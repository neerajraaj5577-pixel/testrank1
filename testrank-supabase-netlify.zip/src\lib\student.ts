import { supabase } from "@/integrations/supabase/client";

type StudentRecord = {
  id: string;
  name: string;
  mobile: string;
  district: string;
  created_at?: string;
};

type StudentIdentity = {
  name: string;
  mobile: string;
  district: string;
};

export async function getExistingStudentByMobile(mobile: string) {
  const normalizedMobile = mobile.trim();
  const { data, error } = await supabase
    .from("students")
    .select("id, name, mobile, district, created_at")
    .eq("mobile", normalizedMobile)
    .order("created_at", { ascending: true })
    .limit(1);

  if (error) throw error;
  return ((data ?? [])[0] as StudentRecord | undefined) ?? null;
}

export async function getOrCreateStudent(identity: StudentIdentity) {
  const existing = await getExistingStudentByMobile(identity.mobile);
  if (existing) return existing;

  const { data, error } = await supabase
    .from("students")
    .insert({
      name: identity.name.trim(),
      mobile: identity.mobile.trim(),
      district: identity.district.trim(),
    })
    .select("id, name, mobile, district, created_at")
    .single();

  if (error) throw error;
  return data as StudentRecord;
}

export async function hasUserAccessToTest({
  userId,
  testId,
  categoryId,
}: {
  userId: string;
  testId: string;
  categoryId?: string | null;
}) {
  const { data: directUnlock, error: directUnlockError } = await supabase
    .from("test_unlocks")
    .select("id")
    .eq("user_id", userId)
    .eq("test_id", testId)
    .maybeSingle();

  if (directUnlockError) throw directUnlockError;
  if (directUnlock) return true;

  if (categoryId) {
    const { data: categoryUnlock, error: categoryUnlockError } = await supabase
      .from("category_unlocks")
      .select("id")
      .eq("user_id", userId)
      .eq("category_id", categoryId)
      .maybeSingle();

    if (categoryUnlockError) throw categoryUnlockError;
    if (categoryUnlock) return true;
  }

  const [{ data: examLinks, error: examLinksError }, { data: subExamLinks, error: subExamLinksError }] = await Promise.all([
    supabase.from("exam_tests" as any).select("exam_id").eq("test_id", testId),
    supabase.from("sub_exam_tests" as any).select("sub_exam_id").eq("test_id", testId),
  ]);

  if (examLinksError) throw examLinksError;
  if (subExamLinksError) throw subExamLinksError;

  const examIds = Array.from(
    new Set(((examLinks ?? []) as any[]).map((row) => row.exam_id).filter(Boolean)),
  );
  if (examIds.length > 0) {
    const { data: examUnlock, error: examUnlockError } = await supabase
      .from("exam_unlocks" as any)
      .select("id")
      .eq("user_id", userId)
      .in("exam_id", examIds)
      .limit(1)
      .maybeSingle();

    if (examUnlockError) throw examUnlockError;
    if (examUnlock) return true;
  }

  const subExamIds = Array.from(
    new Set(((subExamLinks ?? []) as any[]).map((row) => row.sub_exam_id).filter(Boolean)),
  );
  if (subExamIds.length > 0) {
    const { data: subExamUnlock, error: subExamUnlockError } = await supabase
      .from("sub_exam_unlocks" as any)
      .select("id")
      .eq("user_id", userId)
      .in("sub_exam_id", subExamIds)
      .limit(1)
      .maybeSingle();

    if (subExamUnlockError) throw subExamUnlockError;
    if (subExamUnlock) return true;
  }

  return false;
}

export function getStoredStudentId(testId?: string) {
  return testId ? sessionStorage.getItem(`tb_student_${testId}`) : null;
}

export function setStoredStudentId(testId: string, studentId: string) {
  sessionStorage.setItem(`tb_student_${testId}`, studentId);
}

export function getStoredLanguage(testId?: string) {
  return ((testId ? sessionStorage.getItem(`tb_lang_${testId}`) : null) as "en" | "hi" | null) ?? "en";
}

export function setStoredLanguage(testId: string, language: "en" | "hi") {
  sessionStorage.setItem(`tb_lang_${testId}`, language);
}