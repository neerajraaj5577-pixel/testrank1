import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Loader2, ArrowRight, ArrowLeft, Lock, IndianRupee, ShieldCheck, Gift } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import Footer from "@/components/Footer";
import SiteHeader from "@/components/SiteHeader";
import { getExamTheme } from "@/lib/exam-themes";
import SEO from "@/components/SEO";

type SubExam = {
  id: string; exam_id: string; name: string; name_hi: string | null;
  icon_emoji: string | null; badge_label: string | null; exam_codes: string | null;
  is_paid: boolean; price: number | null; mrp: number | null;
  free_category_id: string | null;
};
type Exam = {
  id: string; name: string; color_scheme: string;
  is_paid: boolean; price: number | null; mrp: number | null;
  free_category_id: string | null;
};
type Test = {
  id: string; name: string; total_questions: number; time_limit: number;
  is_paid: boolean; price: number | null; test_type: string | null; subject: string | null;
};

const TABS: Array<{ key: string; label: string; types: string[] }> = [
  { key: "all", label: "All Tests", types: [] },
  { key: "test_series", label: "Test Series", types: ["test_series"] },
  { key: "pyq", label: "Previous Papers", types: ["pyq"] },
  { key: "practice", label: "Practice", types: ["practice", "topic"] },
  { key: "mock", label: "Mock Tests", types: ["mock"] },
];
const TYPE_LABEL: Record<string, string> = {
  mock: "Mock Test", pyq: "PYQ", topic: "Topic Test", practice: "Practice", test_series: "Test Series",
};

declare global { interface Window { Razorpay: any } }

function loadRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true); s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export default function SubExamView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [sub, setSub] = useState<SubExam | null>(null);
  const [exam, setExam] = useState<Exam | null>(null);
  const [examUnlocked, setExamUnlocked] = useState(false);
  const [subUnlocked, setSubUnlocked] = useState(false);
  const [freeCategorySlug, setFreeCategorySlug] = useState<string | null>(null);
  const [tests, setTests] = useState<Test[]>([]);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState(false);
  const [tab, setTab] = useState("all");
  const [subjectFilter, setSubjectFilter] = useState<Set<string>>(new Set());
  const [lockedDialogTest, setLockedDialogTest] = useState<Test | null>(null);

  const refreshUnlockStatus = async (target: "exam" | "sub", targetId: string, userId: string) => {
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const query = target === "sub"
        ? supabase.from("sub_exam_unlocks" as any).select("id").eq("user_id", userId).eq("sub_exam_id", targetId)
        : supabase.from("exam_unlocks" as any).select("id").eq("user_id", userId).eq("exam_id", targetId);

      const { data: unlock } = await query.maybeSingle();
      if (unlock) {
        if (target === "sub") setSubUnlocked(true);
        else setExamUnlocked(true);
        return true;
      }

      await new Promise((resolve) => window.setTimeout(resolve, 1200));
    }

    return false;
  };

  const load = async () => {
    if (!id) return;
    setLoading(true);
    const { data: s } = await supabase.from("sub_exams" as any).select("*").eq("id", id).maybeSingle();
    const subRow = s as any;
    setSub(subRow);

    let examRow: any = null;
    if (subRow) {
      const { data: ex } = await supabase.from("exams" as any).select("*").eq("id", subRow.exam_id).maybeSingle();
      examRow = ex;
      setExam(ex as any);
    }

    if (user && subRow) {
      const [{ data: eu }, { data: su }] = await Promise.all([
        supabase.from("exam_unlocks" as any).select("id").eq("user_id", user.id).eq("exam_id", subRow.exam_id).maybeSingle(),
        supabase.from("sub_exam_unlocks" as any).select("id").eq("user_id", user.id).eq("sub_exam_id", subRow.id).maybeSingle(),
      ]);
      setExamUnlocked(!!eu);
      setSubUnlocked(!!su);
    } else { setExamUnlocked(false); setSubUnlocked(false); }

    // Free-category slug — prefer sub's own, fallback to exam's
    const freeCatId = subRow?.free_category_id ?? examRow?.free_category_id ?? null;
    if (freeCatId) {
      const { data: cat } = await supabase.from("categories").select("slug").eq("id", freeCatId).maybeSingle();
      setFreeCategorySlug((cat as any)?.slug ?? null);
    } else setFreeCategorySlug(null);

    const { data: links } = await supabase.from("sub_exam_tests" as any)
      .select("test_id, position").eq("sub_exam_id", id).order("position");
    const ids = (links ?? []).map((l: any) => l.test_id);
    if (ids.length) {
      const { data: ts } = await supabase
        .from("tests").select("id,name,total_questions,time_limit,is_paid,price,test_type,subject")
        .in("id", ids).eq("status", "published");
      const order = new Map(ids.map((tid, i) => [tid, i]));
      setTests(((ts ?? []) as Test[]).sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0)));
    } else setTests([]);
    setLoading(false);
  };

  useEffect(() => { load(); }, [id, user]);

  const subjects = useMemo(() => {
    const set = new Set<string>();
    tests.forEach((t) => t.subject && set.add(t.subject));
    return Array.from(set).sort();
  }, [tests]);

  const filtered = useMemo(() => {
    const tabDef = TABS.find((t) => t.key === tab) ?? TABS[0];
    return tests.filter((t) => {
      if (tabDef.types.length && !tabDef.types.includes(t.test_type ?? "")) return false;
      if (subjectFilter.size > 0 && !subjectFilter.has(t.subject ?? "")) return false;
      return true;
    });
  }, [tests, tab, subjectFilter]);

  // Whole-group lock: if exam OR sub-exam is paid and the user hasn't unlocked it, every test is locked.
  const groupLocked = (
    (exam?.is_paid && !examUnlocked) ||
    (sub?.is_paid && !subUnlocked)
  ) ?? false;

  const isTestLocked = (t: Test) => {
    if (groupLocked) return true;
    if (t.is_paid) return true; // individual paid test (legacy)
    return false;
  };

  // Decide which payment to trigger and what amount/label to show
  const payTarget: "exam" | "sub" | null = sub?.is_paid ? "sub" : exam?.is_paid ? "exam" : null;
  const payPrice = payTarget === "sub" ? Number(sub?.price ?? 0) : Number(exam?.price ?? 0);
  const payMrp = payTarget === "sub" ? Number(sub?.mrp ?? 0) : Number(exam?.mrp ?? 0);
  const payAlreadyDone = (payTarget === "sub" && subUnlocked) || (payTarget === "exam" && examUnlocked);

  const startPayment = async () => {
    if (!payTarget || !payPrice || !sub || !exam) return;
    if (!user) { navigate(`/signup?redirect=${encodeURIComponent(`/sub-exam/${id}`)}`); return; }
    setPaying(true);
    try {
      const ok = await loadRazorpay();
      if (!ok) throw new Error("Failed to load payment gateway");
      const label = payTarget === "sub" ? sub.name : exam.name;
      const { data: orderData, error: orderErr } = await supabase.functions.invoke("razorpay-create-order", {
        body: {
          amount: Math.round(payPrice * 100), currency: "INR",
          receipt: `${payTarget}_${(payTarget === "sub" ? sub.id : exam.id).slice(0, 8)}_${Date.now()}`,
          notes: { user_id: user.id, [`${payTarget}_id`]: payTarget === "sub" ? sub.id : exam.id },
        },
      });
      if (orderErr || !orderData?.order_id) throw new Error(orderErr?.message || "Could not create order");
      const insertRow: any = {
        user_id: user.id, student_id: user.id,
        amount: payPrice, razorpay_order_id: orderData.order_id, status: "created",
      };
      if (payTarget === "sub") insertRow.sub_exam_id = sub.id; else insertRow.exam_id = exam.id;
      const { data: paymentRow, error: insertErr } = await (supabase.from("test_payments") as any)
        .insert(insertRow).select("id").single();
      if (insertErr) throw insertErr;

      const rzp = new window.Razorpay({
        key: orderData.key_id, amount: orderData.amount, currency: orderData.currency,
        name: "TestNexa", description: label, order_id: orderData.order_id,
        prefill: { name: profile?.name ?? "", contact: profile?.mobile ?? "", email: user.email ?? "" },
        theme: { color: "#0ea5e9" },
        handler: async (resp: any) => {
          try {
            const { data: vData, error: vErr } = await supabase.functions.invoke("razorpay-verify-payment", {
              body: {
                razorpay_order_id: resp.razorpay_order_id,
                razorpay_payment_id: resp.razorpay_payment_id,
                razorpay_signature: resp.razorpay_signature,
                payment_row_id: paymentRow.id,
              },
            });
            if (vErr || !vData?.success) throw new Error(vErr?.message || "Verification failed");
            const targetId = payTarget === "sub" ? sub.id : exam.id;
            const unlockedNow = await refreshUnlockStatus(payTarget, targetId, user.id);
            toast({
              title: "Payment successful",
              description: unlockedNow ? "All tests unlocked." : "Payment received. Access is syncing, please wait a moment.",
            });
            setLockedDialogTest(null);
            await load();
          } catch (e: any) {
            toast({ title: "Verification failed", description: e.message, variant: "destructive" });
          } finally { setPaying(false); }
        },
        modal: { ondismiss: () => { setPaying(false); toast({ title: "Payment cancelled" }); } },
      });
      rzp.on("payment.failed", (resp: any) => {
        toast({ title: "Payment failed", description: resp?.error?.description || "Try again", variant: "destructive" });
        setPaying(false);
      });
      rzp.open();
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
      setPaying(false);
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  if (!sub) return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <Card><CardContent className="py-12 text-center space-y-3">
        <p className="text-muted-foreground">Sub-exam not found.</p>
        <Button asChild><Link to="/">Home</Link></Button>
      </CardContent></Card>
    </div>
  );

  const th = getExamTheme(exam?.color_scheme ?? "blue");

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col">
      <SEO title={`${sub.name} - Mock Tests | TestNexa`} description={`${sub.name} mock tests, previous year papers and practice tests.`} path={`/sub-exam/${sub.id}`} />
      <SiteHeader />

      <main className="container py-6 md:py-10 max-w-6xl flex-1">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate(`/exam/${sub.exam_id}`)}>
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>

        <div className="flex items-start gap-3 mb-4">
          <div className={`h-12 w-12 rounded-xl flex items-center justify-center text-2xl shrink-0 ${th.iconBg} ${th.iconText}`}>
            {sub.icon_emoji ?? "📘"}
          </div>
          <div className="min-w-0">
            <h1 className="text-2xl md:text-3xl font-bold">{sub.name}</h1>
            {sub.name_hi && <div className="text-sm text-muted-foreground">{sub.name_hi}</div>}
          </div>
        </div>

        {/* Premium / free CTAs */}
        {(payTarget || freeCategorySlug) && (
          <Card className={`${th.cardBg} border mb-6`}>
            <CardContent className="p-4 flex items-center gap-3 flex-wrap">
              {payTarget && payPrice > 0 && (
                <>
                  <span className="inline-flex items-center text-xl font-bold">
                    <IndianRupee className="h-5 w-5" />{payPrice}
                  </span>
                  {payMrp > payPrice && <span className="line-through text-muted-foreground">₹{payMrp}</span>}
                  {payAlreadyDone ? (
                    <Badge className="gap-1"><ShieldCheck className="h-3 w-3" /> Unlocked</Badge>
                  ) : (
                    <Button onClick={startPayment} disabled={paying}>
                      {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
                      Unlock all tests
                    </Button>
                  )}
                </>
              )}
              {freeCategorySlug && (
                <Button asChild variant="outline" className="bg-success/10 border-success text-success hover:bg-success/20 hover:text-success">
                  <Link to={`/category/${freeCategorySlug}`}><Gift className="h-4 w-4" /> Want a free mock test? Click here</Link>
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        {/* Tabs */}
        <div className="border-b mb-6 overflow-x-auto">
          <div className="flex gap-1 min-w-max">
            {TABS.map((t) => (
              <button key={t.key} onClick={() => setTab(t.key)}
                className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                  tab === t.key ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
                }`}>
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-[240px_1fr] gap-6">
          <aside className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="font-semibold mb-3">Filter Tests</div>
                {subjects.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No subjects tagged yet.</p>
                ) : (
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-muted-foreground uppercase">Subjects</div>
                    {subjects.map((s) => (
                      <label key={s} className="flex items-center gap-2 text-sm cursor-pointer">
                        <Checkbox
                          checked={subjectFilter.has(s)}
                          onCheckedChange={(v) => {
                            const next = new Set(subjectFilter);
                            if (v) next.add(s); else next.delete(s);
                            setSubjectFilter(next);
                          }}
                        />
                        {s}
                      </label>
                    ))}
                    {subjectFilter.size > 0 && (
                      <Button variant="ghost" size="sm" className="px-0 text-primary" onClick={() => setSubjectFilter(new Set())}>
                        Clear Filters
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </aside>

          <Card>
            <CardContent className="p-0">
              {filtered.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">No tests in this view.</div>
              ) : (
                <div className="divide-y">
                  {filtered.map((t) => {
                    const locked = isTestLocked(t);
                    return (
                      <div key={t.id} className="flex items-center gap-3 p-4 hover:bg-muted/20">
                        <div className={`h-10 w-10 rounded-lg flex items-center justify-center text-lg shrink-0 ${th.iconBg} ${th.iconText}`}>
                          📘
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-semibold">{t.name}</span>
                            {t.test_type && <Badge variant="secondary" className="text-[10px]">{TYPE_LABEL[t.test_type] ?? t.test_type}</Badge>}
                          </div>
                          <div className="text-xs text-muted-foreground mt-0.5">
                            {t.total_questions} Questions · {t.time_limit} Min{t.subject ? ` · ${t.subject}` : ""}
                          </div>
                        </div>
                        {locked ? (
                          <Button size="sm" variant="outline" onClick={() => setLockedDialogTest(t)}>
                            <Lock className="h-3 w-3" /> Locked
                          </Button>
                        ) : (
                          <Button size="sm" onClick={() => navigate(user
                            ? `/test/${t.id}/instructions`
                            : `/signup?redirect=${encodeURIComponent(`/test/${t.id}/instructions`)}`)}>
                            Start Test <ArrowRight className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Locked-test prompt dialog */}
      <Dialog open={!!lockedDialogTest} onOpenChange={(o) => !o && setLockedDialogTest(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Lock className="h-5 w-5 text-primary" /> This test is locked</DialogTitle>
            <DialogDescription>
              {payTarget && payPrice > 0
                ? <>Unlock <strong>all tests</strong> inside <strong>{payTarget === "sub" ? sub.name : exam?.name}</strong> for one payment of <strong>₹{payPrice}</strong>{payMrp > payPrice ? <> (MRP <span className="line-through">₹{payMrp}</span>)</> : null}. Or try a free mock test in the meantime.</>
                : <>This test requires payment. Or try a free mock test in the meantime.</>}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {freeCategorySlug && (
              <Button variant="outline" asChild className="bg-success/10 border-success text-success hover:bg-success/20 hover:text-success">
                <Link to={`/category/${freeCategorySlug}`}><Gift className="h-4 w-4" /> Free mock practice</Link>
              </Button>
            )}
            {payTarget && payPrice > 0 && !payAlreadyDone && (
              <Button onClick={startPayment} disabled={paying}>
                {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
                Unlock all for ₹{payPrice}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}
