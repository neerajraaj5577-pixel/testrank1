// Renders PDF pages to base64 JPEG strings using pdfjs-dist (browser only)
import * as pdfjsLib from "pdfjs-dist";
// Vite-friendly worker import
// @ts-ignore
import workerSrc from "pdfjs-dist/build/pdf.worker.min.mjs?url";

pdfjsLib.GlobalWorkerOptions.workerSrc = workerSrc;

export type PdfPageImage = { pageNumber: number; dataUrl: string };

export async function pdfToImages(
  file: File,
  opts: { maxPages?: number; scale?: number; quality?: number } = {},
): Promise<PdfPageImage[]> {
  const { maxPages = 50, scale = 1.6, quality = 0.85 } = opts;
  const buf = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
  const total = Math.min(pdf.numPages, maxPages);
  const out: PdfPageImage[] = [];
  for (let i = 1; i <= total; i++) {
    const page = await pdf.getPage(i);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement("canvas");
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    const ctx = canvas.getContext("2d")!;
    await page.render({ canvasContext: ctx, viewport } as any).promise;
    const dataUrl = canvas.toDataURL("image/jpeg", quality);
    out.push({ pageNumber: i, dataUrl });
  }
  return out;
}
