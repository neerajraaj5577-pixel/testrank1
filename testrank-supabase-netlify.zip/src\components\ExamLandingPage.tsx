import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import Logo from "@/components/Logo";
import Footer from "@/components/Footer";
import ThemeToggle from "@/components/ThemeToggle";
import SEO, { breadcrumbSchema, courseSchema, faqSchema } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";

export type ExamLandingPageProps = {
  path: string;
  title: string;
  description: string;
  keywords?: string;
  hero: { eyebrow?: string; h1: string; subheading: string; ctaPath?: string; ctaLabel?: string };
  highlights: string[];
  sections: { h2: string; body: string | React.ReactNode }[];
  examTopics?: string[];
  faqs: { q: string; a: string }[];
  related: { name: string; path: string }[];
  breadcrumb: { name: string; path: string }[];
};

export default function ExamLandingPage(p: ExamLandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col">
      <SEO
        title={p.title}
        description={p.description}
        path={p.path}
        keywords={p.keywords}
        jsonLd={[
          breadcrumbSchema(p.breadcrumb),
          courseSchema(p.hero.h1, p.description),
          faqSchema(p.faqs),
        ]}
      />
      <header className="border-b bg-card/80 backdrop-blur sticky top-0 z-10">
        <div className="container flex h-16 items-center justify-between">
          <Logo />
          <div className="flex items-center gap-1">
            <ThemeToggle />
            <Button asChild variant="ghost" size="sm"><Link to="/login">Login</Link></Button>
            <Button asChild size="sm"><Link to="/signup">Sign up</Link></Button>
          </div>
        </div>
      </header>

      <main className="container py-8 md:py-12 flex-1 max-w-5xl">
        <Breadcrumbs items={p.breadcrumb} />

        <section className="text-center py-8 md:py-14 relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/5 via-card to-primary-glow/5 border mb-10">
          {p.hero.eyebrow && (
            <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-4">
              {p.hero.eyebrow}
            </span>
          )}
          <h1 className="text-3xl md:text-5xl font-bold leading-tight px-4">{p.hero.h1}</h1>
          <p className="mt-4 text-muted-foreground text-base md:text-lg max-w-2xl mx-auto px-4">
            {p.hero.subheading}
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Button asChild size="lg">
              <Link to={p.hero.ctaPath || "/"}>{p.hero.ctaLabel || "Start Mock Test"} <ArrowRight className="h-4 w-4" /></Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/signup">Create Free Account</Link>
            </Button>
          </div>
        </section>

        {p.highlights.length > 0 && (
          <section className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-12">
            {p.highlights.map((h) => (
              <div key={h} className="flex items-start gap-2.5 p-4 rounded-lg bg-card border">
                <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-sm">{h}</span>
              </div>
            ))}
          </section>
        )}

        <article className="prose prose-slate dark:prose-invert max-w-none space-y-8">
          {p.sections.map((s) => (
            <section key={s.h2}>
              <h2 className="text-2xl md:text-3xl font-bold mt-2 mb-3">{s.h2}</h2>
              {typeof s.body === "string" ? (
                <p className="text-foreground/85 leading-relaxed">{s.body}</p>
              ) : (
                s.body
              )}
            </section>
          ))}
        </article>

        {p.examTopics && p.examTopics.length > 0 && (
          <section className="mt-12">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">Exams & Topics Covered</h2>
            <div className="flex flex-wrap gap-2">
              {p.examTopics.map((t) => (
                <span key={t} className="px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium border border-primary/20">
                  {t}
                </span>
              ))}
            </div>
          </section>
        )}

        <section className="mt-14">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="bg-card rounded-xl border px-4">
            {p.faqs.map((f, i) => (
              <AccordionItem key={i} value={`q${i}`}>
                <AccordionTrigger className="text-left font-semibold hover:no-underline">{f.q}</AccordionTrigger>
                <AccordionContent className="text-foreground/80 leading-relaxed">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>

        <section className="mt-14 mb-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Related Mock Tests & Resources</h2>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
            {p.related.map((r) => (
              <Link key={r.path} to={r.path}>
                <Card className="hover-glow h-full">
                  <CardContent className="p-4 flex items-center justify-between">
                    <span className="font-medium text-sm">{r.name}</span>
                    <ArrowRight className="h-4 w-4 text-primary" />
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        <section className="mt-14 text-center bg-gradient-primary text-primary-foreground rounded-2xl p-8 md:p-12">
          <h2 className="text-2xl md:text-3xl font-bold mb-2">Ready to Boost Your Rank?</h2>
          <p className="opacity-90 mb-5 max-w-xl mx-auto">
            Join thousands of aspirants practicing on TestNexa daily. Free signup, instant analytics, all-India ranking.
          </p>
          <Button asChild size="lg" variant="secondary">
            <Link to={p.hero.ctaPath || "/"}>{p.hero.ctaLabel || "Practice Now"} <ArrowRight className="h-4 w-4" /></Link>
          </Button>
        </section>
      </main>
      <Footer />
    </div>
  );
}
