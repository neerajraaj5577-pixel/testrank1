import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import Footer from "@/components/Footer";
import SiteHeader from "@/components/SiteHeader";
import SEO, { breadcrumbSchema } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";

export default function StaticPage({
  title,
  subtitle,
  children,
  seoTitle,
  seoDescription,
  path,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  seoTitle?: string;
  seoDescription?: string;
  path?: string;
}) {
  const p = path || "/";
  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col">
      {seoTitle && seoDescription && (
        <SEO
          title={seoTitle}
          description={seoDescription}
          path={p}
          jsonLd={breadcrumbSchema([{ name: title, path: p }])}
        />
      )}
      <SiteHeader />
      <main className="container max-w-3xl py-10 md:py-14 flex-1">
        {seoTitle && <Breadcrumbs items={[{ name: title, path: p }]} />}
        <h1 className="text-3xl md:text-4xl font-bold mb-2">{title}</h1>
        {subtitle && <p className="text-muted-foreground mb-8">{subtitle}</p>}
        <div className="prose prose-slate dark:prose-invert max-w-none space-y-6 text-foreground/90 leading-relaxed">
          {children}
        </div>
      </main>
      <Footer />
    </div>
  );
}
