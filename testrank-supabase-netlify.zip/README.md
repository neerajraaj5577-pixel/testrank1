# TestRank

React + Vite frontend with Supabase Cloud for auth, database, storage, and edge functions. The app is ready to deploy on Netlify.

## Local setup

1. Copy `.env.example` to `.env`.
2. Add your Supabase project values:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`
3. Install dependencies with `npm install`.
4. Run locally with `npm run dev`.

## Supabase setup

1. Create a new Supabase Cloud project.
2. Link the local project:
   ```bash
   npx supabase link --project-ref lpcltrlpqivdsdctdsgy
   ```
3. Apply the database migrations:
   ```bash
   npx supabase db push
   ```
4. Deploy edge functions:
   ```bash
   npx supabase functions deploy parse-mcq-pdf
   npx supabase functions deploy generate-mcqs-from-pdf
   npx supabase functions deploy translate-to-hindi
   npx supabase functions deploy translate-to-english
   npx supabase functions deploy razorpay-create-order --no-verify-jwt
   npx supabase functions deploy razorpay-verify-payment --no-verify-jwt
   ```
5. Add Supabase secrets used by the edge functions:
   ```bash
   npx supabase secrets set OPENAI_API_KEY=your-openai-api-key
   npx supabase secrets set RAZORPAY_KEY_ID=your-razorpay-key-id
   npx supabase secrets set RAZORPAY_KEY_SECRET=your-razorpay-key-secret
   npx supabase secrets set SUPABASE_SERVICE_ROLE_KEY=your-supabase-service-role-key
   ```

## Netlify setup

1. Import the repo in Netlify.
2. Build command: `npm run build`.
3. Publish directory: `dist`.
4. Add environment variables in Netlify:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`

The included `netlify.toml` handles single-page app routing.
