
CREATE TABLE IF NOT EXISTS public.sub_exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid NOT NULL,
  name text NOT NULL,
  name_hi text,
  subtitle text,
  icon_emoji text DEFAULT '📘',
  badge_label text,
  exam_codes text,
  color_scheme text,
  position int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  display_test_count text,
  display_student_count text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS sub_exams_exam_idx ON public.sub_exams(exam_id);

ALTER TABLE public.sub_exams ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active sub_exams" ON public.sub_exams
  FOR SELECT USING (is_active = true);
CREATE POLICY "Public can manage sub_exams" ON public.sub_exams
  FOR ALL USING (true) WITH CHECK (true);

CREATE TRIGGER trg_sub_exams_updated_at
BEFORE UPDATE ON public.sub_exams
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.sub_exam_tests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sub_exam_id uuid NOT NULL,
  test_id uuid NOT NULL,
  position int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (sub_exam_id, test_id)
);

CREATE INDEX IF NOT EXISTS sub_exam_tests_sub_exam_idx ON public.sub_exam_tests(sub_exam_id);
CREATE INDEX IF NOT EXISTS sub_exam_tests_test_idx ON public.sub_exam_tests(test_id);

ALTER TABLE public.sub_exam_tests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view sub_exam_tests" ON public.sub_exam_tests
  FOR SELECT USING (true);
CREATE POLICY "Public can manage sub_exam_tests" ON public.sub_exam_tests
  FOR ALL USING (true) WITH CHECK (true);

ALTER TABLE public.tests ADD COLUMN IF NOT EXISTS test_type text;
ALTER TABLE public.tests ADD COLUMN IF NOT EXISTS subject text;
