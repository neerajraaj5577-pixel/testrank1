export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          id: string
          updated_at: string
          upi_id: string
          upi_payee_name: string
        }
        Insert: {
          id?: string
          updated_at?: string
          upi_id: string
          upi_payee_name: string
        }
        Update: {
          id?: string
          updated_at?: string
          upi_id?: string
          upi_payee_name?: string
        }
        Relationships: []
      }
      blog_posts: {
        Row: {
          content: string
          cover_image: string | null
          created_at: string
          excerpt: string | null
          id: string
          is_published: boolean
          published_at: string | null
          seo_description: string | null
          seo_title: string | null
          slug: string
          tags: string[] | null
          title: string
          updated_at: string
        }
        Insert: {
          content: string
          cover_image?: string | null
          created_at?: string
          excerpt?: string | null
          id?: string
          is_published?: boolean
          published_at?: string | null
          seo_description?: string | null
          seo_title?: string | null
          slug: string
          tags?: string[] | null
          title: string
          updated_at?: string
        }
        Update: {
          content?: string
          cover_image?: string | null
          created_at?: string
          excerpt?: string | null
          id?: string
          is_published?: boolean
          published_at?: string | null
          seo_description?: string | null
          seo_title?: string | null
          slug?: string
          tags?: string[] | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          is_paid: boolean
          mrp: number | null
          name: string
          position: number
          price: number | null
          slug: string
          thumbnail_url: string | null
          updated_at: string
          validity_days: number | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          is_paid?: boolean
          mrp?: number | null
          name: string
          position?: number
          price?: number | null
          slug: string
          thumbnail_url?: string | null
          updated_at?: string
          validity_days?: number | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          is_paid?: boolean
          mrp?: number | null
          name?: string
          position?: number
          price?: number | null
          slug?: string
          thumbnail_url?: string | null
          updated_at?: string
          validity_days?: number | null
        }
        Relationships: []
      }
      category_unlocks: {
        Row: {
          category_id: string
          id: string
          source: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          category_id: string
          id?: string
          source?: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          category_id?: string
          id?: string
          source?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "category_unlocks_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      exam_tests: {
        Row: {
          created_at: string
          exam_id: string
          id: string
          position: number
          test_id: string
        }
        Insert: {
          created_at?: string
          exam_id: string
          id?: string
          position?: number
          test_id: string
        }
        Update: {
          created_at?: string
          exam_id?: string
          id?: string
          position?: number
          test_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "exam_tests_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
        ]
      }
      exam_unlocks: {
        Row: {
          exam_id: string
          id: string
          source: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          exam_id: string
          id?: string
          source?: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          exam_id?: string
          id?: string
          source?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: []
      }
      exams: {
        Row: {
          badge_label: string | null
          color_scheme: string
          created_at: string
          display_student_count: string | null
          display_test_count: string | null
          exam_codes: string | null
          free_category_id: string | null
          icon_emoji: string | null
          id: string
          is_active: boolean
          is_paid: boolean
          logo_url: string | null
          mrp: number | null
          name: string
          name_hi: string | null
          position: number
          price: number | null
          subtitle: string | null
          updated_at: string
          validity_days: number | null
        }
        Insert: {
          badge_label?: string | null
          color_scheme?: string
          created_at?: string
          display_student_count?: string | null
          display_test_count?: string | null
          exam_codes?: string | null
          free_category_id?: string | null
          icon_emoji?: string | null
          id?: string
          is_active?: boolean
          is_paid?: boolean
          logo_url?: string | null
          mrp?: number | null
          name: string
          name_hi?: string | null
          position?: number
          price?: number | null
          subtitle?: string | null
          updated_at?: string
          validity_days?: number | null
        }
        Update: {
          badge_label?: string | null
          color_scheme?: string
          created_at?: string
          display_student_count?: string | null
          display_test_count?: string | null
          exam_codes?: string | null
          free_category_id?: string | null
          icon_emoji?: string | null
          id?: string
          is_active?: boolean
          is_paid?: boolean
          logo_url?: string | null
          mrp?: number | null
          name?: string
          name_hi?: string | null
          position?: number
          price?: number | null
          subtitle?: string | null
          updated_at?: string
          validity_days?: number | null
        }
        Relationships: []
      }
      questions: {
        Row: {
          correct_answer: string
          created_at: string
          explanation: string | null
          explanation_hi: string | null
          id: string
          image_url: string | null
          option_a: string
          option_a_hi: string | null
          option_a_image: string | null
          option_b: string
          option_b_hi: string | null
          option_b_image: string | null
          option_c: string
          option_c_hi: string | null
          option_c_image: string | null
          option_d: string
          option_d_hi: string | null
          option_d_image: string | null
          order_index: number
          question: string
          question_hi: string | null
          section_id: string | null
          test_id: string
        }
        Insert: {
          correct_answer?: string
          created_at?: string
          explanation?: string | null
          explanation_hi?: string | null
          id?: string
          image_url?: string | null
          option_a?: string
          option_a_hi?: string | null
          option_a_image?: string | null
          option_b?: string
          option_b_hi?: string | null
          option_b_image?: string | null
          option_c?: string
          option_c_hi?: string | null
          option_c_image?: string | null
          option_d?: string
          option_d_hi?: string | null
          option_d_image?: string | null
          order_index?: number
          question: string
          question_hi?: string | null
          section_id?: string | null
          test_id: string
        }
        Update: {
          correct_answer?: string
          created_at?: string
          explanation?: string | null
          explanation_hi?: string | null
          id?: string
          image_url?: string | null
          option_a?: string
          option_a_hi?: string | null
          option_a_image?: string | null
          option_b?: string
          option_b_hi?: string | null
          option_b_image?: string | null
          option_c?: string
          option_c_hi?: string | null
          option_c_image?: string | null
          option_d?: string
          option_d_hi?: string | null
          option_d_image?: string | null
          order_index?: number
          question?: string
          question_hi?: string | null
          section_id?: string | null
          test_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "questions_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "test_sections"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questions_test_id_fkey"
            columns: ["test_id"]
            isOneToOne: false
            referencedRelation: "tests"
            referencedColumns: ["id"]
          },
        ]
      }
      results: {
        Row: {
          answers: Json | null
          correct_answers: number
          id: string
          per_question_time: Json | null
          score: number
          student_id: string
          submitted_at: string
          test_id: string
          time_taken_seconds: number
          unattempted: number
          wrong_answers: number
        }
        Insert: {
          answers?: Json | null
          correct_answers?: number
          id?: string
          per_question_time?: Json | null
          score?: number
          student_id: string
          submitted_at?: string
          test_id: string
          time_taken_seconds?: number
          unattempted?: number
          wrong_answers?: number
        }
        Update: {
          answers?: Json | null
          correct_answers?: number
          id?: string
          per_question_time?: Json | null
          score?: number
          student_id?: string
          submitted_at?: string
          test_id?: string
          time_taken_seconds?: number
          unattempted?: number
          wrong_answers?: number
        }
        Relationships: [
          {
            foreignKeyName: "results_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "results_test_id_fkey"
            columns: ["test_id"]
            isOneToOne: false
            referencedRelation: "tests"
            referencedColumns: ["id"]
          },
        ]
      }
      student_profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          district: string
          dob: string | null
          exam: string | null
          mobile: string
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          district: string
          dob?: string | null
          exam?: string | null
          mobile: string
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          district?: string
          dob?: string | null
          exam?: string | null
          mobile?: string
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      students: {
        Row: {
          created_at: string
          district: string
          id: string
          mobile: string
          name: string
        }
        Insert: {
          created_at?: string
          district: string
          id?: string
          mobile: string
          name: string
        }
        Update: {
          created_at?: string
          district?: string
          id?: string
          mobile?: string
          name?: string
        }
        Relationships: []
      }
      sub_exam_tests: {
        Row: {
          created_at: string
          id: string
          position: number
          sub_exam_id: string
          test_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          position?: number
          sub_exam_id: string
          test_id: string
        }
        Update: {
          created_at?: string
          id?: string
          position?: number
          sub_exam_id?: string
          test_id?: string
        }
        Relationships: []
      }
      sub_exam_unlocks: {
        Row: {
          id: string
          source: string
          sub_exam_id: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          id?: string
          source?: string
          sub_exam_id: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          id?: string
          source?: string
          sub_exam_id?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: []
      }
      sub_exams: {
        Row: {
          badge_label: string | null
          color_scheme: string | null
          created_at: string
          display_student_count: string | null
          display_test_count: string | null
          exam_codes: string | null
          exam_id: string
          free_category_id: string | null
          icon_emoji: string | null
          id: string
          is_active: boolean
          is_paid: boolean
          mrp: number | null
          name: string
          name_hi: string | null
          position: number
          price: number | null
          subtitle: string | null
          updated_at: string
          validity_days: number | null
        }
        Insert: {
          badge_label?: string | null
          color_scheme?: string | null
          created_at?: string
          display_student_count?: string | null
          display_test_count?: string | null
          exam_codes?: string | null
          exam_id: string
          free_category_id?: string | null
          icon_emoji?: string | null
          id?: string
          is_active?: boolean
          is_paid?: boolean
          mrp?: number | null
          name: string
          name_hi?: string | null
          position?: number
          price?: number | null
          subtitle?: string | null
          updated_at?: string
          validity_days?: number | null
        }
        Update: {
          badge_label?: string | null
          color_scheme?: string | null
          created_at?: string
          display_student_count?: string | null
          display_test_count?: string | null
          exam_codes?: string | null
          exam_id?: string
          free_category_id?: string | null
          icon_emoji?: string | null
          id?: string
          is_active?: boolean
          is_paid?: boolean
          mrp?: number | null
          name?: string
          name_hi?: string | null
          position?: number
          price?: number | null
          subtitle?: string | null
          updated_at?: string
          validity_days?: number | null
        }
        Relationships: []
      }
      test_payments: {
        Row: {
          amount: number
          category_id: string | null
          created_at: string
          exam_id: string | null
          id: string
          notes: string | null
          razorpay_order_id: string
          razorpay_payment_id: string | null
          razorpay_signature: string | null
          status: string
          student_id: string
          sub_exam_id: string | null
          test_id: string | null
          updated_at: string
          user_id: string | null
          utr: string | null
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          amount: number
          category_id?: string | null
          created_at?: string
          exam_id?: string | null
          id?: string
          notes?: string | null
          razorpay_order_id: string
          razorpay_payment_id?: string | null
          razorpay_signature?: string | null
          status?: string
          student_id: string
          sub_exam_id?: string | null
          test_id?: string | null
          updated_at?: string
          user_id?: string | null
          utr?: string | null
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          amount?: number
          category_id?: string | null
          created_at?: string
          exam_id?: string | null
          id?: string
          notes?: string | null
          razorpay_order_id?: string
          razorpay_payment_id?: string | null
          razorpay_signature?: string | null
          status?: string
          student_id?: string
          sub_exam_id?: string | null
          test_id?: string | null
          updated_at?: string
          user_id?: string | null
          utr?: string | null
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "test_payments_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      test_sections: {
        Row: {
          created_at: string
          id: string
          name: string
          position: number
          test_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          position?: number
          test_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          position?: number
          test_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "test_sections_test_id_fkey"
            columns: ["test_id"]
            isOneToOne: false
            referencedRelation: "tests"
            referencedColumns: ["id"]
          },
        ]
      }
      test_unlocks: {
        Row: {
          id: string
          source: string
          test_id: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          id?: string
          source?: string
          test_id: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          id?: string
          source?: string
          test_id?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "test_unlocks_test_id_fkey"
            columns: ["test_id"]
            isOneToOne: false
            referencedRelation: "tests"
            referencedColumns: ["id"]
          },
        ]
      }
      tests: {
        Row: {
          category_id: string | null
          created_at: string
          description: string | null
          description_hi: string | null
          id: string
          is_paid: boolean
          marks_per_question: number
          name: string
          name_hi: string | null
          negative_marking_fraction: number | null
          price: number | null
          status: string
          subject: string | null
          test_type: string | null
          thumbnail_url: string | null
          time_limit: number
          total_questions: number
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          description?: string | null
          description_hi?: string | null
          id?: string
          is_paid?: boolean
          marks_per_question?: number
          name: string
          name_hi?: string | null
          negative_marking_fraction?: number | null
          price?: number | null
          status?: string
          subject?: string | null
          test_type?: string | null
          thumbnail_url?: string | null
          time_limit?: number
          total_questions?: number
        }
        Update: {
          category_id?: string | null
          created_at?: string
          description?: string | null
          description_hi?: string | null
          id?: string
          is_paid?: boolean
          marks_per_question?: number
          name?: string
          name_hi?: string | null
          negative_marking_fraction?: number | null
          price?: number | null
          status?: string
          subject?: string | null
          test_type?: string | null
          thumbnail_url?: string | null
          time_limit?: number
          total_questions?: number
        }
        Relationships: [
          {
            foreignKeyName: "tests_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_test_questions: {
        Args: { p_test_id: string }
        Returns: {
          explanation: string
          explanation_hi: string
          id: string
          option_a: string
          option_a_hi: string
          option_a_image: string
          option_b: string
          option_b_hi: string
          option_b_image: string
          option_c: string
          option_c_hi: string
          option_c_image: string
          option_d: string
          option_d_hi: string
          option_d_image: string
          order_index: number
          question: string
          question_hi: string
          section_id: string
        }[]
      }
      submit_test:
        | {
            Args: {
              p_answers: Json
              p_student_id: string
              p_test_id: string
              p_time_taken: number
            }
            Returns: string
          }
        | {
            Args: {
              p_answers: Json
              p_per_question_time?: Json
              p_student_id: string
              p_test_id: string
              p_time_taken: number
            }
            Returns: string
          }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
