import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, X } from "lucide-react";
import { format } from "@/lib/format";

type DateRange = "all" | "today" | "7d" | "30d";

export default function AdminStudents() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [district, setDistrict] = useState<string>("all");
  const [range, setRange] = useState<DateRange>("all");

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("students").select("*").order("created_at", { ascending: false });
      setRows(data ?? []);
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search.trim().toLowerCase()), 200);
    return () => clearTimeout(t);
  }, [search]);

  const districts = useMemo(() => {
    const set = new Set<string>();
    rows.forEach((r) => r.district && set.add(r.district));
    return Array.from(set).sort();
  }, [rows]);

  const uniqueRows = useMemo(() => {
    const map = new Map<string, any>();
    rows.forEach((row) => {
      const key = row.mobile?.trim() || row.id;
      const existing = map.get(key);
      if (!existing) {
        map.set(key, row);
        return;
      }
      if (new Date(row.created_at).getTime() < new Date(existing.created_at).getTime()) {
        map.set(key, { ...row, name: existing.name || row.name, district: existing.district || row.district });
      }
    });
    return Array.from(map.values());
  }, [rows]);

  const filtered = useMemo(() => {
    const now = Date.now();
    const cutoff =
      range === "today" ? now - 24 * 60 * 60 * 1000 :
      range === "7d" ? now - 7 * 24 * 60 * 60 * 1000 :
      range === "30d" ? now - 30 * 24 * 60 * 60 * 1000 :
      0;
    return uniqueRows.filter((r) => {
      if (district !== "all" && r.district !== district) return false;
      if (cutoff && new Date(r.created_at).getTime() < cutoff) return false;
      if (debounced) {
        const hay = `${r.name ?? ""} ${r.mobile ?? ""}`.toLowerCase();
        if (!hay.includes(debounced)) return false;
      }
      return true;
    });
  }, [uniqueRows, debounced, district, range]);

  const hasFilters = search !== "" || district !== "all" || range !== "all";
  const clearFilters = () => {
    setSearch("");
    setDistrict("all");
    setRange("all");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Students</h1>
        <p className="text-muted-foreground">Everyone who has registered for a test.</p>
      </div>

      <Card className="p-4 space-y-3">
        <div className="grid gap-3 md:grid-cols-[1fr_auto_auto]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by unique student name or mobile…"
              className="pl-9"
            />
          </div>
          <Select value={district} onValueChange={setDistrict}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="District" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All districts</SelectItem>
              {districts.map((d) => (
                <SelectItem key={d} value={d}>{d}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={range} onValueChange={(v) => setRange(v as DateRange)}>
            <SelectTrigger className="w-full md:w-44">
              <SelectValue placeholder="Date" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">
            Showing {filtered.length} of {uniqueRows.length} unique students
          </span>
          {hasFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters}>
              <X className="h-3 w-3" /> Clear filters
            </Button>
          )}
        </div>
      </Card>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Mobile</TableHead>
              <TableHead className="hidden sm:table-cell">District</TableHead>
              <TableHead className="hidden md:table-cell">Registered</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                  Loading…
                </TableCell>
              </TableRow>
            ) : rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                  No students yet.
                </TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                  <div className="space-y-2">
                    <p>No students match your filters.</p>
                    <Button variant="outline" size="sm" onClick={clearFilters}>
                      Clear filters
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium">{s.name}</TableCell>
                  <TableCell>{s.mobile}</TableCell>
                  <TableCell className="hidden sm:table-cell">{s.district}</TableCell>
                  <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                    {format.dateTime(s.created_at)}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
