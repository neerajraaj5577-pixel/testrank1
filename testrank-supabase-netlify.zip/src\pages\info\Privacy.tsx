import StaticPage from "./StaticPage";

export default function Privacy() {
  return (
    <StaticPage title="Privacy Policy" subtitle="Last updated: May 2026" path="/privacy" seoTitle="Privacy Policy – TestNexa" seoDescription="Read TestNexa's privacy policy: what data we collect, how we use it, your rights, and our security practices.">
      <p>
        Your privacy matters. This policy explains what data TestNexa collects, why we collect it,
        and how we keep it safe.
      </p>

      <h2 className="text-2xl font-semibold mt-6">1. What we collect</h2>
      <ul className="list-disc pl-6 space-y-1">
        <li><strong>Account info:</strong> Name, mobile number, district, exam preference.</li>
        <li><strong>Profile picture:</strong> Optional — uploaded by you.</li>
        <li><strong>Test data:</strong> Your answers, time per question, scores, and review history.</li>
        <li><strong>Payment info:</strong> Payment reference details needed to confirm successful online payments (no card data is ever stored).</li>
      </ul>

      <h2 className="text-2xl font-semibold mt-6">2. How we use it</h2>
      <ul className="list-disc pl-6 space-y-1">
        <li>To deliver tests and personalised analytics.</li>
        <li>To verify your payments and unlock paid categories.</li>
        <li>To send important account notifications (no spam).</li>
      </ul>

      <h2 className="text-2xl font-semibold mt-6">3. Sharing</h2>
      <p>We never sell your data. Aggregated, anonymised stats may be shared publicly (e.g. national rank percentiles).</p>

      <h2 className="text-2xl font-semibold mt-6">4. Security</h2>
      <p>All data is stored on encrypted infrastructure with role-based access and row-level security.</p>

      <h2 className="text-2xl font-semibold mt-6">5. Your rights</h2>
      <p>You may delete your account or request your data anytime by emailing <a className="text-primary" href="mailto:privacy@testnexa.com">privacy@testnexa.com</a>.</p>

      <h2 className="text-2xl font-semibold mt-6">6. Cookies</h2>
      <p>We use only essential cookies for login and preferences. No third-party tracking.</p>
    </StaticPage>
  );
}
