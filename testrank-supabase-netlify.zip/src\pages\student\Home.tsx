import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  FileQuestion, ListChecks, Clock, IndianRupee,
  Search, FolderTree, ArrowRight,
  Zap, Globe, BarChart3, ShieldCheck,
} from "lucide-react";
import Footer from "@/components/Footer";
import SiteHeader from "@/components/SiteHeader";
import SEO, { orgSchema, websiteSchema, faqSchema } from "@/components/SEO";
import ExamCard, { type ExamCardData } from "@/components/ExamCard";

const HOME_FAQS = [
  { q: "Is TestNexa free to use?", a: "Yes. A large library of mock tests, daily quizzes and current affairs is completely free. Premium category packs are optional with lifetime access." },
  { q: "Which exams are covered on TestNexa?", a: "SSC (CGL, CHSL, GD, MTS), Banking (IBPS PO, SBI PO, Clerk, RBI), Railways (NTPC, Group D, ALP), UPSC Prelims, State PSC and many more." },
  { q: "Are mock tests bilingual?", a: "Yes. Most mock tests support both English and Hindi — you can switch language during the attempt." },
  { q: "Will I get an All-India Rank?", a: "Yes. Every mock test gives you an instant score, percentile and rank against every other aspirant." },
];

type CatStat = {
  id: string | null;
  name: string;
  slug: string;
  description: string | null;
  thumbnail_url: string | null;
  position: number;
  test_count: number;
  total_questions: number;
  total_minutes: number;
  pricing: "free" | "paid" | "mixed";
  min_price: number | null;
  cat_is_paid?: boolean;
  cat_price?: number | null;
  cat_mrp?: number | null;
};

type SearchTest = {
  id: string;
  name: string;
  description: string | null;
  subject: string | null;
  test_type: string | null;
  category_name: string | null;
  total_questions: number;
  time_limit: number;
  is_paid: boolean;
  price: number | null;
};

function formatMinutes(m: number) {
  if (m <= 0) return "0 min";
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60);
  const r = m % 60;
  return r === 0 ? `${h} hr` : `${h} hr ${r} min`;
}

export default function StudentHome() {
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const [cats, setCats] = useState<CatStat[]>([]);
  const [exams, setExams] = useState<ExamCardData[]>([]);
  const [searchTests, setSearchTests] = useState<SearchTest[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [{ data: categories }, { data: tests }, { data: examsData }, { data: examLinks }] = await Promise.all([
        supabase.from("categories").select("*").eq("is_active", true).order("position").order("created_at"),
        supabase.from("tests").select("id,name,description,subject,test_type,category_id,total_questions,time_limit,is_paid,price").eq("status", "published"),
        supabase.from("exams" as any).select("*").eq("is_active", true).order("position").order("created_at"),
        supabase.from("exam_tests" as any).select("exam_id"),
      ]);

      const examTestCounts = new Map<string, number>();
      (examLinks ?? []).forEach((l: any) => examTestCounts.set(l.exam_id, (examTestCounts.get(l.exam_id) ?? 0) + 1));
      setExams(((examsData ?? []) as any[]).map((e: any) => ({
        id: e.id, name: e.name, name_hi: e.name_hi, subtitle: e.subtitle,
        badge_label: e.badge_label, icon_emoji: e.icon_emoji, color_scheme: e.color_scheme,
        exam_codes: e.exam_codes, is_paid: !!e.is_paid, price: e.price ? Number(e.price) : null,
        display_test_count: e.display_test_count, display_student_count: e.display_student_count,
        test_count: examTestCounts.get(e.id) ?? 0,
        logo_url: e.logo_url ?? null,
      })));

      const categoryNames = new Map((categories ?? []).map((category: any) => [category.id, category.name]));
      setSearchTests(((tests ?? []) as any[]).map((test) => ({
        id: test.id,
        name: test.name,
        description: test.description ?? null,
        subject: test.subject ?? null,
        test_type: test.test_type ?? null,
        category_name: categoryNames.get(test.category_id) ?? null,
        total_questions: Number(test.total_questions) || 0,
        time_limit: Number(test.time_limit) || 0,
        is_paid: !!test.is_paid,
        price: test.price != null ? Number(test.price) : null,
      })));


      const buildStat = (
        meta: { id: string | null; name: string; slug: string; description: string | null; thumbnail_url: string | null; position: number },
        list: any[],
      ): CatStat => {
        const test_count = list.length;
        const total_questions = list.reduce((s, t) => s + (Number(t.total_questions) || 0), 0);
        const total_minutes = list.reduce((s, t) => s + (Number(t.time_limit) || 0), 0);
        const paidPrices = list.filter((t) => t.is_paid && Number(t.price ?? 0) > 0).map((t) => Number(t.price));
        let pricing: "free" | "paid" | "mixed" = "free";
        if (paidPrices.length === test_count && test_count > 0) pricing = "paid";
        else if (paidPrices.length > 0) pricing = "mixed";
        const min_price = paidPrices.length ? Math.min(...paidPrices) : null;
        return { ...meta, test_count, total_questions, total_minutes, pricing, min_price };
      };

      const result: CatStat[] = [];
      (categories ?? []).forEach((c: any) => {
        const list = (tests ?? []).filter((t: any) => t.category_id === c.id);
        result.push({
          ...buildStat({
            id: c.id, name: c.name, slug: c.slug, description: c.description,
            thumbnail_url: c.thumbnail_url, position: c.position,
          }, list),
          cat_is_paid: !!c.is_paid,
          cat_price: c.price != null ? Number(c.price) : null,
          cat_mrp: c.mrp != null ? Number(c.mrp) : null,
        });
      });
      const otherList = (tests ?? []).filter((t: any) => !t.category_id);
      if (otherList.length > 0) {
        result.push(buildStat({
          id: null, name: "Other Tests", slug: "other",
          description: "Tests not assigned to any category.",
          thumbnail_url: null, position: 9999,
        }, otherList));
      }
      setCats(result);
      setLoading(false);
    })();
  }, []);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return cats;
    return cats.filter((c) => c.name.toLowerCase().includes(s) || (c.description ?? "").toLowerCase().includes(s));
  }, [cats, q]);

  const filteredExams = useMemo(() => {
    const search = q.trim().toLowerCase();
    if (!search) return exams;
    return exams.filter((exam) =>
      [exam.name, exam.name_hi, exam.subtitle, exam.exam_codes]
        .some((value) => (value ?? "").toLowerCase().includes(search)),
    );
  }, [exams, q]);

  const filteredTests = useMemo(() => {
    const search = q.trim().toLowerCase();
    if (!search) return [];
    return searchTests.filter((test) =>
      [test.name, test.description, test.subject, test.test_type, test.category_name]
        .some((value) => (value ?? "").toLowerCase().includes(search)),
    );
  }, [q, searchTests]);

  const hasSearch = q.trim().length > 0;
  const searchResultCount = filteredExams.length + filtered.length + filteredTests.length;

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,hsl(0_84%_60%/0.10),transparent_55%),radial-gradient(ellipse_at_bottom_right,hsl(220_90%_60%/0.10),transparent_55%),linear-gradient(180deg,hsl(var(--background)),hsl(var(--background)))]">
      <SEO
        title="TestNexa – Free Mock Tests & Online Test Series for Govt Exams"
        description="Practice free mock tests, online quizzes, previous year papers & AI-powered test series for SSC, Banking, Railway, UPSC & government exams on TestNexa."
        path="/"
        keywords="mock test, online test series, free mock test, SSC mock test, banking mock test, railway exam, UPSC mock test, government exam preparation, daily quiz, current affairs"
        jsonLd={[orgSchema, websiteSchema, faqSchema(HOME_FAQS)]}
      />
      <SiteHeader />

      <main className="container py-10 md:py-16 relative overflow-hidden">
        {/* Hero — Cyber glow */}
        <section className="relative mb-14 md:mb-20">
          {/* Background glows */}
          <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] max-w-full h-[400px] bg-red-600/15 blur-[120px] rounded-full" />
          <div className="pointer-events-none absolute top-1/4 left-1/3 w-[300px] h-[300px] bg-blue-600/10 blur-[100px] rounded-full" />

          <div className="relative max-w-5xl mx-auto text-center flex flex-col items-center px-2">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-card/60 border border-border mb-6 md:mb-8 backdrop-blur-sm">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75 animate-ping" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-red-500" />
              </span>
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-foreground/80">
                Test Smart. Crack Faster.
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-[2rem] leading-[1.1] sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight mb-5 md:mb-6">
              India's Smart{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-700">
                Mock Test Platform
              </span>{" "}
              for Govt Exam Prep
            </h1>

            {/* Subtitle */}
            <p className="max-w-2xl text-muted-foreground text-sm sm:text-base md:text-lg leading-relaxed mb-8 md:mb-10">
              Practice free mock tests, daily quizzes, previous year papers and AI-powered performance analysis for SSC, Banking, Railway, UPSC and state exams.
            </p>

            {/* Search & filters */}
            <div className="w-full max-w-2xl space-y-5 md:space-y-6">
              {/* Search Bar with glow */}
              <div className="group relative">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-red-600 to-zinc-700 rounded-2xl blur opacity-30 group-focus-within:opacity-60 transition duration-500" />
                <div className="relative flex items-center bg-card/80 backdrop-blur-xl border border-border rounded-2xl p-2 shadow-2xl">
                  <Search className="ml-3 h-5 w-5 text-muted-foreground shrink-0" />
                  <input
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    type="text"
                    placeholder="Search for SSC, UPSC or Banking exams..."
                    className="flex-1 bg-transparent border-none text-foreground px-3 py-3 focus:outline-none placeholder:text-muted-foreground/70 text-sm md:text-base min-w-0"
                  />
                  <button
                    onClick={() => document.getElementById("search-results")?.scrollIntoView({ behavior: "smooth", block: "start" })}
                    className="hidden sm:inline-flex shrink-0 px-5 md:px-6 py-2.5 md:py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-red-900/30 active:scale-95"
                  >
                    Find Exam
                  </button>
                </div>
              </div>

              {/* Popular Tags */}
              <div className="flex flex-wrap justify-center gap-2">
                {exams.length > 0 ? exams.slice(0, 8).map((e) => (
                  <Link
                    key={e.id}
                    to={`/exam/${e.id}`}
                    className="px-3 py-1.5 rounded-lg bg-card border border-border text-xs font-medium text-muted-foreground hover:text-foreground hover:border-red-500/60 hover:bg-card/80 transition-all"
                  >
                    {e.name}
                  </Link>
                )) : [
                  { l: "SSC Mock Test", p: "/ssc-mock-test" },
                  { l: "Banking Mock Test", p: "/banking-mock-test" },
                  { l: "Railway Mock Test", p: "/railway-mock-test" },
                  { l: "UPSC Mock Test", p: "/upsc-mock-test" },
                  { l: "Daily Quiz", p: "/daily-quiz" },
                  { l: "Previous Year Papers", p: "/previous-year-papers" },
                ].map((x) => (
                  <Link
                    key={x.p}
                    to={x.p}
                    className="px-3 py-1.5 rounded-lg bg-card border border-border text-xs font-medium text-muted-foreground hover:text-foreground hover:border-red-500/60 hover:bg-card/80 transition-all"
                  >
                    {x.l}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>

        {hasSearch && (
          <section id="search-results" className="scroll-mt-24 mb-12 space-y-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold">Search results</h2>
              <p className="text-sm text-muted-foreground mt-1">
                {searchResultCount} available result{searchResultCount === 1 ? "" : "s"} for "{q.trim()}"
              </p>
            </div>

            {filteredExams.length > 0 && (
              <div>
                <h3 className="font-semibold mb-3">Exams</h3>
                <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                  {filteredExams.map((exam) => <ExamCard key={exam.id} exam={exam} />)}
                </div>
              </div>
            )}

            {filtered.length > 0 && (
              <div>
                <h3 className="font-semibold mb-3">Categories</h3>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {filtered.map((category) => (
                    <Card
                      key={category.slug}
                      className="cursor-pointer hover:border-red-500/60"
                      onClick={() => navigate(`/category/${category.slug}`)}
                    >
                      <CardHeader>
                        <CardTitle className="text-base">{category.name}</CardTitle>
                        <CardDescription className="line-clamp-2">
                          {category.description ?? `${category.test_count} available tests`}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="text-sm text-muted-foreground">
                        {category.test_count} tests · {category.total_questions} questions
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {filteredTests.length > 0 && (
              <div>
                <h3 className="font-semibold mb-3">Available tests</h3>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {filteredTests.map((test) => (
                    <Card key={test.id} className="flex flex-col">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between gap-2">
                          <CardTitle className="text-base leading-snug">{test.name}</CardTitle>
                          <Badge variant={test.is_paid ? "default" : "secondary"}>
                            {test.is_paid && test.price ? `Rs ${test.price}` : "Free"}
                          </Badge>
                        </div>
                        <CardDescription>{test.category_name ?? test.subject ?? "Mock test"}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-1 text-sm text-muted-foreground">
                        {test.total_questions} questions · {test.time_limit} minutes
                      </CardContent>
                      <CardFooter>
                        <Button
                          className="w-full"
                          onClick={() => navigate(user
                            ? `/test/${test.id}/${test.is_paid ? "pay" : "instructions"}`
                            : `/signup?redirect=${encodeURIComponent(`/test/${test.id}/${test.is_paid ? "pay" : "instructions"}`)}`)}
                        >
                          Start test <ArrowRight className="h-4 w-4" />
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {searchResultCount === 0 && (
              <Card>
                <CardContent className="py-10 text-center text-muted-foreground">
                  No available exams, categories, or tests match your search.
                </CardContent>
              </Card>
            )}
          </section>
        )}

        {!hasSearch && exams.length > 0 && (
          <section className="mb-12 relative">
            <h2 className="text-2xl md:text-3xl font-bold mb-1">Browse by Exam</h2>
            <p className="text-muted-foreground text-sm mb-5">Pick your target exam — practice mock tests, previous year papers and quizzes.</p>
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {exams.map((e) => <ExamCard key={e.id} exam={e} />)}
            </div>
          </section>
        )}

        {!hasSearch && <>
        <div className="mb-12 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-4xl mx-auto">
          {[
            { n: "50K+", l: "Active Learners" },
            { n: "1000+", l: "Mock Tests" },
            { n: "25+", l: "Govt Exams" },
            { n: "4.8★", l: "Rated by Aspirants" },
          ].map((s) => (
            <div key={s.l} className="rounded-xl border-2 border-red-500/30 bg-card/80 backdrop-blur px-3 py-4 text-center shadow-sm hover:border-red-500 transition-colors">
              <div className="text-2xl md:text-3xl font-extrabold bg-gradient-to-r from-red-600 to-rose-500 bg-clip-text text-transparent">{s.n}</div>
              <div className="text-[11px] md:text-xs text-muted-foreground mt-1 font-medium">{s.l}</div>
            </div>
          ))}
        </div>

        {loading ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 relative">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-72" />)}
          </div>
        ) : filtered.length === 0 ? (
          <Card className="max-w-md mx-auto text-center relative">
            <CardContent className="py-12">
              <FileQuestion className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">
                {cats.length === 0
                  ? "No categories yet. Check back soon!"
                  : "No categories match your search."}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 relative">
            {filtered.map((c) => (
              <Card key={c.slug} className="flex flex-col hover-glow gradient-border-top overflow-hidden cursor-pointer"
                onClick={() => navigate(`/category/${c.slug}`)}>
                <div className="relative aspect-video w-full overflow-hidden bg-muted">
                  {c.thumbnail_url ? (
                    <img src={c.thumbnail_url} alt={c.name}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                      loading="lazy" />
                  ) : (
                    <div className="w-full h-full bg-gradient-primary flex items-center justify-center">
                      <FolderTree className="h-12 w-12 text-primary-foreground/80" />
                    </div>
                  )}
                  {c.cat_is_paid && c.cat_price ? (
                    <div className="absolute top-3 right-3 flex flex-col items-end gap-1">
                      <Badge className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-md gap-0.5">
                        <IndianRupee className="h-3 w-3" />{c.cat_price}
                      </Badge>
                      {c.cat_mrp && c.cat_mrp > c.cat_price && (
                        <Badge variant="secondary" className="text-[10px] line-through opacity-80">₹{c.cat_mrp}</Badge>
                      )}
                    </div>
                  ) : c.pricing === "free" ? (
                    <Badge className="absolute top-3 right-3 bg-success text-success-foreground hover:bg-success/90 shadow-md">Free</Badge>
                  ) : c.pricing === "paid" ? (
                    <Badge className="absolute top-3 right-3 bg-primary text-primary-foreground hover:bg-primary/90 shadow-md gap-0.5">
                      <IndianRupee className="h-3 w-3" />{c.min_price}+
                    </Badge>
                  ) : (
                    <Badge className="absolute top-3 right-3 bg-card/80 text-foreground hover:bg-card/80 backdrop-blur shadow-md">
                      Free + Paid
                    </Badge>
                  )}
                </div>
                <CardHeader>
                  <CardTitle className="text-lg leading-snug">{c.name}</CardTitle>
                  {c.description && <CardDescription className="line-clamp-2">{c.description}</CardDescription>}
                </CardHeader>
                <CardContent className="flex-1 space-y-2.5 text-sm">
                  <Stat icon={ListChecks} label={`${c.test_count} test${c.test_count === 1 ? "" : "s"}`} />
                  <Stat icon={FileQuestion} label={`${c.total_questions} total questions`} />
                  <Stat icon={Clock} label={formatMinutes(c.total_minutes)} />
                </CardContent>
                <CardFooter>
                  <Button className="w-full" size="lg" onClick={(e) => { e.stopPropagation(); navigate(`/category/${c.slug}`); }}>
                    Browse tests <ArrowRight className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
        </>}

        {/* Features strip */}
        <section className="mt-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-4 relative">
          {[
            { icon: Zap, title: "Real Exam Feel", desc: "Section-wise palette, timer & full-screen mode." },
            { icon: Globe, title: "Bilingual", desc: "Switch between English & हिंदी anytime." },
            { icon: BarChart3, title: "Deep Analytics", desc: "Per-question time & accuracy breakdowns." },
            { icon: ShieldCheck, title: "Secure & Fair", desc: "Auto-submit on back-press, anti-cheat checks." },
          ].map((f) => (
            <div key={f.title} className="p-5 rounded-xl border bg-card/70 backdrop-blur hover-glow">
              <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-3">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </section>
      </main>
      <Footer />
    </div>
  );
}

function Stat({ icon: Icon, label }: { icon: React.ComponentType<{ className?: string }>; label: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <span className="inline-flex items-center justify-center h-7 w-7 rounded-full shrink-0 bg-primary/10 text-primary">
        <Icon className="h-3.5 w-3.5" />
      </span>
      <span className="text-muted-foreground">{label}</span>
    </div>
  );
}
