import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  ChevronDown, LogOut, Menu, Trophy, User, X, BookOpen, Home as HomeIcon,
  ShieldCheck, Newspaper, Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import ThemeToggle from "@/components/ThemeToggle";
import Logo from "@/components/Logo";
import UserAvatar from "@/components/UserAvatar";
import { useAuth } from "@/contexts/AuthContext";

const navLinks = [
  { to: "/", label: "Home", icon: HomeIcon },
  { to: "/exam-categories", label: "Exams", icon: BookOpen },
  { to: "/free-mock-tests", label: "Mock Tests", icon: Sparkles },
  { to: "/daily-quiz", label: "Daily Quiz", icon: Trophy },
  { to: "/blog", label: "Blog", icon: Newspaper },
];

export default function SiteHeader() {
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const [open, setOpen] = useState(false);

  return (
    <header className="border-b border-red-500/20 bg-gradient-to-r from-background via-card to-background backdrop-blur-xl sticky top-0 z-30 shadow-sm">
      <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-red-500 via-rose-500 to-orange-500" />
      <div className="container flex h-16 items-center justify-between gap-2">
        <div className="flex items-center gap-6 min-w-0">
          <Logo />
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="px-3 py-1.5 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-red-500/10 transition-colors inline-flex items-center gap-1.5"
              >
                <l.icon className="h-3.5 w-3.5" />
                {l.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-1">
          <div className="hidden sm:flex items-center gap-1">
            <ThemeToggle />
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link to="/admin/login"><ShieldCheck className="h-3.5 w-3.5" /> Admin</Link>
            </Button>
          </div>

          {user && profile ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2 pl-1.5">
                  <UserAvatar url={profile.avatar_url} name={profile.name} size="sm" />
                  <span className="hidden sm:inline max-w-[100px] truncate">{profile.name}</span>
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuLabel className="truncate">{profile.name}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild><Link to="/my-tests"><Trophy className="h-4 w-4" /> My Tests</Link></DropdownMenuItem>
                <DropdownMenuItem asChild><Link to="/profile"><User className="h-4 w-4" /> Profile</Link></DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="sm:hidden" asChild><Link to="/admin/login"><ShieldCheck className="h-4 w-4" /> Admin</Link></DropdownMenuItem>
                <DropdownMenuItem onClick={async () => { await signOut(); navigate("/"); }}>
                  <LogOut className="h-4 w-4" /> Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex"><Link to="/login">Login</Link></Button>
              <Button asChild size="sm" className="bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white shadow-md shadow-red-900/20"><Link to="/signup">Sign up</Link></Button>
            </>
          )}

          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden border-t bg-card/95 backdrop-blur-xl">
          <nav className="container py-3 flex flex-col gap-1">
            {navLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="px-3 py-2.5 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-red-500/10 inline-flex items-center gap-2"
              >
                <l.icon className="h-4 w-4" />
                {l.label}
              </Link>
            ))}
            <div className="flex items-center justify-between pt-2 mt-1 border-t">
              <div className="flex items-center gap-1">
                <ThemeToggle />
                <span className="text-xs text-muted-foreground">Theme</span>
              </div>
              <Button asChild variant="ghost" size="sm" className="text-xs">
                <Link to="/admin/login" onClick={() => setOpen(false)}>
                  <ShieldCheck className="h-3.5 w-3.5" /> Admin
                </Link>
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
