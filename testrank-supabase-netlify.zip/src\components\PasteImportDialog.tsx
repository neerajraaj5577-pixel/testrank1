import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Loader2, AlertCircle, Sparkles } from "lucide-react";
import { parseAnswerKey, parseQuestionsText, ParsedTextQuestion } from "@/lib/answer-key-parser";
import { supabase } from "@/integrations/supabase/client";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  testId: string;
  startOrderIndex: number;
  onImported: () => void;
};

export default function PasteImportDialog({ open, onOpenChange, testId, startOrderIndex, onImported }: Props) {
  const [text, setText] = useState("");
  const [keyText, setKeyText] = useState("");
  const [parsed, setParsed] = useState<ParsedTextQuestion[] | null>(null);
  const [importing, setImporting] = useState(false);

  const reset = () => { setText(""); setKeyText(""); setParsed(null); setImporting(false); };
  const handleClose = (next: boolean) => { if (!next) reset(); onOpenChange(next); };

  const extract = () => {
    if (!text.trim()) { toast({ title: "Paste your questions", variant: "destructive" }); return; }
    const key = parseAnswerKey(keyText);
    const qs = parseQuestionsText(text, key);
    if (qs.length === 0) {
      toast({ title: "No questions found", description: "Make sure each question starts with '1.' or '1)' and options like 'a)' 'b)'.", variant: "destructive" });
      return;
    }
    setParsed(qs);
    toast({ title: `Extracted ${qs.length} questions`, description: "Review below and import." });
  };

  const update = (idx: number, patch: Partial<ParsedTextQuestion>) => {
    setParsed((prev) => prev ? prev.map((q, i) => i === idx ? { ...q, ...patch } : q) : prev);
  };
  const remove = (idx: number) => setParsed((prev) => prev ? prev.filter((_, i) => i !== idx) : prev);

  const doImport = async () => {
    if (!parsed?.length) return;
    setImporting(true);
    const rows = parsed.map((q, i) => ({
      test_id: testId,
      question: q.question,
      option_a: q.option_a,
      option_b: q.option_b,
      option_c: q.option_c,
      option_d: q.option_d,
      correct_answer: q.correct_answer,
      order_index: startOrderIndex + i,
      explanation: q.explanation || null,
    }));
    const { error } = await supabase.from("questions").insert(rows);
    setImporting(false);
    if (error) { toast({ title: "Import failed", description: error.message, variant: "destructive" }); return; }
    toast({ title: `Imported ${rows.length} questions` });
    onImported();
    handleClose(false);
  };

  const missing = parsed?.filter((q) => !q._hasKey).length ?? 0;
  const sample = `1. What is the capital of India?\na) Mumbai\nb) Delhi\nc) Kolkata\nd) Chennai\nAns: B\nExplanation: Delhi has been the capital since 1911.\n\n2. 2 + 2 = ?\na) 3\nb) 4\nc) 5\nd) 6\nAns: b`;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-primary" /> Paste Questions</DialogTitle>
          <DialogDescription>
            Paste your MCQs as plain text. Optionally paste a separate answer key. We'll auto-extract.
          </DialogDescription>
        </DialogHeader>

        {!parsed && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Questions (paste text)</Label>
              <Textarea rows={14} value={text} onChange={(e) => setText(e.target.value)} placeholder={sample} className="font-mono text-xs" />
              <p className="text-xs text-muted-foreground">
                Format: each question starts with <code>1.</code> or <code>1)</code>, options as <code>a) b) c) d)</code>, optional <code>Ans: B</code> and <code>Explanation:</code>.
              </p>
            </div>
            <div className="space-y-2">
              <Label>Answer Key (optional)</Label>
              <Textarea rows={3} value={keyText} onChange={(e) => setKeyText(e.target.value)} placeholder="1 a, 2 b, 3 c, 4 d" />
              <p className="text-xs text-muted-foreground">Use this if your text doesn't have inline "Ans:" lines.</p>
            </div>
          </div>
        )}

        {parsed && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">{parsed.length} questions extracted</span>
              {missing > 0 && (
                <span className="flex items-center gap-1 text-warning">
                  <AlertCircle className="h-3.5 w-3.5" /> {missing} missing answer (defaulted to A)
                </span>
              )}
            </div>
            <div className="space-y-3 max-h-[55vh] overflow-y-auto pr-1">
              {parsed.map((q, idx) => (
                <div key={idx} className={`border rounded-md p-3 space-y-2 ${!q._hasKey ? "border-warning/50 bg-warning/5" : ""}`}>
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-primary text-sm">Q{idx + 1}.</span>
                    <Textarea value={q.question} onChange={(e) => update(idx, { question: e.target.value })} rows={2} className="flex-1 text-sm" />
                    <Button variant="ghost" size="sm" onClick={() => remove(idx)}>Remove</Button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 pl-6">
                    {(["a","b","c","d"] as const).map((opt) => (
                      <div key={opt} className="flex items-center gap-1">
                        <span className="text-xs font-medium uppercase w-4">{opt}.</span>
                        <Input value={(q as any)[`option_${opt}`] ?? ""} onChange={(e) => update(idx, { [`option_${opt}`]: e.target.value } as any)} className="text-sm h-8" />
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center gap-2 pl-6 flex-wrap">
                    <Label className="text-xs">Correct:</Label>
                    <Select value={q.correct_answer} onValueChange={(v) => update(idx, { correct_answer: v as any, _hasKey: true })}>
                      <SelectTrigger className="h-8 w-20 text-sm"><SelectValue /></SelectTrigger>
                      <SelectContent>{(["A","B","C","D"] as const).map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                    </Select>
                    <Input
                      placeholder="Explanation (optional)"
                      value={q.explanation ?? ""}
                      onChange={(e) => update(idx, { explanation: e.target.value })}
                      className="h-8 text-xs flex-1 min-w-[200px]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <DialogFooter>
          {!parsed ? (
            <>
              <Button variant="outline" onClick={() => handleClose(false)}>Cancel</Button>
              <Button onClick={extract} disabled={!text.trim()}><Sparkles className="h-4 w-4" /> Extract Questions</Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setParsed(null)} disabled={importing}>Back</Button>
              <Button onClick={doImport} disabled={importing || !parsed.length}>
                {importing ? <><Loader2 className="h-4 w-4 animate-spin" /> Importing…</> : <>Import {parsed.length} Questions</>}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
