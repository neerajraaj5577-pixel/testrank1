import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, IndianRupee, Loader2, ShieldCheck } from "lucide-react";
import { getOrCreateStudent, setStoredStudentId } from "@/lib/student";

type Test = { id: string; name: string; price: number | null; is_paid: boolean };

declare global {
  interface Window {
    Razorpay: any;
  }
}

function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof window === "undefined") return resolve(false);
    if (window.Razorpay) return resolve(true);
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export default function StudentPay() {
  const { id: testId } = useParams();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [studentId, setStudentId] = useState<string | null>(
    testId ? sessionStorage.getItem(`tb_student_${testId}`) : null,
  );

  const [test, setTest] = useState<Test | null>(null);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState(false);
  const [studentName, setStudentName] = useState("");
  const [studentMobile, setStudentMobile] = useState("");

  useEffect(() => {
    if (!testId || !user || !profile) {
      return;
    }
    (async () => {
      let resolvedStudentId = studentId;
      if (!resolvedStudentId) {
        const student = await getOrCreateStudent({
          name: profile.name,
          mobile: profile.mobile,
          district: profile.district,
        });
        resolvedStudentId = student.id;
        setStoredStudentId(testId, student.id);
        setStudentId(student.id);
      }
      const [{ data: t }, { data: s }] = await Promise.all([
        supabase.from("tests").select("id, name, price, is_paid").eq("id", testId).maybeSingle(),
        supabase.from("students").select("name, mobile").eq("id", resolvedStudentId).maybeSingle(),
      ]);
      setTest(t as Test | null);
      if (s) {
        setStudentName((s as any).name ?? "");
        setStudentMobile((s as any).mobile ?? "");
      }
      setLoading(false);
    })();
    loadRazorpayScript();
  }, [testId, studentId, user, profile]);

  const amount = Number(test?.price ?? 0);

  const startPayment = async () => {
    if (!testId || !studentId || !test) return;
    setPaying(true);
    try {
      const ok = await loadRazorpayScript();
      if (!ok) throw new Error("Failed to load payment gateway");

      const { data: orderData, error: orderErr } = await supabase.functions.invoke(
        "razorpay-create-order",
        {
          body: {
            amount: Math.round(amount * 100),
            currency: "INR",
            receipt: `test_${testId.slice(0, 8)}_${Date.now()}`,
            notes: { test_id: testId, student_id: studentId },
          },
        },
      );
      if (orderErr || !orderData?.order_id) throw new Error(orderErr?.message || "Could not create order");

      // Persist a pending payment row
      const insertRow: any = {
        test_id: testId,
        student_id: studentId,
        amount,
        razorpay_order_id: orderData.order_id,
        status: "created",
      };
      if (user) insertRow.user_id = user.id;
      const { data: paymentRow, error: insertErr } = await supabase
        .from("test_payments")
        .insert(insertRow)
        .select("id")
        .single();
      if (insertErr) throw insertErr;

      const options = {
        key: orderData.key_id,
        amount: orderData.amount,
        currency: orderData.currency,
        name: "TestNexa",
        description: test.name,
        order_id: orderData.order_id,
        prefill: { name: studentName, contact: studentMobile, email: user?.email ?? "" },
        theme: { color: "#0ea5e9" },
        handler: async (resp: any) => {
          try {
            const { data: vData, error: vErr } = await supabase.functions.invoke(
              "razorpay-verify-payment",
              {
                body: {
                  razorpay_order_id: resp.razorpay_order_id,
                  razorpay_payment_id: resp.razorpay_payment_id,
                  razorpay_signature: resp.razorpay_signature,
                  payment_row_id: paymentRow.id,
                },
              },
            );
            if (vErr || !vData?.success) throw new Error(vErr?.message || "Verification failed");
            toast({ title: "Payment successful", description: "Redirecting…" });
            navigate(`/test/${testId}/instructions`, { replace: true });
          } catch (e: any) {
            toast({ title: "Verification failed", description: e.message, variant: "destructive" });
          }
        },
        modal: {
          ondismiss: () => {
            setPaying(false);
            toast({ title: "Payment cancelled" });
          },
        },
      };
      const rzp = new window.Razorpay(options);
      rzp.on("payment.failed", (resp: any) => {
        toast({
          title: "Payment failed",
          description: resp?.error?.description || "Try again",
          variant: "destructive",
        });
        setPaying(false);
      });
      rzp.open();
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
      setPaying(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!test || !test.is_paid || !test.price) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md">
          <CardContent className="py-10 text-center space-y-3">
            <p className="text-muted-foreground">This test does not require payment.</p>
            <Button asChild>
              <Link to={`/test/${testId}/instructions`}>Continue</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-subtle p-4">
      <div className="max-w-md mx-auto space-y-3 py-4">
        <Button asChild variant="ghost" size="sm">
          <Link to={`/test/${testId}/instructions`}>
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
        </Button>

        <Card className="shadow-elegant">
          <CardHeader className="text-center">
            <Badge variant="secondary" className="mx-auto w-fit">{test.name}</Badge>
            <CardTitle className="flex items-center justify-center gap-1 text-3xl mt-2">
              <IndianRupee className="h-7 w-7" /> {amount}
            </CardTitle>
            <CardDescription>Secure payment via Razorpay</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg border bg-muted/30 p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Test</span>
                <span className="font-medium">{test.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-semibold">₹ {amount}</span>
              </div>
            </div>

            <Button onClick={startPayment} disabled={paying} className="w-full" size="lg">
              {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
              Pay ₹{amount} with Razorpay
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              You'll be redirected to Razorpay's secure payment window. Cards, UPI, NetBanking and wallets are supported there.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
