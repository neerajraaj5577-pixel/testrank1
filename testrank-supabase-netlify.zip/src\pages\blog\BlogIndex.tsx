import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar } from "lucide-react";
import Footer from "@/components/Footer";
import SiteHeader from "@/components/SiteHeader";
import SEO, { breadcrumbSchema } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";

type Post = {
  id: string; slug: string; title: string; excerpt: string | null;
  cover_image: string | null; tags: string[] | null; published_at: string | null;
};

export default function BlogIndex() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("blog_posts")
        .select("id,slug,title,excerpt,cover_image,tags,published_at")
        .eq("is_published", true)
        .order("published_at", { ascending: false });
      setPosts((data ?? []) as any);
      setLoading(false);
    })();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col">
      <SEO
        title="Competitive Exam Blog – Tips, Strategy & Updates | TestNexa"
        description="Read expert articles on SSC, Banking, Railway, UPSC and State exam preparation. Strategy, current affairs and practice tips, updated regularly."
        path="/blog"
        keywords="competitive exam blog, exam preparation blog, SSC tips, banking tips, UPSC strategy"
        jsonLd={breadcrumbSchema([{ name: "Blog", path: "/blog" }])}
      />
      <SiteHeader />
      <main className="container max-w-5xl py-10 flex-1">
        <Breadcrumbs items={[{ name: "Blog", path: "/blog" }]} />
        <h1 className="text-3xl md:text-4xl font-bold mb-2">TestNexa Blog</h1>
        <p className="text-muted-foreground mb-8">Strategy, tips and updates for competitive exam aspirants.</p>

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[1, 2, 3, 4, 5, 6].map((i) => <Skeleton key={i} className="h-72" />)}
          </div>
        ) : posts.length === 0 ? (
          <p className="text-muted-foreground">No posts yet. Check back soon.</p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {posts.map((p) => (
              <Link key={p.id} to={`/blog/${p.slug}`}>
                <Card className="h-full flex flex-col hover-glow">
                  <CardHeader>
                    <CardTitle className="text-lg leading-snug line-clamp-2">{p.title}</CardTitle>
                    {p.excerpt && <CardDescription className="line-clamp-3">{p.excerpt}</CardDescription>}
                  </CardHeader>
                  <CardFooter className="flex items-center justify-between text-xs text-muted-foreground mt-auto">
                    <span className="inline-flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      {p.published_at ? new Date(p.published_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : ""}
                    </span>
                    <span className="text-primary inline-flex items-center gap-1 font-medium">Read <ArrowRight className="h-3.5 w-3.5" /></span>
                  </CardFooter>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
