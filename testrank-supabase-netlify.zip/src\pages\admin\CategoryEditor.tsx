import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, ImagePlus, Loader2, X } from "lucide-react";

function slugify(s: string) {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

export default function CategoryEditor() {
  const { id } = useParams();
  const isNew = !id;
  const navigate = useNavigate();
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);

  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [slugTouched, setSlugTouched] = useState(false);
  const [description, setDescription] = useState("");
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
  const [thumbUploading, setThumbUploading] = useState(false);
  const [position, setPosition] = useState(0);
  const [isActive, setIsActive] = useState(true);
  const [isPaid, setIsPaid] = useState(false);
  const [price, setPrice] = useState<number>(199);
  const [mrp, setMrp] = useState<number>(499);
  const fileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isNew) return;
    (async () => {
      const { data } = await supabase.from("categories").select("*").eq("id", id!).single();
      if (data) {
        setName(data.name);
        setSlug(data.slug);
        setDescription(data.description ?? "");
        setThumbnailUrl(data.thumbnail_url);
        setPosition(data.position);
        setIsActive(data.is_active);
        setIsPaid(!!(data as any).is_paid);
        if ((data as any).price != null) setPrice(Number((data as any).price));
        if ((data as any).mrp != null) setMrp(Number((data as any).mrp));
        setSlugTouched(true);
      }
      setLoading(false);
    })();
  }, [id, isNew]);

  useEffect(() => {
    if (!slugTouched) setSlug(slugify(name));
  }, [name, slugTouched]);

  const uploadThumb = async (file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      toast({ title: "Image too large", description: "Max 2MB", variant: "destructive" });
      return;
    }
    setThumbUploading(true);
    const ext = file.name.split(".").pop() || "png";
    const path = `categories/${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("question-images").upload(path, file, { upsert: true });
    if (upErr) {
      setThumbUploading(false);
      toast({ title: "Upload failed", description: upErr.message, variant: "destructive" });
      return;
    }
    const { data: pub } = supabase.storage.from("question-images").getPublicUrl(path);
    setThumbnailUrl(pub.publicUrl);
    setThumbUploading(false);
  };

  const save = async () => {
    if (!name.trim()) return toast({ title: "Name required", variant: "destructive" });
    const finalSlug = slugify(slug || name);
    if (!finalSlug) return toast({ title: "Slug required", variant: "destructive" });
    setSaving(true);
    const payload = {
      name: name.trim(),
      slug: finalSlug,
      description: description.trim() || null,
      thumbnail_url: thumbnailUrl,
      position: Number.isFinite(position) ? position : 0,
      is_active: isActive,
      is_paid: isPaid,
      price: isPaid ? Math.round(price) : null,
      mrp: isPaid ? Math.round(mrp) : null,
    };
    const { error } = isNew
      ? await supabase.from("categories").insert(payload)
      : await supabase.from("categories").update(payload).eq("id", id!);
    setSaving(false);
    if (error) {
      const msg = error.message.includes("duplicate") || error.message.includes("unique")
        ? "Slug already in use — pick a different one."
        : error.message;
      return toast({ title: "Error", description: msg, variant: "destructive" });
    }
    toast({ title: isNew ? "Category created" : "Category saved" });
    navigate("/admin/categories");
  };

  if (loading) return <div className="p-8 text-muted-foreground">Loading…</div>;

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate("/admin/categories")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">{isNew ? "New Category" : "Edit Category"}</h1>
      </div>

      <Card>
        <CardHeader><CardTitle>Details</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid sm:grid-cols-3 gap-4">
            <div className="space-y-2 sm:col-span-1">
              <Label>Thumbnail</Label>
              {thumbnailUrl ? (
                <div className="relative aspect-video w-full rounded-md overflow-hidden border bg-muted">
                  <img src={thumbnailUrl} alt="thumb" className="w-full h-full object-cover" />
                  <Button
                    type="button" variant="secondary" size="icon"
                    className="absolute top-1 right-1 h-7 w-7"
                    onClick={() => setThumbnailUrl(null)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="aspect-video w-full rounded-md border-2 border-dashed flex flex-col items-center justify-center text-muted-foreground hover:bg-accent transition-colors"
                  disabled={thumbUploading}
                >
                  {thumbUploading ? <Loader2 className="h-5 w-5 animate-spin" /> : (
                    <>
                      <ImagePlus className="h-5 w-5 mb-1" />
                      <span className="text-xs">Upload</span>
                    </>
                  )}
                </button>
              )}
              <input
                ref={fileRef} type="file" accept="image/*" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadThumb(f); e.target.value = ""; }}
              />
            </div>
            <div className="space-y-4 sm:col-span-2">
              <div className="space-y-2">
                <Label>Name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. SSC CGL" />
              </div>
              <div className="space-y-2">
                <Label>Slug (URL)</Label>
                <Input
                  value={slug}
                  onChange={(e) => { setSlug(e.target.value); setSlugTouched(true); }}
                  placeholder="ssc-cgl"
                />
                <p className="text-xs text-muted-foreground">Will appear as /category/{slug || "your-slug"}</p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Description (optional)</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="Short description shown on the category card" />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Display position</Label>
              <Input type="number" value={position} onChange={(e) => setPosition(Number(e.target.value))} />
              <p className="text-xs text-muted-foreground">Lower values appear first.</p>
            </div>
            <div className="space-y-2">
              <Label>Visibility</Label>
              <div className="flex items-center gap-3 h-10">
                <Switch checked={isActive} onCheckedChange={setIsActive} />
                <span className="text-sm text-muted-foreground">{isActive ? "Visible on home" : "Hidden"}</span>
              </div>
            </div>
          </div>

          <div className="space-y-3 border-t pt-4">
            <div className="flex items-center gap-3">
              <Switch checked={isPaid} onCheckedChange={setIsPaid} />
              <Label>Paid category (unlocks all tests inside)</Label>
            </div>
            {isPaid && (
              <div className="grid sm:grid-cols-2 gap-3 max-w-md">
                <div className="space-y-1">
                  <Label className="text-xs">MRP (₹)</Label>
                  <Input type="number" min={1} value={mrp} onChange={(e) => setMrp(Number(e.target.value))} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Selling price (₹)</Label>
                  <Input type="number" min={1} value={price} onChange={(e) => setPrice(Number(e.target.value))} />
                </div>
                {mrp > price && price > 0 && (
                  <p className="text-xs text-success sm:col-span-2">
                    {Math.round(((mrp - price) / mrp) * 100)}% off — students will see ₹{price} with ₹{mrp} struck through.
                  </p>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => navigate("/admin/categories")}>Cancel</Button>
        <Button onClick={save} disabled={saving}>
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
          {isNew ? "Create" : "Save"}
        </Button>
      </div>
    </div>
  );
}
