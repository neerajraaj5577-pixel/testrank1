import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Users, Trophy, TrendingUp } from "lucide-react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "@/lib/format";

export default function AdminDashboard() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ tests: 0, attempts: 0, avgScore: 0 });
  const [recent, setRecent] = useState<any[]>([]);
  const [chart, setChart] = useState<{ name: string; attempts: number }[]>([]);

  useEffect(() => {
    (async () => {
      const [{ count: testsCount }, { data: results }, { data: tests }] = await Promise.all([
        supabase.from("tests").select("*", { count: "exact", head: true }),
        supabase
          .from("results")
          .select("id, score, submitted_at, test_id, student_id, students(name), tests(name)")
          .order("submitted_at", { ascending: false })
          .limit(50),
        supabase.from("tests").select("id, name"),
      ]);

      const all = results ?? [];
      const avg = all.length ? all.reduce((s, r) => s + Number(r.score || 0), 0) / all.length : 0;
      setStats({ tests: testsCount ?? 0, attempts: all.length, avgScore: Math.round(avg * 100) / 100 });
      setRecent(all.slice(0, 8));

      const counts = new Map<string, number>();
      all.forEach((r: any) => counts.set(r.test_id, (counts.get(r.test_id) ?? 0) + 1));
      setChart(
        (tests ?? []).map((t) => ({ name: t.name.length > 16 ? t.name.slice(0, 14) + "…" : t.name, attempts: counts.get(t.id) ?? 0 })),
      );
      setLoading(false);
    })();
  }, []);

  const cards = [
    { label: "Total Tests", value: stats.tests, icon: FileText, gradient: "from-red-500 to-rose-600", bg: "from-red-500/10 to-rose-500/5", iconBg: "bg-red-500/15 text-red-600 dark:text-red-400" },
    { label: "Total Attempts", value: stats.attempts, icon: Users, gradient: "from-blue-500 to-indigo-600", bg: "from-blue-500/10 to-indigo-500/5", iconBg: "bg-blue-500/15 text-blue-600 dark:text-blue-400" },
    { label: "Average Score", value: stats.avgScore, icon: Trophy, gradient: "from-amber-500 to-orange-600", bg: "from-amber-500/10 to-orange-500/5", iconBg: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
    { label: "Engagement", value: stats.attempts > 0 ? "Active" : "—", icon: TrendingUp, gradient: "from-emerald-500 to-teal-600", bg: "from-emerald-500/10 to-teal-500/5", iconBg: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  ];

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-red-600 via-rose-600 to-orange-600 p-6 md:p-8 text-white shadow-lg">
        <div className="absolute -top-12 -right-12 h-48 w-48 rounded-full bg-white/10 blur-2xl" />
        <div className="relative">
          <h1 className="text-3xl md:text-4xl font-extrabold">Dashboard</h1>
          <p className="text-white/90 mt-1">Welcome back — here's what's happening on TestNexa.</p>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label} className={`relative overflow-hidden bg-gradient-to-br ${c.bg} border-2 hover:shadow-lg transition-shadow`}>
            <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${c.gradient}`} />
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{c.label}</CardTitle>
              <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${c.iconBg}`}>
                <c.icon className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-extrabold bg-gradient-to-r ${c.gradient} bg-clip-text text-transparent`}>
                {loading ? <Skeleton className="h-8 w-16" /> : c.value}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Attempts per Test</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-72 w-full" />
          ) : chart.length === 0 ? (
            <p className="text-sm text-muted-foreground py-12 text-center">No data yet.</p>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chart}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} allowDecimals={false} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                <Bar dataKey="attempts" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Attempts</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-40 w-full" />
          ) : recent.length === 0 ? (
            <p className="text-sm text-muted-foreground py-8 text-center">No attempts yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Test</TableHead>
                  <TableHead className="text-right">Score</TableHead>
                  <TableHead className="hidden sm:table-cell">When</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recent.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.students?.name ?? "—"}</TableCell>
                    <TableCell>{r.tests?.name ?? "—"}</TableCell>
                    <TableCell className="text-right">{r.score}</TableCell>
                    <TableCell className="hidden sm:table-cell text-muted-foreground text-sm">
                      {format.dateTime(r.submitted_at)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
