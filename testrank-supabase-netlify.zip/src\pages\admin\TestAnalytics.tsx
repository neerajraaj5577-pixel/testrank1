import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import { ArrowLeft, Trophy } from "lucide-react";
import { format } from "@/lib/format";

export default function TestAnalytics() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [test, setTest] = useState<any>(null);
  const [results, setResults] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const [{ data: t }, { data: rs }] = await Promise.all([
        supabase.from("tests").select("*").eq("id", id!).single(),
        supabase
          .from("results")
          .select("*, students(name, mobile, district)")
          .eq("test_id", id!)
          .order("score", { ascending: false }),
      ]);
      setTest(t);
      setResults(rs ?? []);
    })();
  }, [id]);

  if (!test) return <p className="text-muted-foreground">Loading…</p>;

  // Score distribution buckets
  const max = Number(test.marks_per_question) * Number(test.total_questions);
  const buckets = [
    { range: "0-20%", min: 0, max: 0.2 },
    { range: "20-40%", min: 0.2, max: 0.4 },
    { range: "40-60%", min: 0.4, max: 0.6 },
    { range: "60-80%", min: 0.6, max: 0.8 },
    { range: "80-100%", min: 0.8, max: 1.01 },
  ];
  const dist = buckets.map((b) => ({
    range: b.range,
    count: results.filter((r) => {
      const pct = max > 0 ? Number(r.score) / max : 0;
      return pct >= b.min && pct < b.max;
    }).length,
  }));

  const top = results.slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate("/admin/tests")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">{test.name}</h1>
          <p className="text-sm text-muted-foreground">Analytics — {results.length} attempts</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Score Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            {results.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No attempts yet.</p>
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={dist}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="range" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }}
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-warning" /> Top Performers
            </CardTitle>
          </CardHeader>
          <CardContent>
            {top.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No attempts yet.</p>
            ) : (
              <ol className="space-y-2">
                {top.map((r, i) => (
                  <li key={r.id} className="flex justify-between items-center p-2 rounded bg-muted/50">
                    <span>
                      <span className="font-bold mr-2">#{i + 1}</span>
                      {r.students?.name}
                    </span>
                    <span className="font-bold text-primary">{r.score}</span>
                  </li>
                ))}
              </ol>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Attempts</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead className="hidden sm:table-cell">Mobile</TableHead>
                <TableHead className="hidden md:table-cell">District</TableHead>
                <TableHead className="text-right">Score</TableHead>
                <TableHead className="hidden sm:table-cell text-right">Time</TableHead>
                <TableHead className="hidden md:table-cell">When</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {results.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                    No attempts yet.
                  </TableCell>
                </TableRow>
              ) : (
                results.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.students?.name}</TableCell>
                    <TableCell className="hidden sm:table-cell">{r.students?.mobile}</TableCell>
                    <TableCell className="hidden md:table-cell">{r.students?.district}</TableCell>
                    <TableCell className="text-right font-bold">{r.score}</TableCell>
                    <TableCell className="hidden sm:table-cell text-right">{format.duration(r.time_taken_seconds)}</TableCell>
                    <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                      {format.dateTime(r.submitted_at)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
