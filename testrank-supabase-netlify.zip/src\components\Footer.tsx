import { Link } from "react-router-dom";
import logo from "@/assets/logo.png";
import { Mail, Shield, FileText, Instagram, Youtube, Twitter, Sparkles } from "lucide-react";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="relative mt-20 overflow-hidden border-t border-red-500/20 bg-gradient-to-br from-background via-card to-background">
      {/* Decorative glows */}
      <div className="pointer-events-none absolute -top-32 left-1/4 h-64 w-64 rounded-full bg-red-600/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 right-1/4 h-64 w-64 rounded-full bg-rose-600/10 blur-3xl" />
      <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-red-500 via-rose-500 to-orange-500" />

      <div className="container relative py-12 grid gap-10 md:grid-cols-3">
        <div className="space-y-4">
          <img src={logo} alt="TestNexa" className="h-12 w-auto" />
          <p className="text-sm text-muted-foreground leading-relaxed max-w-xs">
            <span className="font-semibold text-foreground">Test Smart. Crack Faster.</span><br />
            India's modern mock test platform for competitive exams.
          </p>
          <div className="flex gap-2 pt-1">
            {[
              { Icon: Twitter, color: "hover:bg-sky-500" },
              { Icon: Instagram, color: "hover:bg-pink-500" },
              { Icon: Youtube, color: "hover:bg-red-600" },
            ].map(({ Icon, color }, i) => (
              <a
                key={i}
                href="#"
                aria-label="social"
                className={`h-9 w-9 inline-flex items-center justify-center rounded-full bg-muted text-muted-foreground hover:text-white transition-all ${color}`}
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-bold mb-4 text-sm uppercase tracking-wider bg-gradient-to-r from-red-500 to-rose-500 bg-clip-text text-transparent inline-flex items-center gap-1.5">
            <Sparkles className="h-3.5 w-3.5 text-red-500" /> Company
          </h4>
          <ul className="space-y-2.5 text-sm text-muted-foreground">
            <li><Link to="/about" className="hover:text-red-500 transition-colors">About Us</Link></li>
            <li><Link to="/contact" className="hover:text-red-500 transition-colors">Contact</Link></li>
            <li><Link to="/blog" className="hover:text-red-500 transition-colors">Blog</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold mb-4 text-sm uppercase tracking-wider bg-gradient-to-r from-red-500 to-rose-500 bg-clip-text text-transparent inline-flex items-center gap-1.5">
            <Shield className="h-3.5 w-3.5 text-red-500" /> Legal & Support
          </h4>
          <ul className="space-y-2.5 text-sm text-muted-foreground">
            <li><Link to="/privacy" className="hover:text-red-500 transition-colors inline-flex items-center gap-1.5"><Shield className="h-3.5 w-3.5" /> Privacy Policy</Link></li>
            <li><Link to="/terms" className="hover:text-red-500 transition-colors inline-flex items-center gap-1.5"><FileText className="h-3.5 w-3.5" /> Terms of Service</Link></li>
            <li><a href="mailto:support@testnexa.com" className="hover:text-red-500 transition-colors inline-flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" /> support@testnexa.com</a></li>
          </ul>
        </div>
      </div>

      <div className="relative border-t border-red-500/10 bg-card/40 backdrop-blur">
        <div className="container py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <p>© {year} <span className="font-semibold text-foreground">TestNexa</span>. All rights reserved.</p>
          <p>Made with <span className="text-red-500">❤</span> in India</p>
        </div>
      </div>
    </footer>
  );
}
