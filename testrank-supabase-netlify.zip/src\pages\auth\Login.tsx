import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { mobileToEmail } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Home } from "lucide-react";

const schema = z.object({
  mobile: z.string().trim().regex(/^\d{7,15}$/, "Enter a valid mobile (digits only)"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export default function Login() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const redirect = params.get("redirect") || "/";
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({ mobile, password });
    if (!parsed.success) {
      toast({ title: "Invalid input", description: parsed.error.issues[0].message, variant: "destructive" });
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.auth.signInWithPassword({
      email: mobileToEmail(parsed.data.mobile),
      password: parsed.data.password,
    });
    setSubmitting(false);
    if (error) {
      toast({ title: "Login failed", description: "Wrong mobile or password", variant: "destructive" });
      return;
    }
    toast({ title: "Welcome back!" });
    navigate(redirect, { replace: true });
  };

  return (
    <div className="min-h-screen bg-gradient-subtle flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-3">
        <div className="flex justify-start">
          <Button asChild variant="ghost" size="sm">
            <Link to="/"><Home className="h-4 w-4" /> Back to Home</Link>
          </Button>
        </div>
        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle>Login</CardTitle>
            <CardDescription>Enter your mobile number and password to continue.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Mobile Number</Label>
                <Input
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, ""))}
                  inputMode="tel"
                  maxLength={15}
                  placeholder="10-digit mobile"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Password</Label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Default = your DOB as DDMMYYYY"
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Default password is your date of birth in <b>DDMMYYYY</b> format.
                </p>
              </div>
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? "Logging in…" : "Login"}
              </Button>
              <p className="text-sm text-center text-muted-foreground">
                Don't have an account?{" "}
                <Link to="/signup" className="text-primary font-medium">Sign up</Link>
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
