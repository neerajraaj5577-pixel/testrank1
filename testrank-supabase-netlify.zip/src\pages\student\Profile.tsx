import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Home, LogOut, Loader2, Camera, X } from "lucide-react";
import UserAvatar from "@/components/UserAvatar";
import SiteHeader from "@/components/SiteHeader";
import Footer from "@/components/Footer";

const EXAMS = ["SSC", "Banking", "Railways", "UPSC", "State PSC", "NEET", "JEE", "Other"];

export default function Profile() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile, signOut } = useAuth();
  const [name, setName] = useState("");
  const [district, setDistrict] = useState("");
  const [exam, setExam] = useState("");
  const [saving, setSaving] = useState(false);
  const [newPwd, setNewPwd] = useState("");
  const [pwdSaving, setPwdSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (profile) {
      setName(profile.name);
      setDistrict(profile.district);
      setExam(profile.exam ?? "");
    }
  }, [profile]);

  const uploadAvatar = async (file: File) => {
    if (!user) return;
    if (file.size > 3 * 1024 * 1024) {
      toast({ title: "Image too large", description: "Max 3MB", variant: "destructive" });
      return;
    }
    setUploading(true);
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${user.id}/${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("avatars").upload(path, file, { upsert: true });
    if (upErr) {
      setUploading(false);
      toast({ title: "Upload failed", description: upErr.message, variant: "destructive" });
      return;
    }
    const { data: pub } = supabase.storage.from("avatars").getPublicUrl(path);
    const url = pub.publicUrl;
    const { error } = await supabase.from("student_profiles").update({ avatar_url: url }).eq("user_id", user.id);
    setUploading(false);
    if (error) { toast({ title: "Update failed", description: error.message, variant: "destructive" }); return; }
    await refreshProfile();
    toast({ title: "Profile picture updated" });
  };

  const removeAvatar = async () => {
    if (!user) return;
    await supabase.from("student_profiles").update({ avatar_url: null }).eq("user_id", user.id);
    await refreshProfile();
  };

  const save = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from("student_profiles")
      .update({ name, district, exam })
      .eq("user_id", user.id);
    setSaving(false);
    if (error) { toast({ title: "Save failed", description: error.message, variant: "destructive" }); return; }
    await refreshProfile();
    toast({ title: "Profile updated" });
  };

  const changePassword = async () => {
    if (newPwd.length < 6) { toast({ title: "Password must be at least 6 characters", variant: "destructive" }); return; }
    setPwdSaving(true);
    const { error } = await supabase.auth.updateUser({ password: newPwd });
    setPwdSaving(false);
    if (error) { toast({ title: "Password change failed", description: error.message, variant: "destructive" }); return; }
    setNewPwd("");
    toast({ title: "Password changed" });
  };

  const logout = async () => { await signOut(); navigate("/", { replace: true }); };

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col">
      <SiteHeader />
      <main className="flex-1 p-4 py-10">
      <div className="max-w-2xl mx-auto space-y-5">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">My Profile</h1>
          <Button variant="outline" size="sm" onClick={logout}><LogOut className="h-4 w-4" /> Logout</Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Profile Picture</CardTitle>
            <CardDescription>Shown across the platform during tests and on your dashboard.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-5">
              <div className="relative">
                <UserAvatar url={profile?.avatar_url} name={profile?.name} size="xl" />
                {profile?.avatar_url && (
                  <button
                    onClick={removeAvatar}
                    className="absolute -top-1 -right-1 h-6 w-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                    title="Remove"
                  >
                    <X className="h-3 w-3" />
                  </button>
                )}
              </div>
              <div className="space-y-2">
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadAvatar(f); e.target.value = ""; }}
                />
                <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()} disabled={uploading}>
                  {uploading ? <><Loader2 className="h-4 w-4 animate-spin" /> Uploading…</> : <><Camera className="h-4 w-4" /> {profile?.avatar_url ? "Change picture" : "Upload picture"}</>}
                </Button>
                <p className="text-xs text-muted-foreground">JPG, PNG up to 3MB. Square photos work best.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>My Profile</CardTitle>
            <CardDescription>Mobile: {profile?.mobile}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Full Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>District</Label>
              <Input value={district} onChange={(e) => setDistrict(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Exam preparing for</Label>
              <Select value={exam} onValueChange={setExam}>
                <SelectTrigger><SelectValue placeholder="Choose exam" /></SelectTrigger>
                <SelectContent>{EXAMS.map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Change Password</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>New Password</Label>
              <Input type="password" value={newPwd} onChange={(e) => setNewPwd(e.target.value)} />
            </div>
            <Button onClick={changePassword} disabled={pwdSaving}>{pwdSaving ? "Saving…" : "Update Password"}</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>My Tests</CardTitle>
            <CardDescription>View your unlocked tests and past results.</CardDescription>
          </CardHeader>
          <CardContent className="flex gap-3">
            <Button asChild variant="outline"><Link to="/my-tests">My Tests Dashboard</Link></Button>
          </CardContent>
        </Card>
      </div>
      </main>
      <Footer />
    </div>
  );
}
