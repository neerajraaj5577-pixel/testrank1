import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

export default function UserAvatar({
  url,
  name,
  size = "md",
  className,
}: {
  url?: string | null;
  name?: string | null;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}) {
  const sizeClass =
    size === "sm" ? "h-7 w-7 text-xs" :
    size === "lg" ? "h-14 w-14 text-lg" :
    size === "xl" ? "h-24 w-24 text-2xl" :
    "h-9 w-9 text-sm";
  const initial = (name?.trim()?.[0] ?? "U").toUpperCase();
  return (
    <Avatar className={cn(sizeClass, className)}>
      {url ? <AvatarImage src={url} alt={name ?? "Avatar"} /> : null}
      <AvatarFallback className="bg-gradient-primary text-primary-foreground font-semibold">
        {initial}
      </AvatarFallback>
    </Avatar>
  );
}
