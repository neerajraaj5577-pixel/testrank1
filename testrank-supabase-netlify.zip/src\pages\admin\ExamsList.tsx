import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Edit, Trash2, Eye, EyeOff, IndianRupee } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { getExamTheme } from "@/lib/exam-themes";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader,
  AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type Row = {
  id: string; name: string; name_hi: string | null; subtitle: string | null;
  badge_label: string | null; icon_emoji: string | null; color_scheme: string;
  position: number; is_active: boolean; is_paid: boolean; price: number | null;
  test_count: number;
};

export default function AdminExamsList() {
  const navigate = useNavigate();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data: exams } = await supabase
      .from("exams" as any).select("*").order("position").order("created_at");
    const ids = (exams ?? []).map((e: any) => e.id);
    const { data: links } = ids.length
      ? await supabase.from("exam_tests" as any).select("exam_id").in("exam_id", ids)
      : { data: [] as any[] };
    const counts = new Map<string, number>();
    (links ?? []).forEach((l: any) => counts.set(l.exam_id, (counts.get(l.exam_id) ?? 0) + 1));
    setRows((exams ?? []).map((e: any) => ({ ...e, test_count: counts.get(e.id) ?? 0 })));
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const toggleActive = async (row: Row) => {
    const { error } = await (supabase.from("exams" as any) as any).update({ is_active: !row.is_active }).eq("id", row.id);
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    toast({ title: row.is_active ? "Exam hidden" : "Exam visible" });
    load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("exams" as any).delete().eq("id", id);
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    toast({ title: "Exam deleted" });
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold">Exams</h1>
          <p className="text-muted-foreground">Manage the colored exam buttons / cards on the home page.</p>
        </div>
        <Button onClick={() => navigate("/admin/exams/new")}>
          <Plus className="h-4 w-4" /> New Exam
        </Button>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16"></TableHead>
              <TableHead>Name</TableHead>
              <TableHead className="hidden md:table-cell">Badge</TableHead>
              <TableHead className="hidden sm:table-cell">Tests</TableHead>
              <TableHead className="hidden md:table-cell">Price</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : rows.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No exams yet.</TableCell></TableRow>
            ) : rows.map((r) => {
              const th = getExamTheme(r.color_scheme);
              return (
                <TableRow key={r.id}>
                  <TableCell>
                    <div className={`h-10 w-10 rounded-lg flex items-center justify-center text-xl ${th.iconBg} ${th.iconText}`}>
                      {r.icon_emoji ?? "📘"}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{r.name}</div>
                    {r.subtitle && <div className="text-xs text-muted-foreground">{r.subtitle}</div>}
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    {r.badge_label && <Badge variant="secondary">{r.badge_label}</Badge>}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">{r.test_count}</TableCell>
                  <TableCell className="hidden md:table-cell">
                    {r.is_paid && r.price ? (
                      <span className="inline-flex items-center font-medium"><IndianRupee className="h-3 w-3" />{r.price}</span>
                    ) : <span className="text-muted-foreground">Free</span>}
                  </TableCell>
                  <TableCell><Badge variant={r.is_active ? "default" : "secondary"}>{r.is_active ? "Active" : "Hidden"}</Badge></TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => toggleActive(r)} title={r.is_active ? "Hide" : "Show"}>
                        {r.is_active ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                      <Button asChild variant="ghost" size="icon" title="Edit">
                        <Link to={`/admin/exams/${r.id}/edit`}><Edit className="h-4 w-4" /></Link>
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" title="Delete">
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete this exam?</AlertDialogTitle>
                            <AlertDialogDescription>
                              The tests inside won't be deleted, only the exam grouping and unlocks.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => remove(r.id)}>Delete</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
