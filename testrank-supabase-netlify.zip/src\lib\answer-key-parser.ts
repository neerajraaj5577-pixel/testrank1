// Parses flexible answer key formats into a map of { questionNumber: "A"|"B"|"C"|"D" }
// Accepts: "1 a, 2 b", "1.A 2.B", "1) A\n2) B", "1-a 2-b", etc.
export function parseAnswerKey(input: string): Record<number, "A" | "B" | "C" | "D"> {
  const result: Record<number, "A" | "B" | "C" | "D"> = {};
  if (!input) return result;
  const regex = /(\d+)\s*[\.\)\-:,\s]\s*([abcdABCD])\b/g;
  let m: RegExpExecArray | null;
  while ((m = regex.exec(input)) !== null) {
    const num = parseInt(m[1], 10);
    const letter = m[2].toUpperCase() as "A" | "B" | "C" | "D";
    if (!Number.isNaN(num)) result[num] = letter;
  }
  return result;
}

export type ParsedTextQuestion = {
  number: number;
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: "A" | "B" | "C" | "D";
  explanation?: string;
  _hasKey: boolean;
};

/**
 * Parse pasted MCQ text. Handles common formats:
 *
 * 1. Capital of India?
 * a) Mumbai
 * b) Delhi
 * c) Kolkata
 * d) Chennai
 * Ans: B
 * Explanation: Delhi is the capital
 *
 * 2) ...
 *
 * Answer key may be inline (Ans/Answer) or supplied separately.
 */
export function parseQuestionsText(
  text: string,
  externalKey: Record<number, "A" | "B" | "C" | "D"> = {},
): ParsedTextQuestion[] {
  if (!text?.trim()) return [];

  // Normalize newlines
  const normalized = text.replace(/\r\n/g, "\n").replace(/\u00a0/g, " ");

  // Split into question blocks. A new question starts at a line beginning with "<num>." or "<num>)" or "Q<num>"
  const blockRegex = /(?:^|\n)\s*(?:Q\.?\s*)?(\d{1,3})\s*[\.\)\:\-]\s*/gi;
  const indices: { num: number; start: number }[] = [];
  let m: RegExpExecArray | null;
  while ((m = blockRegex.exec(normalized)) !== null) {
    indices.push({ num: parseInt(m[1], 10), start: m.index + m[0].length });
  }
  if (indices.length === 0) return [];

  const blocks = indices.map((cur, i) => {
    const end = i + 1 < indices.length ? indices[i + 1].start - 1 : normalized.length;
    return { num: cur.num, body: normalized.slice(cur.start, end).trim() };
  });

  const optRegex = /(?:^|\n)\s*\(?([a-dA-D])\)?\s*[\.\)\:\-]\s*(.+?)(?=(?:\n\s*\(?[a-dA-D]\)?\s*[\.\)\:\-])|(?:\n\s*(?:ans(?:wer)?|correct|explanation|expl|sol)\b)|$)/gis;
  const ansRegex = /(?:^|\n)\s*(?:ans(?:wer)?|correct(?:\s*answer)?)\s*[:\-\.]?\s*\(?([a-dA-D])\)?/i;
  const explRegex = /(?:^|\n)\s*(?:explanation|expl|sol(?:ution)?)\s*[:\-\.]?\s*([\s\S]+?)$/i;

  const out: ParsedTextQuestion[] = [];
  for (const b of blocks) {
    const opts: Record<string, string> = {};
    let firstOptIdx = b.body.length;
    let oMatch: RegExpExecArray | null;
    const optR = new RegExp(optRegex.source, optRegex.flags);
    while ((oMatch = optR.exec(b.body)) !== null) {
      const letter = oMatch[1].toUpperCase();
      if (!opts[letter]) {
        opts[letter] = oMatch[2].trim().replace(/\s+/g, " ");
        if (oMatch.index < firstOptIdx) firstOptIdx = oMatch.index;
      }
    }
    const question = b.body.slice(0, firstOptIdx).trim().replace(/\s+/g, " ");
    if (!question) continue;

    const ansMatch = b.body.match(ansRegex);
    const explMatch = b.body.match(explRegex);
    const externalAns = externalKey[b.num];
    const correct = (ansMatch?.[1]?.toUpperCase() as any) || externalAns || "A";
    const hasKey = !!ansMatch || !!externalAns;

    out.push({
      number: b.num,
      question,
      option_a: opts.A ?? "",
      option_b: opts.B ?? "",
      option_c: opts.C ?? "",
      option_d: opts.D ?? "",
      correct_answer: ["A", "B", "C", "D"].includes(correct) ? correct : "A",
      explanation: explMatch?.[1]?.trim() || undefined,
      _hasKey: hasKey,
    });
  }
  return out;
}
