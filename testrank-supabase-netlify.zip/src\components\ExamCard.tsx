import { Link } from "react-router-dom";
import { ArrowRight, IndianRupee, Users } from "lucide-react";
import { getExamTheme } from "@/lib/exam-themes";

export type ExamCardData = {
  id: string;
  name: string;
  name_hi: string | null;
  subtitle: string | null;
  badge_label: string | null;
  icon_emoji: string | null;
  color_scheme: string;
  exam_codes: string | null;
  is_paid: boolean;
  price: number | null;
  display_test_count: string | null;
  display_student_count: string | null;
  test_count: number;
  logo_url?: string | null;
};

export default function ExamCard({ exam }: { exam: ExamCardData }) {
  const th = getExamTheme(exam.color_scheme);
  const testsLabel = exam.display_test_count || `${exam.test_count} Tests`;
  const studentsLabel = exam.display_student_count;

  return (
    <Link
      to={`/exam/${exam.id}`}
      className={`group relative block rounded-2xl p-5 transition-all
        !border-2 !border-red-500 hover:!border-red-600
        ring-0 hover:ring-4 hover:ring-red-500/20 focus:ring-4 focus:ring-red-500/30 active:ring-4 active:ring-red-500/40
        shadow-[0_4px_14px_-6px_hsl(0_84%_60%/0.35)] hover:shadow-[0_14px_36px_-12px_hsl(0_84%_60%/0.55)]
        hover:-translate-y-0.5 ${th.cardBg}`}
    >
      <div className="flex items-start justify-between gap-2">
        {exam.logo_url ? (
          <div className="h-12 w-12 rounded-xl overflow-hidden bg-white shadow-sm shrink-0 border">
            <img src={exam.logo_url} alt={exam.name} className="w-full h-full object-cover" />
          </div>
        ) : (
          <div className={`h-12 w-12 rounded-xl flex items-center justify-center text-2xl shrink-0 ${th.iconBg} ${th.iconText}`}>
            {exam.icon_emoji ?? "📘"}
          </div>
        )}
        {exam.badge_label && (
          <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${th.badgeBg} ${th.badgeText}`}>
            {exam.badge_label}
          </span>
        )}
      </div>
      <h3 className={`text-lg font-bold mt-3 ${th.title}`}>{exam.name}</h3>
      {exam.name_hi && <div className={`text-xs ${th.meta}`}>{exam.name_hi}</div>}
      {exam.exam_codes && <div className="text-xs text-muted-foreground mt-3 line-clamp-1">{exam.exam_codes}</div>}

      {exam.is_paid && exam.price ? (
        <div className="mt-3 inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-500 text-white font-extrabold text-xl shadow-md">
          <IndianRupee className="h-5 w-5" />
          <span>{exam.price}</span>
        </div>
      ) : null}

      <div className={`mt-4 pt-3 border-t border-current/10 flex items-center justify-between text-xs ${th.meta}`}>
        <div className="flex flex-col gap-1">
          <span className="font-semibold">{testsLabel}</span>
          {studentsLabel && (
            <span className="inline-flex items-center gap-1.5 font-semibold text-rose-600 dark:text-rose-400">
              <span className="relative inline-flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75 animate-ping"></span>
                <span className="relative inline-flex h-2 w-2 rounded-full bg-rose-500"></span>
              </span>
              <Users className="h-3 w-3" />
              {studentsLabel}
            </span>
          )}
        </div>
        <span className={`inline-flex items-center font-semibold ${th.exploreText}`}>
          Explore <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
        </span>
      </div>
    </Link>
  );
}
