import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Plus, Trash2, ArrowLeft, FileUp, ImagePlus, Loader2, Languages, X, Sparkles } from "lucide-react";
import BulkImportDialog from "@/components/BulkImportDialog";
import PasteImportDialog from "@/components/PasteImportDialog";

const FRACTIONS = [
  { value: "0.5", label: "1/2" },
  { value: "0.3333", label: "1/3" },
  { value: "0.25", label: "1/4" },
  { value: "0.2", label: "1/5" },
];

type Question = {
  id?: string;
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: "A" | "B" | "C" | "D";
  order_index: number;
  image_url?: string | null;
  question_hi?: string | null;
  option_a_hi?: string | null;
  option_b_hi?: string | null;
  option_c_hi?: string | null;
  option_d_hi?: string | null;
  section_id?: string | null;
  option_a_image?: string | null;
  option_b_image?: string | null;
  option_c_image?: string | null;
  option_d_image?: string | null;
  explanation?: string | null;
  _new?: boolean;
};

type Section = { id: string; name: string; position: number };

const containsHindi = (fields: Record<string, string>) =>
  Object.values(fields).some((value) => /[\u0900-\u097F]/.test(value));

async function translateFields(
  fields: Record<string, string>,
  target: "en" | "hi",
): Promise<Record<string, string> | null> {
  try {
    const functionName = target === "en" ? "translate-to-english" : "translate-to-hindi";
    const { data, error } = await supabase.functions.invoke(functionName, { body: { fields } });
    if (error) throw error;
    return data?.translations ?? null;
  } catch (e) {
    console.error("Translation failed", e);
    return null;
  }
}

export default function TestEditor() {
  const { id } = useParams();
  const isNew = !id;
  const navigate = useNavigate();
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [testId, setTestId] = useState<string | null>(id ?? null);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
  const [thumbUploading, setThumbUploading] = useState(false);
  const thumbInputRef = useRef<HTMLInputElement | null>(null);
  const [timeLimit, setTimeLimit] = useState(30);
  const [marksPer, setMarksPer] = useState(1);
  const [negEnabled, setNegEnabled] = useState(false);
  const [negFraction, setNegFraction] = useState("0.25");
  const [isPaid, setIsPaid] = useState(false);
  const [price, setPrice] = useState<number>(10);
  const [categoryId, setCategoryId] = useState<string | "none">("none");
  const [categories, setCategories] = useState<Array<{ id: string; name: string }>>([]);
  const [testType, setTestType] = useState<string>("none");
  const [subject, setSubject] = useState<string>("");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [newSectionName, setNewSectionName] = useState("");
  const [bulkOpen, setBulkOpen] = useState(false);
  const [pasteOpen, setPasteOpen] = useState(false);
  const [translating, setTranslating] = useState<Record<string, boolean>>({});
  const [uploading, setUploading] = useState<Record<string, boolean>>({});
  const fileInputs = useRef<Record<number, HTMLInputElement | null>>({});
  const optFileInputs = useRef<Record<string, HTMLInputElement | null>>({});
  const questionRefs = useRef<Record<number, HTMLDivElement | null>>({});
  const questionTextRefs = useRef<Record<number, HTMLTextAreaElement | null>>({});

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("categories").select("id,name").order("position").order("name");
      setCategories((data ?? []) as any);
    })();
  }, []);

  useEffect(() => {
    if (isNew) return;
    (async () => {
      const [{ data: test }, { data: qs }, { data: secs }] = await Promise.all([
        supabase.from("tests").select("*").eq("id", id!).single(),
        supabase.from("questions").select("*").eq("test_id", id!).order("order_index"),
        supabase.from("test_sections").select("id,name,position").eq("test_id", id!).order("position"),
      ]);
      if (test) {
        setName(test.name);
        setDescription(test.description ?? "");
        setThumbnailUrl((test as any).thumbnail_url ?? null);
        setTimeLimit(test.time_limit);
        setMarksPer(Number(test.marks_per_question));
        if (test.negative_marking_fraction != null) {
          setNegEnabled(true);
          setNegFraction(String(test.negative_marking_fraction));
        }
        setIsPaid(!!(test as any).is_paid);
        if ((test as any).price != null) setPrice(Number((test as any).price));
        setCategoryId((test as any).category_id ?? "none");
        setTestType((test as any).test_type ?? "none");
        setSubject((test as any).subject ?? "");
      }
      setQuestions((qs ?? []) as Question[]);
      setSections((secs ?? []) as Section[]);
      setLoading(false);
    })();
  }, [id, isNew]);

  const addSection = async () => {
    const tid = await ensureTest();
    if (!tid) return;
    const nm = newSectionName.trim();
    if (!nm) return;
    const pos = sections.length;
    const { data, error } = await supabase
      .from("test_sections")
      .insert({ test_id: tid, name: nm, position: pos })
      .select("id,name,position")
      .single();
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    setSections([...sections, data as Section]);
    setNewSectionName("");
  };

  const removeSection = async (sid: string) => {
    await supabase.from("test_sections").delete().eq("id", sid);
    setSections(sections.filter((s) => s.id !== sid));
    setQuestions((prev) => prev.map((q) => (q.section_id === sid ? { ...q, section_id: null } : q)));
  };

  const updateSectionName = async (sid: string, name: string) => {
    await supabase.from("test_sections").update({ name }).eq("id", sid);
    setSections((prev) => prev.map((s) => (s.id === sid ? { ...s, name } : s)));
  };

  const setQuestionSection = async (idx: number, sid: string | null) => {
    const q = questions[idx];
    if (!q.id) return;
    updateQ(idx, { section_id: sid });
    await supabase.from("questions").update({ section_id: sid }).eq("id", q.id);
  };

  const handleOptionImageUpload = async (idx: number, opt: "a" | "b" | "c" | "d", file: File) => {
    const q = questions[idx];
    if (!q.id) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "Image too large", description: "Max 5MB", variant: "destructive" });
      return;
    }
    const key = `${q.id}-opt-${opt}`;
    setUploading((p) => ({ ...p, [key]: true }));
    const ext = file.name.split(".").pop() || "png";
    const path = `${testId}/${q.id}-opt-${opt}-${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("question-images").upload(path, file, { upsert: true });
    if (upErr) {
      setUploading((p) => { const n = { ...p }; delete n[key]; return n; });
      return toast({ title: "Upload failed", description: upErr.message, variant: "destructive" });
    }
    const { data: pub } = supabase.storage.from("question-images").getPublicUrl(path);
    const url = pub.publicUrl;
    const col = `option_${opt}_image`;
    await supabase.from("questions").update({ [col]: url } as any).eq("id", q.id);
    updateQ(idx, { [col]: url } as any);
    setUploading((p) => { const n = { ...p }; delete n[key]; return n; });
  };

  const removeOptionImage = async (idx: number, opt: "a" | "b" | "c" | "d") => {
    const q = questions[idx];
    if (!q.id) return;
    const col = `option_${opt}_image`;
    await supabase.from("questions").update({ [col]: null } as any).eq("id", q.id);
    updateQ(idx, { [col]: null } as any);
  };

  const saveExplanation = async (idx: number, value: string) => {
    const q = questions[idx];
    if (!q.id) return;
    await supabase.from("questions").update({ explanation: value || null }).eq("id", q.id);
  };


  const saveTest = async () => {
    if (!name.trim()) {
      toast({ title: "Name required", variant: "destructive" });
      return null;
    }
    if (isPaid && (!Number.isFinite(price) || price < 1)) {
      toast({ title: "Enter a valid price (min ₹1)", variant: "destructive" });
      return null;
    }
    setSaving(true);
    const payload: any = {
      name: name.trim(),
      description: description.trim() || null,
      thumbnail_url: thumbnailUrl,
      time_limit: timeLimit,
      marks_per_question: marksPer,
      negative_marking_fraction: negEnabled ? Number(negFraction) : null,
      is_paid: isPaid,
      price: isPaid ? Math.round(price) : null,
      category_id: categoryId === "none" ? null : categoryId,
      test_type: testType === "none" ? null : testType,
      subject: subject.trim() || null,
      total_questions: questions.length,
    };
    let resultId = testId;
    if (isNew && !testId) {
      const { data, error } = await supabase.from("tests").insert(payload).select("id").single();
      if (error) {
        toast({ title: "Error", description: error.message, variant: "destructive" });
        setSaving(false);
        return null;
      }
      resultId = data.id;
      setTestId(data.id);
    } else {
      const { error } = await supabase.from("tests").update(payload).eq("id", testId!);
      if (error) {
        toast({ title: "Error", description: error.message, variant: "destructive" });
        setSaving(false);
        return null;
      }
    }
    setSaving(false);

    // Background auto-translate test name + description
    if (resultId) {
      const fields: Record<string, string> = { name: name.trim() };
      if (description.trim()) fields.description = description.trim();
      const sourceIsHindi = containsHindi(fields);
      translateFields(fields, sourceIsHindi ? "en" : "hi").then((t) => {
        if (!t) return;
        supabase
          .from("tests")
          .update(sourceIsHindi
            ? {
                name: t.name || name.trim(),
                description: t.description || description.trim() || null,
                name_hi: name.trim(),
                description_hi: description.trim() || null,
              }
            : {
                name_hi: t.name || null,
                description_hi: t.description || null,
              })
          .eq("id", resultId!)
          .then(() => {});
      });
    }
    return resultId;
  };

  const handleSaveAndExit = async () => {
    const tid = await saveTest();
    if (tid) {
      toast({ title: "Saved" });
      navigate("/admin/tests");
    }
  };

  const ensureTest = async (): Promise<string | null> => {
    if (testId) return testId;
    return saveTest();
  };

  const addQuestion = async () => {
    const tid = await ensureTest();
    if (!tid) return;
    const order_index = questions.length;
    const { data, error } = await supabase
      .from("questions")
      .insert({
        test_id: tid,
        question: "",
        option_a: "",
        option_b: "",
        option_c: "",
        option_d: "",
        correct_answer: "A",
        order_index,
      })
      .select("*")
      .single();
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    const newIdx = questions.length;
    setQuestions([...questions, data as Question]);
    await supabase.from("tests").update({ total_questions: questions.length + 1 }).eq("id", tid);
    // Smooth scroll to and focus the new question
    setTimeout(() => {
      questionRefs.current[newIdx]?.scrollIntoView({ behavior: "smooth", block: "center" });
      questionTextRefs.current[newIdx]?.focus();
    }, 50);
  };

  const updateQ = (idx: number, patch: Partial<Question>) => {
    setQuestions((prev) => prev.map((q, i) => (i === idx ? { ...q, ...patch } : q)));
  };

  const autoTranslateQuestion = async (qid: string, q: Question) => {
    const fields: Record<string, string> = {};
    if (q.question?.trim()) fields.question = q.question.trim();
    if (q.option_a?.trim()) fields.option_a = q.option_a.trim();
    if (q.option_b?.trim()) fields.option_b = q.option_b.trim();
    if (q.option_c?.trim()) fields.option_c = q.option_c.trim();
    if (q.option_d?.trim()) fields.option_d = q.option_d.trim();
    if (Object.keys(fields).length === 0) return;

    setTranslating((p) => ({ ...p, [qid]: true }));
    const sourceIsHindi = containsHindi(fields);
    const t = await translateFields(fields, sourceIsHindi ? "en" : "hi");
    setTranslating((p) => {
      const n = { ...p };
      delete n[qid];
      return n;
    });
    if (!t) return;
    const translatedPatch: Partial<Question> = sourceIsHindi
      ? {
          question: t.question || q.question,
          option_a: t.option_a || q.option_a,
          option_b: t.option_b || q.option_b,
          option_c: t.option_c || q.option_c,
          option_d: t.option_d || q.option_d,
          question_hi: q.question || null,
          option_a_hi: q.option_a || null,
          option_b_hi: q.option_b || null,
          option_c_hi: q.option_c || null,
          option_d_hi: q.option_d || null,
        }
      : {
          question_hi: t.question || null,
          option_a_hi: t.option_a || null,
          option_b_hi: t.option_b || null,
          option_c_hi: t.option_c || null,
          option_d_hi: t.option_d || null,
        };
    await supabase.from("questions").update(translatedPatch).eq("id", qid);
    setQuestions((prev) =>
      prev.map((qq) => (qq.id === qid ? { ...qq, ...translatedPatch } : qq)),
    );
  };

  const saveQ = async (idx: number, override?: Partial<Question>) => {
    const base = questions[idx];
    if (!base?.id) return;
    const q = { ...base, ...(override ?? {}) };
    const { error } = await supabase
      .from("questions")
      .update({
        question: q.question,
        option_a: q.option_a,
        option_b: q.option_b,
        option_c: q.option_c,
        option_d: q.option_d,
        correct_answer: q.correct_answer,
      })
      .eq("id", q.id);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
      return;
    }
    // Background auto-translate (don't block UI)
    autoTranslateQuestion(q.id!, q);
  };

  const removeQ = async (idx: number) => {
    const q = questions[idx];
    if (q.id) await supabase.from("questions").delete().eq("id", q.id);
    const next = questions.filter((_, i) => i !== idx);
    setQuestions(next);
    if (testId) await supabase.from("tests").update({ total_questions: next.length }).eq("id", testId);
  };

  const handleImageUpload = async (idx: number, file: File) => {
    const q = questions[idx];
    if (!q.id) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "Image too large", description: "Max 5MB", variant: "destructive" });
      return;
    }
    setUploading((p) => ({ ...p, [q.id!]: true }));
    const ext = file.name.split(".").pop() || "png";
    const path = `${testId}/${q.id}-${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("question-images").upload(path, file, { upsert: true });
    if (upErr) {
      setUploading((p) => {
        const n = { ...p };
        delete n[q.id!];
        return n;
      });
      toast({ title: "Upload failed", description: upErr.message, variant: "destructive" });
      return;
    }
    const { data: pub } = supabase.storage.from("question-images").getPublicUrl(path);
    const url = pub.publicUrl;
    await supabase.from("questions").update({ image_url: url }).eq("id", q.id);
    updateQ(idx, { image_url: url });
    setUploading((p) => {
      const n = { ...p };
      delete n[q.id!];
      return n;
    });
  };

  const removeImage = async (idx: number) => {
    const q = questions[idx];
    if (!q.id) return;
    await supabase.from("questions").update({ image_url: null }).eq("id", q.id);
    updateQ(idx, { image_url: null });
  };

  const handleThumbnailUpload = async (file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      toast({ title: "Image too large", description: "Max 2MB", variant: "destructive" });
      return;
    }
    const tid = await ensureTest();
    if (!tid) return;
    setThumbUploading(true);
    const ext = file.name.split(".").pop() || "png";
    const path = `thumbnails/${tid}/${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("question-images").upload(path, file, { upsert: true });
    if (upErr) {
      setThumbUploading(false);
      toast({ title: "Upload failed", description: upErr.message, variant: "destructive" });
      return;
    }
    const { data: pub } = supabase.storage.from("question-images").getPublicUrl(path);
    const url = pub.publicUrl;
    await supabase.from("tests").update({ thumbnail_url: url }).eq("id", tid);
    setThumbnailUrl(url);
    setThumbUploading(false);
  };

  const removeThumbnail = async () => {
    setThumbnailUrl(null);
    if (testId) await supabase.from("tests").update({ thumbnail_url: null }).eq("id", testId);
  };

  if (loading) return <p className="text-muted-foreground">Loading…</p>;

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/admin/tests")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">{isNew ? "New Test" : "Edit Test"}</h1>
            <p className="text-sm text-muted-foreground">
              Configure metadata, then add questions in English or Hindi. The other language is auto-generated.
            </p>
          </div>
        </div>
        <Button onClick={handleSaveAndExit} disabled={saving}>
          {saving ? "Saving…" : "Save & Exit"}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Test Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2 sm:col-span-2">
              <Label>Thumbnail</Label>
              {thumbnailUrl ? (
                <div className="relative inline-block w-full max-w-md">
                  <div className="aspect-video w-full overflow-hidden rounded-md border bg-muted">
                    <img src={thumbnailUrl} alt="Test thumbnail" className="w-full h-full object-cover" />
                  </div>
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute -top-2 -right-2 h-7 w-7"
                    onClick={removeThumbnail}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <input
                    ref={thumbInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleThumbnailUpload(f);
                      e.target.value = "";
                    }}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => thumbInputRef.current?.click()}
                    disabled={thumbUploading}
                  >
                    {thumbUploading ? (
                      <><Loader2 className="h-3 w-3 animate-spin" /> Uploading…</>
                    ) : (
                      <><ImagePlus className="h-3 w-3" /> Upload thumbnail</>
                    )}
                  </Button>
                  <span className="text-xs text-muted-foreground">Recommended 1200×630, max 2MB</span>
                </div>
              )}
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>Test Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. General Knowledge — Set 1" />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>Description</Label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>Category (optional)</Label>
              <Select value={categoryId} onValueChange={(v) => setCategoryId(v as any)}>
                <SelectTrigger>
                  <SelectValue placeholder="Uncategorised" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Uncategorised (Other Tests)</SelectItem>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">Manage categories from the Categories tab.</p>
            </div>
            <div className="space-y-2">
              <Label>Test Type (tab on exam page)</Label>
              <Select value={testType} onValueChange={setTestType}>
                <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="mock">Mock Test</SelectItem>
                  <SelectItem value="pyq">Previous Year Paper</SelectItem>
                  <SelectItem value="topic">Topic Test</SelectItem>
                  <SelectItem value="practice">Practice</SelectItem>
                  <SelectItem value="test_series">Test Series</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Subject (filter on exam page)</Label>
              <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="e.g. Quantitative Aptitude" />
            </div>
            <div className="space-y-2">
              <Label>Time Limit (minutes)</Label>
              <Input type="number" min={1} value={timeLimit} onChange={(e) => setTimeLimit(Number(e.target.value))} />
            </div>
            <div className="space-y-2">
              <Label>Marks per Question</Label>
              <Input type="number" step="0.5" min={0.5} value={marksPer} onChange={(e) => setMarksPer(Number(e.target.value))} />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <div className="flex items-center gap-2">
                <Checkbox id="neg" checked={negEnabled} onCheckedChange={(v) => setNegEnabled(!!v)} />
                <Label htmlFor="neg" className="cursor-pointer">
                  Enable negative marking
                </Label>
              </div>
              {negEnabled && (
                <Select value={negFraction} onValueChange={setNegFraction}>
                  <SelectTrigger className="max-w-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FRACTIONS.map((f) => (
                      <SelectItem key={f.value} value={f.value}>
                        {f.label} of marks per question
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Pricing</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            <Checkbox id="paid" checked={isPaid} onCheckedChange={(v) => setIsPaid(!!v)} />
            <Label htmlFor="paid" className="cursor-pointer">
              This is a paid test
            </Label>
          </div>
          {isPaid && (
            <div className="space-y-2 max-w-xs">
              <Label>Price (₹)</Label>
              <Input
                type="number"
                min={1}
                step={1}
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                Students will be asked to pay online before they can start the test.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Sections</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <p className="text-xs text-muted-foreground">
            Group questions into sections (e.g. Maths, Reasoning). Students can switch between sections during the test.
          </p>
          {sections.map((s) => (
            <div key={s.id} className="flex items-center gap-2">
              <Input value={s.name} onChange={(e) => setSections((prev) => prev.map((x) => x.id === s.id ? { ...x, name: e.target.value } : x))} onBlur={(e) => updateSectionName(s.id, e.target.value)} className="max-w-xs" />
              <Button variant="ghost" size="icon" onClick={() => removeSection(s.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
            </div>
          ))}
          <div className="flex items-center gap-2">
            <Input placeholder="New section name (e.g. Maths)" value={newSectionName} onChange={(e) => setNewSectionName(e.target.value)} className="max-w-xs" />
            <Button size="sm" onClick={addSection}><Plus className="h-4 w-4" /> Add</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="sticky top-0 z-10 bg-card border-b flex-row items-center justify-between flex-wrap gap-2 rounded-t-lg">
          <CardTitle>Questions ({questions.length})</CardTitle>
          <div className="flex gap-2 flex-wrap">
            <Button size="sm" variant="outline" onClick={async () => {
              const tid = await ensureTest();
              if (tid) setPasteOpen(true);
            }}>
              <Sparkles className="h-4 w-4" /> Paste Questions
            </Button>
            <Button size="sm" variant="outline" onClick={async () => {
              const tid = await ensureTest();
              if (tid) setBulkOpen(true);
            }}>
              <FileUp className="h-4 w-4" /> Bulk Import PDF
            </Button>
            <Button size="sm" onClick={addQuestion}>
              <Plus className="h-4 w-4" /> Add Question
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 pt-4">
          {questions.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-8">
              No questions yet. Click "Add Question" to begin.
            </p>
          )}
          {questions.map((q, idx) => (
            <Card
              key={q.id ?? idx}
              ref={(el) => (questionRefs.current[idx] = el)}
              className="border-2"
            >
              <CardContent className="pt-6 space-y-3">
                <div className="flex items-start gap-2">
                  <span className="font-bold text-primary">Q{idx + 1}.</span>
                  <Textarea
                    ref={(el) => (questionTextRefs.current[idx] = el)}
                    value={q.question}
                    placeholder="Question text in English or Hindi - the other language is auto-generated"
                    onChange={(e) => updateQ(idx, { question: e.target.value })}
                    onBlur={() => saveQ(idx)}
                    rows={2}
                    className="flex-1"
                  />
                  <div className="flex flex-col gap-1">
                    {q.id && translating[q.id] && (
                      <span className="text-xs text-muted-foreground inline-flex items-center gap-1 px-1">
                        <Loader2 className="h-3 w-3 animate-spin" /> Translating…
                      </span>
                    )}
                    <Button variant="ghost" size="icon" onClick={() => removeQ(idx)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>

                {/* Image upload */}
                <div className="pl-6">
                  {q.image_url ? (
                    <div className="relative inline-block">
                      <img src={q.image_url} alt="Question" className="max-h-40 rounded border" />
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute -top-2 -right-2 h-6 w-6"
                        onClick={() => removeImage(idx)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <input
                        ref={(el) => (fileInputs.current[idx] = el)}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleImageUpload(idx, f);
                          e.target.value = "";
                        }}
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => fileInputs.current[idx]?.click()}
                        disabled={!q.id || (q.id && uploading[q.id])}
                      >
                        {q.id && uploading[q.id] ? (
                          <><Loader2 className="h-3 w-3 animate-spin" /> Uploading…</>
                        ) : (
                          <><ImagePlus className="h-3 w-3" /> Add image</>
                        )}
                      </Button>
                    </>
                  )}
                </div>

                <div className="grid sm:grid-cols-2 gap-2 pl-6">
                  {(["A", "B", "C", "D"] as const).map((opt) => {
                    const key = `option_${opt.toLowerCase()}` as keyof Question;
                    const imgKey = `option_${opt.toLowerCase()}_image` as keyof Question;
                    const imgUrl = q[imgKey] as string | null | undefined;
                    const optLower = opt.toLowerCase() as "a" | "b" | "c" | "d";
                    const upKey = `${q.id}-opt-${optLower}`;
                    return (
                      <div key={opt} className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium w-5">{opt}.</span>
                          <Input
                            value={(q[key] as string) ?? ""}
                            placeholder={`Option ${opt}`}
                            onChange={(e) => updateQ(idx, { [key]: e.target.value } as any)}
                            onBlur={() => saveQ(idx)}
                          />
                          {imgUrl ? (
                            <Button variant="ghost" size="icon" onClick={() => removeOptionImage(idx, optLower)} title="Remove image">
                              <X className="h-3 w-3 text-destructive" />
                            </Button>
                          ) : (
                            <>
                              <input
                                ref={(el) => (optFileInputs.current[upKey] = el)}
                                type="file" accept="image/*" className="hidden"
                                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleOptionImageUpload(idx, optLower, f); e.target.value = ""; }}
                              />
                              <Button variant="ghost" size="icon" onClick={() => optFileInputs.current[upKey]?.click()} disabled={!q.id || uploading[upKey]} title="Add image to option">
                                {uploading[upKey] ? <Loader2 className="h-3 w-3 animate-spin" /> : <ImagePlus className="h-3 w-3" />}
                              </Button>
                            </>
                          )}
                        </div>
                        {imgUrl && <img src={imgUrl} alt={`Option ${opt}`} className="max-h-24 rounded border ml-7" />}
                      </div>
                    );
                  })}
                </div>

                <div className="pl-6 space-y-1">
                  <Label className="text-xs text-muted-foreground">Explanation (shown on result review)</Label>
                  <Textarea
                    rows={2}
                    placeholder="Why is this the right answer?"
                    defaultValue={q.explanation ?? ""}
                    onBlur={(e) => saveExplanation(idx, e.target.value)}
                  />
                </div>

                <div className="flex items-center gap-2 pl-6 flex-wrap">
                  <Label className="text-sm">Section:</Label>
                  <Select
                    value={q.section_id ?? "none"}
                    onValueChange={(v) => setQuestionSection(idx, v === "none" ? null : v)}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="General" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">General</SelectItem>
                      {sections.map((s) => (
                        <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Label className="text-sm ml-2">Correct:</Label>
                  <Select
                    value={q.correct_answer}
                    onValueChange={(v) => {
                      const newVal = v as "A" | "B" | "C" | "D";
                      updateQ(idx, { correct_answer: newVal });
                      saveQ(idx, { correct_answer: newVal });
                    }}
                  >
                    <SelectTrigger className="w-20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {(["A", "B", "C", "D"] as const).map((o) => (
                        <SelectItem key={o} value={o}>
                          {o}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="ml-auto"
                    disabled={!q.id || (q.id && translating[q.id])}
                    onClick={() => q.id && autoTranslateQuestion(q.id, q)}
                    title="Generate the missing English or Hindi version"
                  >
                    {q.id && translating[q.id] ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <Languages className="h-3 w-3" />
                    )}
                    Translate
                  </Button>
                  {q.question?.trim() && q.question_hi?.trim() && (
                    <span className="text-xs text-success">Bilingual ready</span>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      {testId && (
        <>
          <BulkImportDialog
            open={bulkOpen}
            onOpenChange={setBulkOpen}
            testId={testId}
            startOrderIndex={questions.length}
            onImported={async () => {
              const { data } = await supabase
                .from("questions")
                .select("*")
                .eq("test_id", testId)
                .order("order_index");
              setQuestions((data ?? []) as Question[]);
              await supabase.from("tests").update({ total_questions: (data ?? []).length }).eq("id", testId);
            }}
          />
          <PasteImportDialog
            open={pasteOpen}
            onOpenChange={setPasteOpen}
            testId={testId}
            startOrderIndex={questions.length}
            onImported={async () => {
              const { data } = await supabase
                .from("questions")
                .select("*")
                .eq("test_id", testId)
                .order("order_index");
              setQuestions((data ?? []) as Question[]);
              await supabase.from("tests").update({ total_questions: (data ?? []).length }).eq("id", testId);
            }}
          />
        </>
      )}
    </div>
  );
}
