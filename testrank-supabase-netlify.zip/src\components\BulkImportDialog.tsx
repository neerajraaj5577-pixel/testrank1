import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Loader2, FileUp, AlertCircle } from "lucide-react";
import { pdfToImages } from "@/lib/pdf-to-images";
import { parseAnswerKey } from "@/lib/answer-key-parser";
import { supabase } from "@/integrations/supabase/client";

type ParsedQuestion = {
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: "A" | "B" | "C" | "D";
  question_hi?: string;
  option_a_hi?: string;
  option_b_hi?: string;
  option_c_hi?: string;
  option_d_hi?: string;
  _hasKey?: boolean;
};

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  testId: string;
  startOrderIndex: number;
  onImported: () => void;
};

export default function BulkImportDialog({ open, onOpenChange, testId, startOrderIndex, onImported }: Props) {
  const [file, setFile] = useState<File | null>(null);
  const [answerKeyText, setAnswerKeyText] = useState("");
  const [extracting, setExtracting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [parsed, setParsed] = useState<ParsedQuestion[] | null>(null);

  const reset = () => {
    setFile(null);
    setAnswerKeyText("");
    setParsed(null);
    setExtracting(false);
    setImporting(false);
  };

  const handleClose = (next: boolean) => {
    if (!next) reset();
    onOpenChange(next);
  };

  const handleExtract = async () => {
    if (!file) {
      toast({ title: "Please select a PDF", variant: "destructive" });
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast({ title: "File too large", description: "Max 20MB", variant: "destructive" });
      return;
    }
    setExtracting(true);
    try {
      const images = await pdfToImages(file, { maxPages: 50, scale: 1.6, quality: 0.85 });
      const answerKey = parseAnswerKey(answerKeyText);

      const { data, error } = await supabase.functions.invoke("parse-mcq-pdf", {
        body: { images: images.map((p) => p.dataUrl), answerKey },
      });
      if (error) throw error;
      if (!data?.questions?.length) {
        toast({ title: "No questions found", description: "Try a clearer PDF.", variant: "destructive" });
        return;
      }
      setParsed(data.questions as ParsedQuestion[]);
      const missing = data.missingCount ?? 0;
      if (missing > 0) {
        toast({
          title: `${missing} question${missing > 1 ? "s" : ""} may be missing`,
          description: `Got ${data.questions.length} of ${data.expectedCount} expected. Check the PDF and add manually if needed.`,
          variant: "destructive",
        });
      } else {
        toast({ title: `Extracted ${data.questions.length} questions`, description: "Review and import below." });
      }
    } catch (e: any) {
      toast({ title: "Extraction failed", description: e?.message ?? String(e), variant: "destructive" });
    } finally {
      setExtracting(false);
    }
  };

  const updateParsed = (idx: number, patch: Partial<ParsedQuestion>) => {
    setParsed((prev) => (prev ? prev.map((q, i) => (i === idx ? { ...q, ...patch } : q)) : prev));
  };

  const removeParsed = (idx: number) => {
    setParsed((prev) => (prev ? prev.filter((_, i) => i !== idx) : prev));
  };

  const handleImport = async () => {
    if (!parsed || parsed.length === 0) return;
    setImporting(true);
    try {
      const rows = parsed.map((q, i) => ({
        test_id: testId,
        question: q.question,
        option_a: q.option_a,
        option_b: q.option_b,
        option_c: q.option_c,
        option_d: q.option_d,
        correct_answer: q.correct_answer,
        order_index: startOrderIndex + i,
        question_hi: q.question_hi?.trim() || null,
        option_a_hi: q.option_a_hi?.trim() || null,
        option_b_hi: q.option_b_hi?.trim() || null,
        option_c_hi: q.option_c_hi?.trim() || null,
        option_d_hi: q.option_d_hi?.trim() || null,
      }));
      const { error } = await supabase.from("questions").insert(rows);
      if (error) throw error;
      toast({ title: `Imported ${rows.length} questions` });
      onImported();
      handleClose(false);
    } catch (e: any) {
      toast({ title: "Import failed", description: e?.message ?? String(e), variant: "destructive" });
    } finally {
      setImporting(false);
    }
  };

  const missingKeyCount = parsed?.filter((q) => !q._hasKey).length ?? 0;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Bulk Import from PDF</DialogTitle>
          <DialogDescription>
            Upload a PDF of MCQs and paste the answer key. We'll extract questions automatically.
          </DialogDescription>
        </DialogHeader>

        {!parsed && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>PDF File (max 20MB, 50 pages)</Label>
              <Input
                type="file"
                accept="application/pdf"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              />
              {file && <p className="text-xs text-muted-foreground">{file.name} · {(file.size / 1024 / 1024).toFixed(2)} MB</p>}
            </div>
            <div className="space-y-2">
              <Label>Answer Key</Label>
              <Textarea
                rows={5}
                value={answerKeyText}
                onChange={(e) => setAnswerKeyText(e.target.value)}
                placeholder={"Examples:\n1 a, 2 b, 3 c, 4 d\n1.A 2.B 3.C\n1) A\n2) B"}
              />
              <p className="text-xs text-muted-foreground">
                Flexible format — numbers paired with A/B/C/D in any separator. Missing entries default to A.
              </p>
            </div>
          </div>
        )}

        {parsed && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">{parsed.length} questions extracted</span>
              {missingKeyCount > 0 && (
                <span className="flex items-center gap-1 text-warning">
                  <AlertCircle className="h-3.5 w-3.5" />
                  {missingKeyCount} missing answer key (defaulted to A)
                </span>
              )}
            </div>
            <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
              {parsed.map((q, idx) => (
                <div key={idx} className={`border rounded-md p-3 space-y-2 ${!q._hasKey ? "border-warning/50 bg-warning/5" : ""}`}>
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-primary text-sm">Q{idx + 1}.</span>
                    <Textarea
                      value={q.question}
                      onChange={(e) => updateParsed(idx, { question: e.target.value })}
                      rows={2}
                      className="flex-1 text-sm"
                    />
                    <Button variant="ghost" size="sm" onClick={() => removeParsed(idx)}>Remove</Button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 pl-6">
                    {(["a", "b", "c", "d"] as const).map((opt) => {
                      const key = `option_${opt}` as keyof ParsedQuestion;
                      return (
                        <div key={opt} className="flex items-center gap-1">
                          <span className="text-xs font-medium uppercase w-4">{opt}.</span>
                          <Input
                            value={(q[key] as string) ?? ""}
                            onChange={(e) => updateParsed(idx, { [key]: e.target.value } as any)}
                            className="text-sm h-8"
                          />
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center gap-2 pl-6">
                    <Label className="text-xs">Correct:</Label>
                    <Select
                      value={q.correct_answer}
                      onValueChange={(v) => updateParsed(idx, { correct_answer: v as any, _hasKey: true })}
                    >
                      <SelectTrigger className="h-8 w-20 text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {(["A", "B", "C", "D"] as const).map((o) => (
                          <SelectItem key={o} value={o}>{o}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <DialogFooter>
          {!parsed ? (
            <>
              <Button variant="outline" onClick={() => handleClose(false)} disabled={extracting}>Cancel</Button>
              <Button onClick={handleExtract} disabled={extracting || !file}>
                {extracting ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Extracting…</>
                ) : (
                  <><FileUp className="h-4 w-4" /> Extract Questions</>
                )}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setParsed(null)} disabled={importing}>Back</Button>
              <Button onClick={handleImport} disabled={importing || parsed.length === 0}>
                {importing ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Importing…</>
                ) : (
                  <>Import {parsed.length} Questions</>
                )}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
