import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  CheckCircle2, XCircle, Circle, Clock, Trophy, Target, Timer, TrendingUp, TrendingDown,
} from "lucide-react";
import { format } from "@/lib/format";
import { cn } from "@/lib/utils";

type Q = {
  id: string;
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: string;
  order_index: number;
  image_url: string | null;
  option_a_image?: string | null;
  option_b_image?: string | null;
  option_c_image?: string | null;
  option_d_image?: string | null;
  explanation?: string | null;
};

function fmtMs(ms: number) {
  const sec = Math.floor(ms / 1000);
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function Result() {
  const { resultId } = useParams();
  const [result, setResult] = useState<any>(null);
  const [test, setTest] = useState<any>(null);
  const [questions, setQuestions] = useState<Q[]>([]);
  const [openQid, setOpenQid] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data: r } = await supabase.from("results").select("*").eq("id", resultId!).single();
      setResult(r);
      if (r) {
        const [{ data: t }, { data: qs }] = await Promise.all([
          supabase.from("tests").select("*").eq("id", r.test_id).single(),
          supabase
            .from("questions")
            .select("id, question, option_a, option_b, option_c, option_d, correct_answer, order_index, image_url, option_a_image, option_b_image, option_c_image, option_d_image, explanation")
            .eq("test_id", r.test_id)
            .order("order_index"),
        ]);
        setTest(t);
        setQuestions((qs ?? []) as Q[]);
      }
    })();
  }, [resultId]);

  const breakdown = useMemo(() => {
    if (!result || questions.length === 0) return [];
    const userAns: Record<string, string> = result.answers ?? {};
    const times: Record<string, number> = result.per_question_time ?? {};
    return questions.map((q, i) => {
      const ans = userAns[q.id] ?? null;
      const correct = ans ? ans === q.correct_answer : null;
      const ms = times[q.id] ?? 0;
      return { num: i + 1, qid: q.id, question: q.question, ans, correctAns: q.correct_answer, correct, ms };
    });
  }, [result, questions]);

  const slowest = useMemo(
    () => [...breakdown].sort((a, b) => b.ms - a.ms).slice(0, 3),
    [breakdown],
  );
  const fastest = useMemo(
    () => [...breakdown].filter((x) => x.ms > 0).sort((a, b) => a.ms - b.ms).slice(0, 3),
    [breakdown],
  );

  const openQuestion = useMemo(
    () => questions.find((q) => q.id === openQid) ?? null,
    [openQid, questions],
  );
  const openDetail = useMemo(() => {
    if (!openQuestion || !result) return null;
    const userAns: Record<string, string> = result.answers ?? {};
    const times: Record<string, number> = result.per_question_time ?? {};
    const idx = questions.findIndex((q) => q.id === openQuestion.id);
    return {
      num: idx + 1,
      ans: userAns[openQuestion.id] ?? null,
      ms: times[openQuestion.id] ?? 0,
    };
  }, [openQuestion, result, questions]);

  if (!result || !test) return <div className="min-h-screen flex items-center justify-center">Loading…</div>;

  const totalAttempted = result.correct_answers + result.wrong_answers;
  const accuracy = totalAttempted > 0 ? Math.round((result.correct_answers / totalAttempted) * 100) : 0;
  const maxScore = Number(test.marks_per_question) * Number(test.total_questions);
  const hasBreakdown = breakdown.length > 0 && (result.answers || result.per_question_time);

  return (
    <div className="min-h-screen bg-gradient-subtle p-4 py-10">
      <div className="max-w-3xl mx-auto space-y-5">
        <Card className="shadow-elegant">
          <CardContent className="pt-8 space-y-6">
            <div className="text-center">
              <div className="mx-auto h-16 w-16 rounded-full bg-gradient-primary flex items-center justify-center mb-3">
                <Trophy className="h-8 w-8 text-primary-foreground" />
              </div>
              <h1 className="text-2xl font-bold">Test Submitted!</h1>
              <p className="text-muted-foreground">{test.name}</p>
            </div>

            <div className="text-center py-6 bg-gradient-primary rounded-xl text-primary-foreground">
              <div className="text-sm opacity-80">Your Score</div>
              <div className="text-5xl font-bold">{result.score}</div>
              <div className="text-sm opacity-80">out of {maxScore}</div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Stat icon={CheckCircle2} label="Correct" value={result.correct_answers} color="text-success" />
              <Stat icon={XCircle} label="Wrong" value={result.wrong_answers} color="text-destructive" />
              <Stat icon={Circle} label="Unattempted" value={result.unattempted} color="text-muted-foreground" />
              <Stat icon={Target} label="Accuracy" value={`${accuracy}%`} color="text-primary" />
            </div>

            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" /> Time taken: {format.duration(result.time_taken_seconds)}
            </div>

            <Button asChild className="w-full">
              <Link to="/">Back to Home</Link>
            </Button>
          </CardContent>
        </Card>

        {hasBreakdown && (
          <>
            <div className="grid sm:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <TrendingDown className="h-4 w-4 text-destructive" /> Slowest 3 questions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1.5 text-sm">
                  {slowest.map((b) => (
                    <button
                      key={b.qid}
                      onClick={() => setOpenQid(b.qid)}
                      className="flex justify-between w-full hover:text-primary transition-colors"
                    >
                      <span>Q{b.num}</span>
                      <span className="font-mono">{fmtMs(b.ms)}</span>
                    </button>
                  ))}
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-success" /> Fastest 3 questions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1.5 text-sm">
                  {fastest.map((b) => (
                    <button
                      key={b.qid}
                      onClick={() => setOpenQid(b.qid)}
                      className="flex justify-between w-full hover:text-primary transition-colors"
                    >
                      <span>Q{b.num}</span>
                      <span className="font-mono">{fmtMs(b.ms)}</span>
                    </button>
                  ))}
                  {fastest.length === 0 && (
                    <p className="text-muted-foreground text-xs">No timing data available.</p>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Timer className="h-4 w-4" /> Question-by-question breakdown
                </CardTitle>
                <p className="text-xs text-muted-foreground">Tap any row to view the question.</p>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">#</TableHead>
                        <TableHead>Your answer</TableHead>
                        <TableHead>Correct</TableHead>
                        <TableHead>Result</TableHead>
                        <TableHead className="text-right">Time</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {breakdown.map((b) => (
                        <TableRow
                          key={b.qid}
                          onClick={() => setOpenQid(b.qid)}
                          className="cursor-pointer hover:bg-muted/60"
                        >
                          <TableCell className="font-medium">{b.num}</TableCell>
                          <TableCell>{b.ans ?? <span className="text-muted-foreground">—</span>}</TableCell>
                          <TableCell>{b.correctAns}</TableCell>
                          <TableCell>
                            {b.ans === null ? (
                              <Badge variant="secondary">Skipped</Badge>
                            ) : b.correct ? (
                              <Badge className="bg-success text-success-foreground hover:bg-success">Correct</Badge>
                            ) : (
                              <Badge variant="destructive">Wrong</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right font-mono">{fmtMs(b.ms)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <Dialog open={!!openQid} onOpenChange={(o) => !o && setOpenQid(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          {openQuestion && openDetail && (
            <>
              <DialogHeader>
                <DialogTitle>Question {openDetail.num}</DialogTitle>
                <DialogDescription className="flex items-center gap-2 text-xs">
                  <Timer className="h-3.5 w-3.5" /> Time spent: {fmtMs(openDetail.ms)}
                  {openDetail.ans === null ? (
                    <Badge variant="secondary">Skipped</Badge>
                  ) : openDetail.ans === openQuestion.correct_answer ? (
                    <Badge className="bg-success text-success-foreground hover:bg-success">Correct</Badge>
                  ) : (
                    <Badge variant="destructive">Wrong</Badge>
                  )}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                {openQuestion.image_url && (
                  <img
                    src={openQuestion.image_url}
                    alt="Question illustration"
                    className="max-h-64 rounded-md border mx-auto"
                  />
                )}
                <p className="text-base font-medium leading-relaxed">{openQuestion.question}</p>

                <div className="space-y-2">
                  {(["A", "B", "C", "D"] as const).map((opt) => {
                    const text = (openQuestion as any)[`option_${opt.toLowerCase()}`];
                    const img = (openQuestion as any)[`option_${opt.toLowerCase()}_image`] as string | null | undefined;
                    if (!text && !img) return null;
                    const isCorrect = opt === openQuestion.correct_answer;
                    const isUser = opt === openDetail.ans;
                    return (
                      <div
                        key={opt}
                        className={cn(
                          "flex items-start gap-3 p-3 rounded-md border",
                          isCorrect && "border-success bg-success/10",
                          !isCorrect && isUser && "border-destructive bg-destructive/10",
                        )}
                      >
                        <span className="font-semibold">{opt}.</span>
                        <div className="flex-1 space-y-2">
                          <div>{text}</div>
                          {img && <img src={img} alt={`Option ${opt}`} className="max-h-32 rounded border" />}
                        </div>
                        {isCorrect && (
                          <Badge className="bg-success text-success-foreground hover:bg-success">Correct</Badge>
                        )}
                        {!isCorrect && isUser && <Badge variant="destructive">Your answer</Badge>}
                      </div>
                    );
                  })}
                </div>

                {openQuestion.explanation && (
                  <div className="rounded-md border-l-4 border-primary bg-primary/5 p-4 space-y-1">
                    <p className="text-sm font-semibold text-primary">Explanation</p>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{openQuestion.explanation}</p>
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Stat({ icon: Icon, label, value, color }: any) {
  return (
    <div className="p-4 rounded-lg bg-muted text-center">
      <Icon className={`h-5 w-5 mx-auto mb-1 ${color}`} />
      <div className="text-xl font-bold">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}
