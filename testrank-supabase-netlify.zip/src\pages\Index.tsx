export { default } from "./student/Home";
