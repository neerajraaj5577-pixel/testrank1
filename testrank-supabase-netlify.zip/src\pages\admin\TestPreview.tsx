import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

export default function TestPreview() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [test, setTest] = useState<any>(null);
  const [questions, setQuestions] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const [{ data: t }, { data: qs }] = await Promise.all([
        supabase.from("tests").select("*").eq("id", id!).single(),
        supabase.from("questions").select("*").eq("test_id", id!).order("order_index"),
      ]);
      setTest(t);
      setQuestions(qs ?? []);
    })();
  }, [id]);

  if (!test) return <p className="text-muted-foreground">Loading…</p>;

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate("/admin/tests")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">{test.name}</h1>
          <p className="text-sm text-muted-foreground">{test.description}</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Badge variant="secondary">{test.time_limit} min</Badge>
        <Badge variant="secondary">{questions.length} questions</Badge>
        <Badge variant="secondary">{test.marks_per_question} marks each</Badge>
        {test.negative_marking_fraction != null && (
          <Badge variant="destructive">−{Number(test.negative_marking_fraction) * Number(test.marks_per_question)} per wrong</Badge>
        )}
      </div>

      <div className="space-y-4">
        {questions.map((q, idx) => (
          <Card key={q.id}>
            <CardHeader>
              <CardTitle className="text-base">
                Q{idx + 1}. {q.question}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {(["A", "B", "C", "D"] as const).map((opt) => {
                const text = q[`option_${opt.toLowerCase()}`];
                const isCorrect = q.correct_answer === opt;
                return (
                  <div
                    key={opt}
                    className={cn(
                      "p-3 rounded-md border",
                      isCorrect ? "border-success bg-success/10 text-success-foreground" : "border-border",
                    )}
                  >
                    <span className="font-medium mr-2">{opt}.</span>
                    {text}
                    {isCorrect && <Badge className="ml-2 bg-success text-success-foreground">Correct</Badge>}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
