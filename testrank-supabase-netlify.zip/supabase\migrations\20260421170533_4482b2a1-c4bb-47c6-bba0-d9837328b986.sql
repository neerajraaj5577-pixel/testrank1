
ALTER TABLE public.questions ADD COLUMN IF NOT EXISTS image_url text;

INSERT INTO storage.buckets (id, name, public)
VALUES ('question-images', 'question-images', true)
ON CONFLICT (id) DO NOTHING;

DO $$ BEGIN
  CREATE POLICY "Public read question images"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'question-images');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "Public upload question images"
    ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'question-images');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "Public update question images"
    ON storage.objects FOR UPDATE
    USING (bucket_id = 'question-images');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "Public delete question images"
    ON storage.objects FOR DELETE
    USING (bucket_id = 'question-images');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
