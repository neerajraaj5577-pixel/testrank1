-- Add pricing columns to tests
ALTER TABLE public.tests
  ADD COLUMN IF NOT EXISTS is_paid boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS price numeric(10,2);

-- Create test_payments table
CREATE TABLE IF NOT EXISTS public.test_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL,
  test_id uuid NOT NULL,
  razorpay_order_id text NOT NULL,
  razorpay_payment_id text,
  razorpay_signature text,
  amount numeric(10,2) NOT NULL,
  status text NOT NULL DEFAULT 'created',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_test_payments_student_test ON public.test_payments(student_id, test_id);
CREATE INDEX IF NOT EXISTS idx_test_payments_order_id ON public.test_payments(razorpay_order_id);
CREATE UNIQUE INDEX IF NOT EXISTS uniq_paid_per_student_test
  ON public.test_payments(student_id, test_id)
  WHERE status = 'paid';

-- updated_at trigger function (reusable)
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS update_test_payments_updated_at ON public.test_payments;
CREATE TRIGGER update_test_payments_updated_at
BEFORE UPDATE ON public.test_payments
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- RLS
ALTER TABLE public.test_payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can insert test_payments" ON public.test_payments;
CREATE POLICY "Public can insert test_payments"
  ON public.test_payments FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "Public can read test_payments" ON public.test_payments;
CREATE POLICY "Public can read test_payments"
  ON public.test_payments FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Public can update test_payments" ON public.test_payments;
CREATE POLICY "Public can update test_payments"
  ON public.test_payments FOR UPDATE
  USING (true)
  WITH CHECK (true);