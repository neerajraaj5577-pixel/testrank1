import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowRight, ArrowLeft, Lock, IndianRupee, ShieldCheck } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import SiteHeader from "@/components/SiteHeader";
import Footer from "@/components/Footer";
import { getExamTheme } from "@/lib/exam-themes";
import SEO from "@/components/SEO";

type Exam = {
  id: string; name: string; name_hi: string | null; subtitle: string | null;
  badge_label: string | null; icon_emoji: string | null; color_scheme: string;
  exam_codes: string | null; is_paid: boolean; price: number | null; mrp: number | null;
  free_category_id: string | null;
};
type SubExam = {
  id: string; name: string; name_hi: string | null; icon_emoji: string | null;
  badge_label: string | null; exam_codes: string | null; position: number;
  test_count: number;
};

declare global { interface Window { Razorpay: any } }

function loadRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true); s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export default function ExamView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [exam, setExam] = useState<Exam | null>(null);
  const [freeCategorySlug, setFreeCategorySlug] = useState<string | null>(null);
  const [subExams, setSubExams] = useState<SubExam[]>([]);
  const [unlocked, setUnlocked] = useState(false);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState(false);

  const refreshUnlockStatus = async (userId: string, examId: string) => {
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const { data: unlock } = await supabase
        .from("exam_unlocks" as any)
        .select("id")
        .eq("user_id", userId)
        .eq("exam_id", examId)
        .maybeSingle();

      if (unlock) {
        setUnlocked(true);
        return true;
      }

      await new Promise((resolve) => window.setTimeout(resolve, 1200));
    }

    return false;
  };

  const load = async () => {
    if (!id) return;
    setLoading(true);
    const { data: ex } = await supabase.from("exams" as any).select("*").eq("id", id).maybeSingle();
    setExam(ex as any);
    if (ex && (ex as any).free_category_id) {
      const { data: cat } = await supabase.from("categories").select("slug").eq("id", (ex as any).free_category_id).maybeSingle();
      setFreeCategorySlug((cat as any)?.slug ?? null);
    } else setFreeCategorySlug(null);
    const { data: subs } = await supabase
      .from("sub_exams" as any).select("*").eq("exam_id", id).eq("is_active", true).order("position");
    const sids = (subs ?? []).map((s: any) => s.id);
    const { data: links } = sids.length
      ? await supabase.from("sub_exam_tests" as any).select("sub_exam_id").in("sub_exam_id", sids)
      : { data: [] as any[] };
    const counts = new Map<string, number>();
    (links ?? []).forEach((l: any) => counts.set(l.sub_exam_id, (counts.get(l.sub_exam_id) ?? 0) + 1));
    setSubExams(((subs ?? []) as any[]).map((s) => ({ ...s, test_count: counts.get(s.id) ?? 0 })));
    if (user && ex) {
      const { data: u } = await supabase.from("exam_unlocks" as any).select("id").eq("user_id", user.id).eq("exam_id", id).maybeSingle();
      setUnlocked(!!u);
    } else setUnlocked(false);
    setLoading(false);
  };

  useEffect(() => { load(); }, [id, user]);

  const payForExam = async () => {
    if (!exam || !exam.price) return;
    if (!user) { navigate(`/signup?redirect=${encodeURIComponent(`/exam/${id}`)}`); return; }
    setPaying(true);
    try {
      const ok = await loadRazorpay();
      if (!ok) throw new Error("Failed to load payment gateway");
      const { data: orderData, error: orderErr } = await supabase.functions.invoke("razorpay-create-order", {
        body: {
          amount: Math.round(Number(exam.price) * 100), currency: "INR",
          receipt: `exam_${exam.id.slice(0, 8)}_${Date.now()}`,
          notes: { exam_id: exam.id, user_id: user.id },
        },
      });
      if (orderErr || !orderData?.order_id) throw new Error(orderErr?.message || "Could not create order");
      const { data: paymentRow, error: insertErr } = await (supabase.from("test_payments") as any).insert({
        exam_id: exam.id, user_id: user.id, student_id: user.id,
        amount: Number(exam.price), razorpay_order_id: orderData.order_id, status: "created",
      }).select("id").single();
      if (insertErr) throw insertErr;
      const rzp = new window.Razorpay({
        key: orderData.key_id, amount: orderData.amount, currency: orderData.currency,
        name: "TestNexa", description: exam.name, order_id: orderData.order_id,
        prefill: { name: profile?.name ?? "", contact: profile?.mobile ?? "", email: user.email ?? "" },
        theme: { color: "#0ea5e9" },
        handler: async (resp: any) => {
          try {
            const { data: vData, error: vErr } = await supabase.functions.invoke("razorpay-verify-payment", {
              body: {
                razorpay_order_id: resp.razorpay_order_id,
                razorpay_payment_id: resp.razorpay_payment_id,
                razorpay_signature: resp.razorpay_signature,
                payment_row_id: paymentRow.id,
              },
            });
            if (vErr || !vData?.success) throw new Error(vErr?.message || "Verification failed");
            const unlockedNow = await refreshUnlockStatus(user.id, exam.id);
            toast({
              title: "Payment successful",
              description: unlockedNow ? "All tests unlocked." : "Payment received. Access is syncing, please wait a moment.",
            });
            await load();
          } catch (e: any) {
            toast({ title: "Verification failed", description: e.message, variant: "destructive" });
          } finally { setPaying(false); }
        },
        modal: { ondismiss: () => { setPaying(false); toast({ title: "Payment cancelled" }); } },
      });
      rzp.on("payment.failed", (resp: any) => {
        toast({ title: "Payment failed", description: resp?.error?.description || "Try again", variant: "destructive" });
        setPaying(false);
      });
      rzp.open();
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
      setPaying(false);
    }
  };

  if (!loading && !exam) return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <Card><CardContent className="py-12 text-center space-y-3">
        <p className="text-muted-foreground">Exam not found.</p>
        <Button asChild><Link to="/">Home</Link></Button>
      </CardContent></Card>
    </div>
  );

  const th = exam ? getExamTheme(exam.color_scheme) : getExamTheme("default");

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col">
      {exam && <SEO title={`${exam.name} - Mock Tests | TestNexa`} description={`${exam.name} mock tests, sub-exams and practice papers for ${exam.exam_codes ?? "competitive exams"}.`} path={`/exam/${exam.id}`} />}
      <SiteHeader />

      <main className="container py-6 md:py-10 max-w-6xl flex-1">
        <Button asChild variant="ghost" size="sm" className="mb-4">
          <Link to="/"><ArrowLeft className="h-4 w-4" /> Back</Link>
        </Button>

        {loading || !exam ? (
          <>
            <Skeleton className="h-40 w-full mb-6 rounded-2xl" />
            <Skeleton className="h-6 w-40 mb-4" />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3, 4, 5, 6].map((i) => <Skeleton key={i} className="h-44 rounded-2xl" />)}
            </div>
          </>
        ) : (
          <>
            <Card className={`${th.cardBg} border-2 mb-6`}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-3">
                  <div className={`h-14 w-14 rounded-xl flex items-center justify-center text-3xl shrink-0 ${th.iconBg} ${th.iconText}`}>
                    {exam.icon_emoji ?? "📘"}
                  </div>
                  {exam.badge_label && (
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${th.badgeBg} ${th.badgeText}`}>{exam.badge_label}</span>
                  )}
                </div>
                <h1 className={`text-2xl md:text-3xl font-bold mt-3 ${th.title}`}>{exam.name}</h1>
                {exam.name_hi && <div className={`text-base ${th.meta}`}>{exam.name_hi}</div>}
                {exam.exam_codes && <div className="text-sm text-muted-foreground mt-2">{exam.exam_codes}</div>}
                {exam.is_paid && exam.price && (
                  <div className="mt-4 flex items-center gap-3 flex-wrap">
                    <span className="inline-flex items-center text-2xl font-bold"><IndianRupee className="h-5 w-5" />{exam.price}</span>
                    {exam.mrp && exam.mrp > exam.price && (<span className="line-through text-muted-foreground">₹{exam.mrp}</span>)}
                    {unlocked ? (
                      <Badge className="gap-1"><ShieldCheck className="h-3 w-3" /> Unlocked</Badge>
                    ) : (
                      <Button onClick={payForExam} disabled={paying}>
                        {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
                        Unlock all tests
                      </Button>
                    )}
                  </div>
                )}
                {freeCategorySlug && (
                  <div className="mt-3">
                    <Button asChild variant="outline" className="bg-success/10 border-success text-success hover:bg-success/20 hover:text-success">
                      <Link to={`/category/${freeCategorySlug}`}>🎁 Want a free mock test? Click here</Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            <h2 className="text-xl font-bold mb-3">Choose an exam</h2>
            {subExams.length === 0 ? (
              <Card><CardContent className="py-12 text-center text-muted-foreground">No sub-exams added yet.</CardContent></Card>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {subExams.map((s) => (
                  <Link
                    key={s.id} to={`/sub-exam/${s.id}`}
                    className={`block rounded-2xl border p-5 transition-all hover:shadow-lg hover:-translate-y-0.5 ${th.cardBg}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className={`h-12 w-12 rounded-xl flex items-center justify-center text-2xl shrink-0 ${th.iconBg} ${th.iconText}`}>
                        {s.icon_emoji ?? "📘"}
                      </div>
                      {s.badge_label && (
                        <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${th.badgeBg} ${th.badgeText}`}>{s.badge_label}</span>
                      )}
                    </div>
                    <h3 className={`text-lg font-bold mt-3 ${th.title}`}>{s.name}</h3>
                    {s.name_hi && <div className={`text-xs ${th.meta}`}>{s.name_hi}</div>}
                    {s.exam_codes && <div className="text-xs text-muted-foreground mt-2 line-clamp-1">{s.exam_codes}</div>}
                    <div className={`mt-4 pt-3 border-t border-current/10 flex items-center justify-between text-xs ${th.meta}`}>
                      <span className="font-semibold">{s.test_count} Tests</span>
                      <span className={`inline-flex items-center font-semibold ${th.exploreText}`}>
                        Explore <ArrowRight className="h-3 w-3" />
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}
