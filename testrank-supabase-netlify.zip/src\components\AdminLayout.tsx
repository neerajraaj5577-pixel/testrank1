import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { LayoutDashboard, FileText, LogOut, GraduationCap, Sparkles, IndianRupee, FolderTree, ListChecks, BookOpen } from "lucide-react";
import { adminLogout } from "@/lib/admin-auth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import ThemeToggle from "@/components/ThemeToggle";
import logo from "@/assets/logo.png";

const nav = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/admin/tests", label: "Tests", icon: FileText },
  { to: "/admin/questions", label: "Questions", icon: ListChecks },
  { to: "/admin/categories", label: "Categories", icon: FolderTree },
  { to: "/admin/exams", label: "Exams", icon: BookOpen },
  { to: "/admin/question-ai", label: "Question AI", icon: Sparkles },
  { to: "/admin/students", label: "Students", icon: GraduationCap },
  { to: "/admin/payments", label: "Payments", icon: IndianRupee },
];

export default function AdminLayout() {
  const navigate = useNavigate();
  const handleLogout = () => {
    adminLogout();
    navigate("/admin/login", { replace: true });
  };

  return (
    <div className="flex min-h-screen w-full bg-background">
      <aside className="hidden md:flex w-60 flex-col border-r bg-card">
        <div className="h-16 flex items-center px-4 border-b gap-2">
          <img src={logo} alt="TestNexa" className="h-8 w-auto" />
          <span className="font-bold text-sm text-muted-foreground">Admin</span>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                  isActive
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground",
                )
              }
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t space-y-1">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs text-muted-foreground">Theme</span>
            <ThemeToggle />
          </div>
          <Button variant="ghost" className="w-full justify-start" onClick={handleLogout}>
            <LogOut className="h-4 w-4" /> Logout
          </Button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden h-14 flex items-center justify-between px-4 border-b bg-card">
          <img src={logo} alt="TestNexa" className="h-7 w-auto" />
          <div className="flex items-center gap-1">
            <ThemeToggle />
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </header>
        <nav className="md:hidden flex border-b bg-card overflow-x-auto">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                cn(
                  "flex-shrink-0 px-4 py-2 text-sm font-medium border-b-2",
                  isActive ? "border-primary text-primary" : "border-transparent text-muted-foreground",
                )
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <main className="flex-1 p-4 md:p-8 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
