import ExamLandingPage from "@/components/ExamLandingPage";

const RELATED_ALL = [
  { name: "SSC Mock Test", path: "/ssc-mock-test" },
  { name: "Banking Mock Test", path: "/banking-mock-test" },
  { name: "Railway Mock Test", path: "/railway-mock-test" },
  { name: "UPSC Mock Test", path: "/upsc-mock-test" },
  { name: "Daily Quiz", path: "/daily-quiz" },
  { name: "Current Affairs", path: "/daily-current-affairs" },
  { name: "Previous Year Papers", path: "/previous-year-papers" },
  { name: "Free Mock Tests", path: "/free-mock-tests" },
  { name: "Online Test Series", path: "/online-test-series" },
];

const r = (exclude: string[]) => RELATED_ALL.filter((x) => !exclude.includes(x.path)).slice(0, 6);

export const MockTests = () => (
  <ExamLandingPage
    path="/mock-tests"
    title="Mock Tests Online – SSC, Banking, Railway, UPSC | TestNexa"
    description="Attempt expert-curated online mock tests for every major government exam. Real exam interface, instant scores, detailed analytics & all-India ranking."
    keywords="mock test, online mock test, mock test platform, free mock test, government exam mock test"
    breadcrumb={[{ name: "Mock Tests", path: "/mock-tests" }]}
    hero={{
      eyebrow: "All Mock Tests",
      h1: "Online Mock Tests for Every Government Exam",
      subheading: "From SSC and Banking to Railways, UPSC and State PSCs — practice the most realistic mock tests with section-wise analysis and live ranking.",
      ctaPath: "/", ctaLabel: "Browse All Tests",
    }}
    highlights={[
      "Real exam interface with section-wise palette",
      "Auto-submit & full-screen anti-cheat mode",
      "Bilingual: English & हिंदी",
      "Per-question time tracking",
      "Detailed performance analytics",
      "All-India rank after every test",
    ]}
    sections={[
      { h2: "Why TestNexa Mock Tests?", body: "TestNexa is built by educators and engineers who understand how Indian government exams actually work. Every mock test mirrors the latest pattern, marking scheme and difficulty curve of the real paper. Whether you are preparing for SSC CGL, IBPS PO, RRB NTPC or UPSC Prelims, you get a paper that feels exactly like the official exam — same number of questions, same time limit, same negative marking, same bilingual support." },
      { h2: "What you get with every mock test", body: "Each test ships with a clean exam-mode UI, a section-aware question palette, automatic timer, save-and-mark-for-review, language toggle, and instant scoring the moment you submit. After the test, our analytics engine breaks down accuracy, average time per question, weak topics and your percentile against every other student who has attempted the same paper." },
      { h2: "Free vs Paid Mock Tests", body: "We keep a strong free library so anyone can start practicing immediately. Paid test series unlock complete category packs, full-length papers, and previous-year-pattern simulations. Every paid pack gives lifetime access — buy once, practice forever." },
    ]}
    examTopics={["SSC CGL", "SSC CHSL", "IBPS PO", "SBI PO", "RRB NTPC", "RRB Group D", "UPSC Prelims", "State PSC", "Police Exams", "Teaching Exams", "Defence Exams"]}
    faqs={[
      { q: "Are TestNexa mock tests free?", a: "Yes, a large library of mock tests is free. Premium full-length tests are available in affordable category packs with lifetime access." },
      { q: "Do mock tests follow the latest exam pattern?", a: "Every mock test is regularly updated to match the latest official notification, including marking scheme, negative marking, sections and timing." },
      { q: "Will I get an All-India Rank?", a: "Yes. As soon as you submit the test, you receive your score, percentile and rank against every other candidate who attempted the same test." },
      { q: "Can I practice in Hindi?", a: "Absolutely. Most mock tests are fully bilingual — switch between English and Hindi anytime during the attempt." },
    ]}
    related={r(["/mock-tests"])}
  />
);

export const FreeMockTests = () => (
  <ExamLandingPage
    path="/free-mock-tests"
    title="Free Mock Tests Online for Govt Exams | TestNexa"
    description="100% free mock tests for SSC, Banking, Railway, UPSC and state government exams. No payment, no login required to start your first test."
    keywords="free mock test, free online test, free mock test online, free government exam mock test"
    breadcrumb={[{ name: "Free Mock Tests", path: "/free-mock-tests" }]}
    hero={{
      eyebrow: "100% Free",
      h1: "Free Mock Tests for Every Competitive Exam",
      subheading: "Start practicing without paying a rupee. Real exam interface, instant scoring and detailed analytics — completely free.",
      ctaPath: "/", ctaLabel: "Start Free Test",
    }}
    highlights={[
      "Zero payment to start practicing",
      "Real-exam UI & timer",
      "Instant score and rank",
      "Section-wise breakdown",
      "Bilingual English / Hindi",
      "Works on mobile, tablet & desktop",
    ]}
    sections={[
      { h2: "Why we offer free mock tests", body: "Quality exam practice should not depend on what you can afford. TestNexa keeps a huge library of free mock tests covering reasoning, quantitative aptitude, English, general awareness and current affairs so that every student in India can practice with the same tools." },
      { h2: "How free is 'free'?", body: "No credit card. No trial timer. No locked questions in the middle of the test. Sign up with just your email and start attempting any test marked Free across SSC, Banking, Railways, UPSC and State exams." },
      { h2: "From free to full preparation", body: "Once you find a category that matches your target exam, you can optionally upgrade to a paid pack to unlock full-length simulations and previous year pattern papers — all with lifetime access." },
    ]}
    examTopics={["SSC", "Banking", "Railway", "UPSC", "State PSC", "Reasoning", "Quant", "English", "GK", "Current Affairs"]}
    faqs={[
      { q: "Do I need to pay anything to attempt a free mock test?", a: "No. All tests labelled Free are 100% free, with no hidden charges." },
      { q: "Do I need to create an account?", a: "Yes, a free account is required so we can save your scores and show you your rank — but signup is completely free." },
      { q: "Are free tests less detailed than paid ones?", a: "No. Free tests have the same exam interface, analytics and ranking as paid tests. Paid packs add full-length papers and additional simulations." },
    ]}
    related={r(["/free-mock-tests"])}
  />
);

export const FreeOnlineTest = () => (
  <ExamLandingPage
    path="/free-online-test"
    title="Free Online Tests & Quizzes for Competitive Exams | TestNexa"
    description="Free online test series for SSC, Banking, Railway, UPSC and state exams. Topic-wise quizzes, full mocks and daily current affairs — all free."
    keywords="free online test, free online quiz, online test free, online practice test"
    breadcrumb={[{ name: "Free Online Test", path: "/free-online-test" }]}
    hero={{
      h1: "Free Online Tests for Every Government Exam",
      subheading: "Topic quizzes, full-length mocks and daily current affairs — practice anywhere, anytime, on any device, completely free.",
      ctaPath: "/", ctaLabel: "Start Practicing Free",
    }}
    highlights={[
      "No payment required",
      "Topic, sectional & full mocks",
      "Daily current affairs quiz",
      "Instant detailed analysis",
      "AI-powered weakness detection",
      "Mobile-first experience",
    ]}
    sections={[
      { h2: "Practice anytime from any device", body: "TestNexa works smoothly on low-end Android phones, tablets and desktops. The exam interface is mobile-first, lightweight and works even on slow networks — so you can squeeze in a quick quiz during a commute or attempt a full-length mock at home." },
      { h2: "What kinds of free tests are available?", body: "Topic-level quizzes (e.g. ratio & proportion, syllogism, antonyms), section-level tests (e.g. full reasoning section), full-length mock tests, previous-year pattern papers and the daily current affairs quiz." },
    ]}
    faqs={[
      { q: "Is TestNexa really free to use?", a: "Yes. Most of our practice content is free. Paid packs are optional add-ons for full-length premium series." },
      { q: "Can I track my progress?", a: "Yes. Your dashboard shows every test you've attempted, accuracy trends, weak chapters and your percentile." },
    ]}
    related={r(["/free-online-test"])}
  />
);

export const ExamCategoriesPage = () => (
  <ExamLandingPage
    path="/exam-categories"
    title="All Exam Categories – Govt Exam Preparation | TestNexa"
    description="Browse SSC, Banking, Railway, UPSC, State PSC, Police, Defence and Teaching exam categories. Mock tests, quizzes and previous year papers in one place."
    keywords="exam categories, government exam, competitive exam categories, exam list"
    breadcrumb={[{ name: "Exam Categories", path: "/exam-categories" }]}
    hero={{
      h1: "Pick Your Exam. Start Preparing.",
      subheading: "All major Indian competitive exams in one place — every category comes with mock tests, topic quizzes and previous year papers.",
      ctaPath: "/", ctaLabel: "Browse Categories",
    }}
    highlights={["50+ exams covered", "Updated patterns", "Bilingual content", "Free + paid options", "Section-wise practice", "Lifetime access on paid"]}
    sections={[
      { h2: "Find your exam in seconds", body: "TestNexa organises every exam into clear categories — SSC, Banking, Railways, UPSC, State PSC, Police, Defence and Teaching. Tap a category to see every available mock test, full-length paper and topic quiz, with the latest exam pattern automatically applied." },
      { h2: "One platform for every stage", body: "Prelims, Mains, Tier-1, Tier-2 — TestNexa supports every stage of multi-tier exams with the right paper format, marking scheme and timing for each." },
    ]}
    examTopics={["SSC CGL", "SSC CHSL", "SSC GD", "IBPS PO", "IBPS Clerk", "SBI PO", "SBI Clerk", "RRB NTPC", "RRB Group D", "UPSC Prelims", "UPPSC", "MPPSC", "BPSC", "Police Constable", "CTET", "NDA", "CDS"]}
    faqs={[
      { q: "Which exams are covered on TestNexa?", a: "SSC, Banking (IBPS, SBI, RBI), Railways (RRB), UPSC, State PSC, Police, Defence and Teaching exams — with new categories added regularly." },
      { q: "Can I switch between exam categories?", a: "Yes. Your account works across every category and your progress is tracked separately for each." },
    ]}
    related={r(["/exam-categories"])}
  />
);

export const SSCMockTest = () => (
  <ExamLandingPage
    path="/ssc-mock-test"
    title="SSC Mock Test 2026 – Free CGL, CHSL, GD Tests | TestNexa"
    description="Free SSC mock tests for CGL, CHSL, MTS, GD and CPO. Latest pattern, bilingual papers, instant analysis & all-India ranking on TestNexa."
    keywords="SSC mock test, SSC CGL mock test, SSC CHSL mock test, SSC GD mock test, free SSC mock test, SSC test series"
    breadcrumb={[{ name: "SSC Mock Test", path: "/ssc-mock-test" }]}
    hero={{
      eyebrow: "Staff Selection Commission",
      h1: "SSC Mock Tests – CGL, CHSL, GD, MTS, CPO",
      subheading: "Free + premium SSC mock tests built on the latest official pattern. Section-wise palette, negative marking, instant ranking — exactly like the real SSC exam.",
      ctaPath: "/", ctaLabel: "Start SSC Mock Test",
    }}
    highlights={[
      "Tier-1, Tier-2 & Tier-3 papers",
      "Latest 2025-26 SSC pattern",
      "Bilingual English & हिंदी",
      "Negative marking enabled",
      "Sectional & full-length tests",
      "Previous year SSC papers",
    ]}
    sections={[
      { h2: "About SSC Exams", body: "The Staff Selection Commission (SSC) conducts some of India's most competitive recruitment exams — SSC CGL, SSC CHSL, SSC MTS, SSC GD Constable and SSC CPO. Every year millions of aspirants compete for a limited number of vacancies, which makes consistent mock test practice the single biggest deciding factor between selection and rejection." },
      { h2: "SSC CGL Mock Test", body: "Combined Graduate Level papers cover Reasoning, Quantitative Aptitude, English Comprehension and General Awareness. TestNexa's CGL mocks follow the official Tier-1 timing of 60 minutes for 100 questions with the standard 0.50 negative marking, plus dedicated Tier-2 sectional tests for advanced Quant and English." },
      { h2: "SSC CHSL & GD Mock Test", body: "Our CHSL papers strictly follow the 100-question, 60-minute pattern across all four sections. SSC GD Constable mocks include the latest Hindi-medium support and are tuned to the difficulty level of recent CAPF recruitment papers." },
      { h2: "How to use SSC mocks effectively", body: "Start with a diagnostic free mock to identify weak sections. Move into topic quizzes for those weaknesses. Take a full-length mock every 2–3 days. Review every wrong answer with the explanation. Track your accuracy and average time per question over weeks — improvement compounds quickly." },
    ]}
    examTopics={["SSC CGL Tier 1", "SSC CGL Tier 2", "SSC CHSL", "SSC MTS", "SSC GD Constable", "SSC CPO", "SSC JE", "SSC Stenographer"]}
    faqs={[
      { q: "Are TestNexa SSC mock tests free?", a: "Yes, a large set of SSC mock tests is free. Full-length premium SSC test series can be unlocked with affordable lifetime-access packs." },
      { q: "Do mocks follow the latest SSC pattern?", a: "Yes. CGL, CHSL, MTS and GD mocks are updated to match the most recent official notification — including section weightage, time limit and negative marking." },
      { q: "Are SSC mock tests available in Hindi?", a: "Yes. All SSC mocks are bilingual — switch between English and Hindi during the attempt." },
      { q: "Will I get rank and previous year papers?", a: "Yes. Every mock gives instant rank, percentile and detailed analysis. Previous year SSC papers are also available with full solutions." },
    ]}
    related={r(["/ssc-mock-test"])}
  />
);

export const BankingMockTest = () => (
  <ExamLandingPage
    path="/banking-mock-test"
    title="Banking Mock Test – IBPS PO, SBI PO, Clerk | TestNexa"
    description="Free banking mock tests for IBPS PO, SBI PO, IBPS Clerk, SBI Clerk and RBI exams. Latest pattern, sectional timing, instant analysis."
    keywords="banking mock test, IBPS PO mock test, SBI PO mock test, IBPS clerk mock test, bank exam mock test"
    breadcrumb={[{ name: "Banking Mock Test", path: "/banking-mock-test" }]}
    hero={{
      eyebrow: "IBPS · SBI · RBI",
      h1: "Banking Mock Tests for PO, Clerk & RBI Exams",
      subheading: "Crack IBPS PO, SBI PO, Clerk and RBI Grade B with mocks that match the official sectional timing, marking and difficulty.",
      ctaPath: "/", ctaLabel: "Start Banking Mock",
    }}
    highlights={[
      "Sectional timing per official pattern",
      "Prelims + Mains coverage",
      "Reasoning, Quant, English, GA",
      "Banking awareness & computer aptitude",
      "Real exam negative marking",
      "All-India bank ranking",
    ]}
    sections={[
      { h2: "Banking exams covered", body: "TestNexa covers every major banking recruitment exam — IBPS PO, IBPS Clerk, IBPS RRB Officer, IBPS RRB Assistant, SBI PO, SBI Clerk, RBI Assistant and RBI Grade B. Each mock follows the exact sectional timing pattern of its respective exam." },
      { h2: "IBPS PO & Clerk Mock Test", body: "Our IBPS PO Prelims mocks deliver 100 questions across Reasoning, Quantitative Aptitude and English with the official 20-minute sectional timer. Mains mocks include the descriptive section and Banking Awareness with current affairs from the last 6 months." },
      { h2: "SBI PO & Clerk Mock Test", body: "SBI PO mocks follow the latest pattern with 30 minutes for Reasoning, 20 minutes for Quant and 20 minutes for English in Prelims, plus full Mains coverage with Reasoning + Computer Aptitude as a single section." },
      { h2: "How to crack banking exams with TestNexa", body: "Banking exams reward speed more than depth. Use sectional mocks daily to build topic-wise speed, then switch to full-length mocks closer to your exam to build stamina. Use the per-question timer in your analytics to identify questions you should have skipped — that one habit alone often pushes scores past the cutoff." },
    ]}
    examTopics={["IBPS PO Prelims", "IBPS PO Mains", "IBPS Clerk", "SBI PO", "SBI Clerk", "IBPS RRB", "RBI Assistant", "RBI Grade B"]}
    faqs={[
      { q: "Do TestNexa banking mocks have sectional timing?", a: "Yes. PO and Clerk Prelims mocks enforce the exact official sectional time limits." },
      { q: "Is banking awareness updated regularly?", a: "Yes. Banking awareness and current affairs are refreshed every month so you always practice on the latest information." },
      { q: "Can I attempt banking mocks in Hindi?", a: "Most quantitative and reasoning mocks support Hindi. The English language section is, by exam design, English-only." },
    ]}
    related={r(["/banking-mock-test"])}
  />
);

export const RailwayMockTest = () => (
  <ExamLandingPage
    path="/railway-mock-test"
    title="Railway Mock Test – RRB NTPC, Group D, ALP | TestNexa"
    description="Free railway mock tests for RRB NTPC, Group D, ALP and JE. Real CBT exam interface, bilingual support, instant analysis & rank."
    keywords="railway mock test, RRB NTPC mock test, RRB Group D mock test, RRB ALP mock test, railway exam test series"
    breadcrumb={[{ name: "Railway Mock Test", path: "/railway-mock-test" }]}
    hero={{
      eyebrow: "Railway Recruitment Board",
      h1: "Railway Mock Tests for NTPC, Group D, ALP & JE",
      subheading: "Practice on a real CBT-style interface that matches the official RRB pattern. Bilingual support, negative marking and instant ranking.",
      ctaPath: "/", ctaLabel: "Start Railway Mock",
    }}
    highlights={[
      "Real RRB CBT interface",
      "NTPC, Group D, ALP, JE coverage",
      "Bilingual English / Hindi",
      "1/3 negative marking applied",
      "Section-wise palette",
      "Previous year RRB papers",
    ]}
    sections={[
      { h2: "About RRB exams", body: "Railway Recruitment Board (RRB) exams are India's largest recruitment drives. RRB NTPC, RRB Group D, RRB ALP and RRB JE collectively attract crores of applicants. The CBT format demands speed, accuracy and the right exam-day temperament — all of which can only be built through repeated mock practice." },
      { h2: "RRB NTPC Mock Test", body: "Our NTPC CBT-1 mocks follow the official 100-question, 90-minute format covering General Awareness, Mathematics and General Intelligence & Reasoning, with the standard 1/3 negative marking. CBT-2 mocks adapt to the appropriate level for each pay grade." },
      { h2: "RRB Group D Mock Test", body: "Group D mocks deliver 100 questions in 90 minutes covering Mathematics, General Intelligence & Reasoning, General Science and General Awareness on Current Affairs. The Hindi-medium toggle is widely used by Group D aspirants and is fully supported." },
    ]}
    examTopics={["RRB NTPC CBT 1", "RRB NTPC CBT 2", "RRB Group D", "RRB ALP", "RRB Technician", "RRB JE", "RPF Constable", "RPF SI"]}
    faqs={[
      { q: "Are RRB mocks available in Hindi?", a: "Yes. All RRB mocks are bilingual and you can switch language during the attempt." },
      { q: "Do mocks follow the latest RRB pattern?", a: "Yes. NTPC, Group D, ALP and JE mocks are updated whenever RRB changes the pattern or syllabus." },
      { q: "Is negative marking applied?", a: "Yes. The official 1/3 negative marking is enforced just like the real CBT." },
    ]}
    related={r(["/railway-mock-test"])}
  />
);

export const UPSCMockTest = () => (
  <ExamLandingPage
    path="/upsc-mock-test"
    title="UPSC Mock Test – Prelims CSAT & GS Test Series | TestNexa"
    description="Free UPSC Prelims mock tests for GS Paper 1 and CSAT. Latest UPSC pattern, instant analytics, current affairs based questions."
    keywords="UPSC mock test, UPSC prelims mock test, UPSC test series, IAS mock test, CSAT mock test"
    breadcrumb={[{ name: "UPSC Mock Test", path: "/upsc-mock-test" }]}
    hero={{
      eyebrow: "Civil Services",
      h1: "UPSC Prelims Mock Tests – GS & CSAT",
      subheading: "Build the analytical edge needed for UPSC Prelims with rigorously curated GS Paper 1 and CSAT mock tests, complete with detailed explanations.",
      ctaPath: "/", ctaLabel: "Start UPSC Mock",
    }}
    highlights={[
      "GS Paper 1 + CSAT coverage",
      "100 questions, 2 hours format",
      "1/3 negative marking",
      "Detailed explanations",
      "Static + current affairs mix",
      "All-India aspirant ranking",
    ]}
    sections={[
      { h2: "Why mock tests are non-negotiable for UPSC", body: "UPSC Prelims is less about how much you know and more about how well you eliminate. Even the strongest aspirants fail to clear cutoff if they don't repeatedly train their judgement on quality mock tests. TestNexa's UPSC mocks are designed to replicate the unpredictability of the real exam — same 100-question format, same 2-hour window, same 1/3 negative marking." },
      { h2: "GS Paper 1 Mock Tests", body: "Our GS mocks balance static topics (Polity, History, Geography, Economy, Environment, Science) with the latest year of relevant current affairs. Each question carries a clean explanation with source references so learning continues even after the test ends." },
      { h2: "CSAT Mock Tests", body: "CSAT is qualifying, but every year thousands lose the year because they ignored it. Our CSAT mocks focus on Reading Comprehension, Logical Reasoning and Basic Numeracy at the exact difficulty level of recent UPSC papers." },
    ]}
    examTopics={["UPSC Prelims GS", "UPSC CSAT", "Polity", "History", "Geography", "Economy", "Environment", "Science & Tech", "Current Affairs"]}
    faqs={[
      { q: "Do mocks include current affairs?", a: "Yes. Every GS mock has a healthy mix of static topics and current affairs from the last 12 months." },
      { q: "Are explanations provided?", a: "Yes. Every question comes with a clean, sourced explanation that you can review after submission." },
      { q: "Is CSAT covered?", a: "Yes. We provide dedicated CSAT mocks tuned to the official 80-question, 2-hour format." },
    ]}
    related={r(["/upsc-mock-test"])}
  />
);

export const StateExams = () => (
  <ExamLandingPage
    path="/state-exams"
    title="State PSC Mock Tests – UPPSC, BPSC, MPPSC & More | TestNexa"
    description="Mock tests for every State PSC and state government exam — UPPSC, BPSC, MPPSC, RPSC and state police, teaching, and clerical recruitment."
    keywords="state PSC mock test, UPPSC mock test, BPSC mock test, MPPSC mock test, state exam preparation"
    breadcrumb={[{ name: "State Exams", path: "/state-exams" }]}
    hero={{
      h1: "State Government Exam Mock Tests",
      subheading: "From UPPSC and BPSC to state police and teaching exams — get state-specific mock tests with regional language support and updated patterns.",
      ctaPath: "/", ctaLabel: "Browse State Exams",
    }}
    highlights={["UPPSC, BPSC, MPPSC, RPSC", "State Police & SI exams", "State Teaching exams (TET)", "Hindi medium supported", "State current affairs", "Region-specific GK"]}
    sections={[
      { h2: "Why dedicated State PSC practice matters", body: "State PSC papers test state-specific history, geography, polity and current affairs that national-level test series rarely cover well. TestNexa's state exam mocks are curated by topic experts who actively track each state's official notifications and recent question trends." },
      { h2: "Bilingual & Hindi medium first", body: "Most state exams are taken in Hindi. Our state-exam mocks are designed Hindi-first — questions read naturally in Hindi rather than feeling like translations from English." },
    ]}
    examTopics={["UPPSC", "BPSC", "MPPSC", "RPSC", "UKPSC", "JKPSC", "UP Police", "Bihar Police", "MP Police", "UPTET", "BTET", "MPTET"]}
    faqs={[
      { q: "Are state mocks available in regional languages?", a: "Hindi medium is supported across major Hindi-belt state exams. More regional languages are being added." },
      { q: "Are state-specific current affairs covered?", a: "Yes. We track state government schemes, appointments and events for each major State PSC." },
    ]}
    related={r(["/state-exams"])}
  />
);

export const OnlineTestSeries = () => (
  <ExamLandingPage
    path="/online-test-series"
    title="Online Test Series for Government Exams | TestNexa"
    description="Complete online test series for SSC, Banking, Railway, UPSC and State exams. Full-length mocks, sectional tests, previous year papers — lifetime access."
    keywords="online test series, test series, online mock test series, government exam test series, exam test series"
    breadcrumb={[{ name: "Online Test Series", path: "/online-test-series" }]}
    hero={{
      h1: "Online Test Series for Every Government Exam",
      subheading: "A structured, end-to-end test series for every major exam — sectional tests, full-length mocks, previous year papers and live ranking.",
      ctaPath: "/", ctaLabel: "View Test Series",
    }}
    highlights={["End-to-end coverage", "Lifetime access on paid", "Updated to latest pattern", "Bilingual where applicable", "Per-test analytics", "Comparative percentile"]}
    sections={[
      { h2: "What is a TestNexa test series?", body: "A test series is a structured set of tests that takes you from the start of your preparation to exam day. It includes diagnostic tests, topic-wise quizzes, sectional mocks, full-length papers and previous year pattern simulations — all sequenced for steady improvement." },
      { h2: "Why lifetime access matters", body: "Most platforms charge you yearly for the same content. TestNexa's paid test series come with lifetime access — buy once, use the same series across multiple exam attempts and recommend it confidently to friends." },
    ]}
    faqs={[
      { q: "How is a test series different from a single mock?", a: "A series is a sequenced bundle that covers your full preparation — diagnostics, topic tests, sectional mocks and full-length papers. Single mocks are useful, but a series builds long-term improvement." },
      { q: "Is the test series updated for new patterns?", a: "Yes. Whenever an exam pattern changes, the affected series is updated free of charge for existing buyers." },
    ]}
    related={r(["/online-test-series"])}
  />
);

export const TestSeriesPage = () => (
  <ExamLandingPage
    path="/test-series"
    title="Test Series for SSC, Banking, Railway, UPSC | TestNexa"
    description="Affordable test series with full-length mocks, previous year papers and live ranking for every major Indian competitive exam."
    keywords="test series, mock test series, exam test series, online test series"
    breadcrumb={[{ name: "Test Series", path: "/test-series" }]}
    hero={{
      h1: "Test Series Built for Real Exam Success",
      subheading: "Pick the test series that matches your target exam and get a clear, structured path to a top rank.",
      ctaPath: "/", ctaLabel: "Browse Test Series",
    }}
    highlights={["Sequenced from basic to advanced", "Topic + sectional + full mocks", "Pattern-locked to latest notification", "Lifetime access", "Live ranking", "Detailed analysis after every test"]}
    sections={[
      { h2: "How TestNexa test series are structured", body: "Each series begins with a diagnostic test that maps your strengths and weaknesses. From there, you progress through topic quizzes, sectional mocks and full-length papers, with periodic previous-year-pattern simulations to benchmark your readiness." },
    ]}
    faqs={[
      { q: "Is the test series time-bound?", a: "No. Paid series come with lifetime access — practice at your own pace." },
      { q: "Can I see how I rank against others?", a: "Yes. Every test in the series produces an All-India rank against everyone else who has attempted that test." },
    ]}
    related={r(["/test-series"])}
  />
);

export const PreviousYearPapers = () => (
  <ExamLandingPage
    path="/previous-year-papers"
    title="Previous Year Question Papers with Solutions | TestNexa"
    description="Solve previous year papers for SSC, Banking, Railway, UPSC and State exams. Real exam interface, bilingual mode, full solutions and expert tips."
    keywords="previous year papers, previous year question paper, PYQ, previous year mock test, SSC previous year papers"
    breadcrumb={[{ name: "Previous Year Papers", path: "/previous-year-papers" }]}
    hero={{
      h1: "Previous Year Papers — Solve Like It's the Real Exam",
      subheading: "Genuine previous year question papers across SSC, Banking, Railway, UPSC and State exams, served in a real exam interface with full solutions.",
      ctaPath: "/", ctaLabel: "Solve PYQs Now",
    }}
    highlights={["Authentic year-by-year papers", "Original marking scheme", "Detailed solutions", "Bilingual where applicable", "Compare with All-India rank", "Free + premium papers"]}
    sections={[
      { h2: "Why PYQs are the strongest practice tool", body: "Previous year papers reveal exactly how the exam thinks — which topics get repeated, which traps re-appear, and how the difficulty has trended over time. Solving 5 years of PYQs in real exam conditions usually beats 50 random mock tests." },
      { h2: "How to use TestNexa PYQs", body: "Start with the most recent year first to set your baseline. Then go backward year-by-year and after each paper, review every wrong answer with the explanation. This single habit builds the strongest pattern recognition you can have on exam day." },
    ]}
    faqs={[
      { q: "Are PYQs free?", a: "Many recent year PYQs are free. Some premium PYQ packs include detailed video-style explanations." },
      { q: "Do PYQs follow the original marking scheme?", a: "Yes. Each PYQ runs with the negative marking and timing of the actual exam in that year." },
    ]}
    related={r(["/previous-year-papers"])}
  />
);

export const DailyQuiz = () => (
  <ExamLandingPage
    path="/daily-quiz"
    title="Daily Quiz – Free GK, Reasoning, Quant & English | TestNexa"
    description="Free daily quiz for competitive exam aspirants. Reasoning, quantitative aptitude, English, GK and current affairs — fresh questions every day."
    keywords="daily quiz, daily online quiz, daily quiz for competitive exams, online quiz app, daily current affairs quiz"
    breadcrumb={[{ name: "Daily Quiz", path: "/daily-quiz" }]}
    hero={{
      eyebrow: "Free · 10 minutes a day",
      h1: "Daily Quiz to Sharpen Your Exam Edge",
      subheading: "A fresh free quiz every day across reasoning, quantitative aptitude, English, GK and current affairs — perfect for busy aspirants.",
      ctaPath: "/", ctaLabel: "Take Today's Quiz",
    }}
    highlights={["Fresh quiz every day", "10–15 minute format", "Topic rotation", "Detailed explanations", "Daily streak tracking", "100% free"]}
    sections={[
      { h2: "Why a daily quiz works", body: "Consistency beats intensity. A 10-minute quiz every day quietly builds vocabulary, mental math speed, GK recall and pattern recognition — the four pillars of competitive exam success. The TestNexa daily quiz is engineered to make that habit effortless." },
      { h2: "What's covered each week", body: "Across the week the quiz rotates through Reasoning, Quantitative Aptitude, English Vocabulary, Static GK and Current Affairs so that no area gets ignored. Streaks reward consistency and detailed explanations help you actually learn from mistakes." },
    ]}
    faqs={[
      { q: "Is the daily quiz really free?", a: "Yes, completely free with no signup wall." },
      { q: "How long is each quiz?", a: "10–15 minutes — designed to fit into a coffee break or commute." },
    ]}
    related={r(["/daily-quiz"])}
  />
);

export const DailyCurrentAffairs = () => (
  <ExamLandingPage
    path="/daily-current-affairs"
    title="Daily Current Affairs Quiz for Govt Exams | TestNexa"
    description="Daily current affairs quiz for SSC, Banking, Railway, UPSC and state exams. Stay updated with the latest national, international and economic news."
    keywords="daily current affairs, current affairs quiz, daily current affairs quiz, current affairs for competitive exams, today's current affairs"
    breadcrumb={[{ name: "Daily Current Affairs", path: "/daily-current-affairs" }]}
    hero={{
      h1: "Daily Current Affairs Quiz for Government Exams",
      subheading: "Stay exam-ready every single day with a curated 10-minute current affairs quiz covering national, international, economy, sports and awards.",
      ctaPath: "/", ctaLabel: "Today's Current Affairs",
    }}
    highlights={["Updated every morning", "National + international + economy", "Sports, awards, appointments", "Linked to UPSC + Banking syllabus", "Bilingual support", "100% free"]}
    sections={[
      { h2: "Why daily current affairs cannot be skipped", body: "Banking exams, SSC GA section, UPSC Prelims and almost every State PSC ride heavily on the last 12 months of current affairs. A daily 10-minute habit ensures you walk into the exam having seen every major news item — calmly and confidently." },
      { h2: "What our daily quiz covers", body: "National schemes, international relations, economy and budget, defence, science & tech, sports, awards & honours, books & authors, important days and obituaries — exactly the topics that recurring questions are pulled from." },
    ]}
    faqs={[
      { q: "How often is the current affairs quiz updated?", a: "Every morning. The previous day's important events are turned into a fresh quiz overnight." },
      { q: "Is it useful for UPSC and Banking together?", a: "Yes. Items are tagged so you can identify which exam each event is most relevant for." },
    ]}
    related={r(["/daily-current-affairs"])}
  />
);

export const CurrentAffairs = DailyCurrentAffairs;

export const GovernmentExamQuiz = () => (
  <ExamLandingPage
    path="/government-exam-quiz"
    title="Government Exam Quiz – Free Practice for Govt Jobs | TestNexa"
    description="Free quiz platform for every government job exam in India. Reasoning, Aptitude, GK, English and current affairs questions with instant scoring."
    keywords="government exam quiz, government job quiz, govt exam practice, online government exam quiz"
    breadcrumb={[{ name: "Government Exam Quiz", path: "/government-exam-quiz" }]}
    hero={{
      h1: "Free Quiz for Every Government Exam",
      subheading: "From SSC and Banking to Railways and State PSC — practice short, focused quizzes built specifically for government job aspirants.",
      ctaPath: "/", ctaLabel: "Start a Quiz",
    }}
    highlights={["Topic-wise quizzes", "Exam-aligned difficulty", "Instant explanations", "Mobile optimised", "Bilingual", "100% free"]}
    sections={[
      { h2: "Built specifically for government job aspirants", body: "Generic quiz apps test trivia. TestNexa's government exam quiz is engineered topic-by-topic to mirror what actually appears in SSC, Banking, Railway and State exams. Every question links back to a real syllabus item." },
    ]}
    examTopics={["Reasoning", "Quantitative Aptitude", "English", "General Awareness", "Computer Awareness", "Current Affairs", "Banking Awareness"]}
    faqs={[
      { q: "Are these quizzes free?", a: "Yes, all government exam quizzes are 100% free." },
      { q: "Can quizzes replace full mock tests?", a: "No — they're designed to complement mocks. Use quizzes daily for revision, and full mocks weekly for stamina." },
    ]}
    related={r(["/government-exam-quiz"])}
  />
);

export const ResultsRankings = () => (
  <ExamLandingPage
    path="/results-rankings"
    title="Results & All-India Rankings | TestNexa"
    description="Track your test results, percentile and All-India rank across every TestNexa mock test. Compete with thousands of aspirants live."
    keywords="exam ranking, all india rank, mock test rank, test results, online test ranking"
    breadcrumb={[{ name: "Results & Rankings", path: "/results-rankings" }]}
    hero={{
      h1: "Real-Time Results & All-India Rankings",
      subheading: "Every test you submit instantly gives you a score, percentile and rank — see exactly where you stand against thousands of aspirants.",
      ctaPath: "/my-tests", ctaLabel: "View My Results",
    }}
    highlights={["Instant rank after every test", "Percentile across all attempts", "Section-wise comparison", "Per-question time benchmark", "Topic-wise weakness map", "Progress over weeks"]}
    sections={[
      { h2: "Why rankings matter", body: "Knowing your absolute score is useful. Knowing where that score places you on an All-India scale is what tells you whether you would actually clear the cutoff. TestNexa shows your live percentile and rank after every single test." },
      { h2: "Beyond rank: deep analysis", body: "Each result includes section-wise accuracy, average time per question, the topics that hurt you most, and a clear comparison against the topper of that test. Use it to plan the next 7 days of preparation." },
    ]}
    faqs={[
      { q: "Is the All-India rank live?", a: "Yes. Your rank updates dynamically as new aspirants attempt the same test." },
      { q: "Where can I see all my past results?", a: "Inside your dashboard under My Tests — every attempt is saved with full analysis." },
    ]}
    related={r(["/results-rankings"])}
  />
);
