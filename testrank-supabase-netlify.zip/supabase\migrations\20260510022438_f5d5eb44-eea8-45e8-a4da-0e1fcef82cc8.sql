-- Exams system
CREATE TABLE public.exams (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  name_hi text,
  subtitle text,
  badge_label text,
  icon_emoji text DEFAULT '📘',
  color_scheme text NOT NULL DEFAULT 'blue',
  exam_codes text,
  position integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  is_paid boolean NOT NULL DEFAULT false,
  price numeric,
  mrp numeric,
  validity_days integer,
  display_test_count text,
  display_student_count text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active exams" ON public.exams FOR SELECT USING (is_active = true);
CREATE POLICY "Public can manage exams" ON public.exams FOR ALL USING (true) WITH CHECK (true);

CREATE TRIGGER update_exams_updated_at BEFORE UPDATE ON public.exams
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Link tests to exams (many-to-many)
CREATE TABLE public.exam_tests (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  exam_id uuid NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  test_id uuid NOT NULL,
  position integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (exam_id, test_id)
);
CREATE INDEX idx_exam_tests_exam_id ON public.exam_tests(exam_id);
CREATE INDEX idx_exam_tests_test_id ON public.exam_tests(test_id);

ALTER TABLE public.exam_tests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view exam_tests" ON public.exam_tests FOR SELECT USING (true);
CREATE POLICY "Public can manage exam_tests" ON public.exam_tests FOR ALL USING (true) WITH CHECK (true);

-- Exam unlocks
CREATE TABLE public.exam_unlocks (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  exam_id uuid NOT NULL,
  source text NOT NULL DEFAULT 'paid',
  unlocked_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (user_id, exam_id)
);

ALTER TABLE public.exam_unlocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert exam_unlocks" ON public.exam_unlocks FOR INSERT WITH CHECK (true);
CREATE POLICY "Public can read exam_unlocks" ON public.exam_unlocks FOR SELECT USING (true);

-- Add exam_id to test_payments
ALTER TABLE public.test_payments ADD COLUMN IF NOT EXISTS exam_id uuid;

-- Trigger to auto-create exam_unlock when payment paid
CREATE OR REPLACE FUNCTION public.on_payment_paid_create_exam_unlock()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.status = 'paid' AND (OLD.status IS DISTINCT FROM 'paid')
     AND NEW.user_id IS NOT NULL AND NEW.exam_id IS NOT NULL THEN
    INSERT INTO public.exam_unlocks (user_id, exam_id, source)
    VALUES (NEW.user_id, NEW.exam_id, 'paid')
    ON CONFLICT (user_id, exam_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_payment_paid_exam_unlock
AFTER UPDATE ON public.test_payments
FOR EACH ROW EXECUTE FUNCTION public.on_payment_paid_create_exam_unlock();

-- Seed default exams matching the existing hero buttons / screenshot
INSERT INTO public.exams (name, name_hi, subtitle, badge_label, icon_emoji, color_scheme, exam_codes, position, display_test_count, display_student_count) VALUES
('SSC Exams', 'एसएससी परीक्षा', 'कर्मचारी चयन आयोग', 'Most Popular', '🏛️', 'blue', 'CGL, CHSL, MTS, CPO, GD Constable', 1, '284 Tests', '2.1L Students'),
('Railway (RRB)', 'रेलवे आरआरबी', 'रेलवे भर्ती बोर्ड', 'Trending', '🚂', 'orange', 'NTPC, Group D, ALP, JE, RPF', 2, '196 Tests', '1.8L Students'),
('Banking Exams', 'बैंकिंग परीक्षा', 'बैंकिंग परीक्षा', 'High Demand', '🏦', 'green', 'SBI PO, IBPS PO, RRB, Clerk', 3, '178 Tests', '1.4L Students'),
('UP Exams', 'यूपी परीक्षा', 'उत्तर प्रदेश', 'New Tests', '⚖️', 'purple', 'UP Police, UPPSC, UPSSSC, Lekhpal', 4, '142 Tests', '98K Students'),
('Bihar Exams', 'बिहार परीक्षा', 'बिहार', 'Updated', '🗺️', 'red', 'BPSC, Bihar Police, BSSC', 5, '98 Tests', '76K Students'),
('Jharkhand Exams', 'झारखंड परीक्षा', 'झारखंड', 'Local Focus', '🌿', 'teal', 'JPSC, JSSC, Jharkhand Police', 6, '84 Tests', '52K Students'),
('Police Exams', 'पुलिस परीक्षा', 'पुलिस भर्ती', 'Popular', '🚓', 'slate', 'Delhi Police, SSC CPO, State Police', 7, '116 Tests', '88K Students'),
('Teaching Exams', 'शिक्षक परीक्षा', 'शिक्षक भर्ती', 'Certified', '📚', 'amber', 'CTET, STET, KVS, NVS, DSSSB', 8, '104 Tests', '64K Students');
