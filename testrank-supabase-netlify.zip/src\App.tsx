import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Navigate, Route, Routes, useParams } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Instructions from "./pages/student/Instructions";
import Attempt from "./pages/student/Attempt";
import Result from "./pages/student/Result";
import StudentPay from "./pages/student/Pay";
import Login from "./pages/auth/Login";
import Signup from "./pages/auth/Signup";
import Profile from "./pages/student/Profile";
import MyTests from "./pages/student/MyTests";
import { RequireStudent } from "./components/RequireStudent";
import AdminLoginPage from "./pages/admin/Login";
import AdminLayout from "./components/AdminLayout";
import { RequireAdmin } from "./components/RequireAdmin";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminTestsList from "./pages/admin/TestsList";
import TestEditor from "./pages/admin/TestEditor";
import TestPreview from "./pages/admin/TestPreview";
import TestAnalytics from "./pages/admin/TestAnalytics";
import AdminStudents from "./pages/admin/StudentsList";
import AdminQuestionsList from "./pages/admin/QuestionsList";
import QuestionAI from "./pages/admin/QuestionAI";
import AdminPayments from "./pages/admin/Payments";
import AdminCategoriesList from "./pages/admin/CategoriesList";
import CategoryEditor from "./pages/admin/CategoryEditor";
import CategoryView from "./pages/student/CategoryView";
import AdminExamsList from "./pages/admin/ExamsList";
import AdminExamEditor from "./pages/admin/ExamEditor";
import ExamView from "./pages/student/ExamView";
import SubExamView from "./pages/student/SubExamView";
import AdminSubExamEditor from "./pages/admin/SubExamEditor";
import About from "./pages/info/About";
import Contact from "./pages/info/Contact";
import Careers from "./pages/info/Careers";
import Privacy from "./pages/info/Privacy";
import Terms from "./pages/info/Terms";
import {
  MockTests, FreeMockTests, FreeOnlineTest, ExamCategoriesPage,
  SSCMockTest, BankingMockTest, RailwayMockTest, UPSCMockTest, StateExams,
  OnlineTestSeries, TestSeriesPage, PreviousYearPapers, DailyQuiz,
  DailyCurrentAffairs, CurrentAffairs, GovernmentExamQuiz, ResultsRankings,
} from "./pages/seo/landingPages";
import BlogIndex from "./pages/blog/BlogIndex";
import BlogPost from "./pages/blog/BlogPost";
import ScrollToTop from "./components/ScrollToTop";

const queryClient = new QueryClient();

function LegacyTestRegisterRedirect() {
  const { id } = useParams();
  const redirect = encodeURIComponent(`/test/${id}/instructions`);
  return <Navigate to={`/signup?redirect=${redirect}`} replace />;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <ScrollToTop />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />

            <Route path="/mock-tests" element={<MockTests />} />
            <Route path="/free-mock-tests" element={<FreeMockTests />} />
            <Route path="/free-online-test" element={<FreeOnlineTest />} />
            <Route path="/exam-categories" element={<ExamCategoriesPage />} />
            <Route path="/ssc-mock-test" element={<SSCMockTest />} />
            <Route path="/banking-mock-test" element={<BankingMockTest />} />
            <Route path="/railway-mock-test" element={<RailwayMockTest />} />
            <Route path="/upsc-mock-test" element={<UPSCMockTest />} />
            <Route path="/state-exams" element={<StateExams />} />
            <Route path="/online-test-series" element={<OnlineTestSeries />} />
            <Route path="/test-series" element={<TestSeriesPage />} />
            <Route path="/previous-year-papers" element={<PreviousYearPapers />} />
            <Route path="/daily-quiz" element={<DailyQuiz />} />
            <Route path="/daily-current-affairs" element={<DailyCurrentAffairs />} />
            <Route path="/current-affairs" element={<CurrentAffairs />} />
            <Route path="/government-exam-quiz" element={<GovernmentExamQuiz />} />
            <Route path="/results-rankings" element={<ResultsRankings />} />
            <Route path="/blog" element={<BlogIndex />} />
            <Route path="/blog/:slug" element={<BlogPost />} />

            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route
              path="/profile"
              element={
                <RequireStudent>
                  <Profile />
                </RequireStudent>
              }
            />
            <Route
              path="/my-tests"
              element={
                <RequireStudent>
                  <MyTests />
                </RequireStudent>
              }
            />

            <Route path="/category/:slug" element={<CategoryView />} />
            <Route path="/exam/:id" element={<ExamView />} />
            <Route path="/sub-exam/:id" element={<SubExamView />} />

            <Route path="/test/:id/register" element={<LegacyTestRegisterRedirect />} />
            <Route path="/test/:id/pay" element={<RequireStudent unauthenticatedTo="/signup"><StudentPay /></RequireStudent>} />
            <Route path="/test/:id/instructions" element={<RequireStudent unauthenticatedTo="/signup"><Instructions /></RequireStudent>} />
            <Route path="/test/:id/attempt" element={<RequireStudent unauthenticatedTo="/signup"><Attempt /></RequireStudent>} />
            <Route path="/test/:id/result/:resultId" element={<RequireStudent unauthenticatedTo="/signup"><Result /></RequireStudent>} />

            <Route path="/admin/login" element={<AdminLoginPage />} />
            <Route
              path="/admin"
              element={
                <RequireAdmin>
                  <AdminLayout />
                </RequireAdmin>
              }
            >
              <Route index element={<AdminDashboard />} />
              <Route path="tests" element={<AdminTestsList />} />
              <Route path="tests/new" element={<TestEditor />} />
              <Route path="tests/:id/edit" element={<TestEditor />} />
              <Route path="tests/:id/preview" element={<TestPreview />} />
              <Route path="tests/:id/analytics" element={<TestAnalytics />} />
              <Route path="categories" element={<AdminCategoriesList />} />
              <Route path="categories/new" element={<CategoryEditor />} />
              <Route path="categories/:id/edit" element={<CategoryEditor />} />
              <Route path="exams" element={<AdminExamsList />} />
              <Route path="exams/new" element={<AdminExamEditor />} />
              <Route path="exams/:id/edit" element={<AdminExamEditor />} />
              <Route path="exams/:examId/sub-exams/new" element={<AdminSubExamEditor />} />
              <Route path="sub-exams/:id/edit" element={<AdminSubExamEditor />} />
              <Route path="students" element={<AdminStudents />} />
              <Route path="questions" element={<AdminQuestionsList />} />
              <Route path="question-ai" element={<QuestionAI />} />
              <Route path="payments" element={<AdminPayments />} />
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
