
ALTER TABLE public.questions
  ADD COLUMN IF NOT EXISTS question_hi text,
  ADD COLUMN IF NOT EXISTS option_a_hi text,
  ADD COLUMN IF NOT EXISTS option_b_hi text,
  ADD COLUMN IF NOT EXISTS option_c_hi text,
  ADD COLUMN IF NOT EXISTS option_d_hi text;

ALTER TABLE public.tests
  ADD COLUMN IF NOT EXISTS name_hi text,
  ADD COLUMN IF NOT EXISTS description_hi text;

DROP FUNCTION IF EXISTS public.get_test_questions(uuid);

CREATE OR REPLACE FUNCTION public.get_test_questions(p_test_id uuid)
 RETURNS TABLE(
   id uuid,
   question text,
   option_a text,
   option_b text,
   option_c text,
   option_d text,
   order_index integer,
   question_hi text,
   option_a_hi text,
   option_b_hi text,
   option_c_hi text,
   option_d_hi text
 )
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT q.id, q.question, q.option_a, q.option_b, q.option_c, q.option_d, q.order_index,
         q.question_hi, q.option_a_hi, q.option_b_hi, q.option_c_hi, q.option_d_hi
  FROM public.questions q
  JOIN public.tests t ON t.id = q.test_id
  WHERE q.test_id = p_test_id AND t.status = 'published'
  ORDER BY q.order_index, q.created_at;
$function$;
