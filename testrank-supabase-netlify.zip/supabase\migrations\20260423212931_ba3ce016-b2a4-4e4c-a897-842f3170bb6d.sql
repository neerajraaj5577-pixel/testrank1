-- 1. Add per-question time + answers map to results
ALTER TABLE public.results
  ADD COLUMN IF NOT EXISTS per_question_time jsonb,
  ADD COLUMN IF NOT EXISTS answers jsonb;

-- 2. Link test_payments to auth user
ALTER TABLE public.test_payments
  ADD COLUMN IF NOT EXISTS user_id uuid;

CREATE INDEX IF NOT EXISTS idx_test_payments_user_id ON public.test_payments(user_id);

-- 3. student_profiles table
CREATE TABLE IF NOT EXISTS public.student_profiles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  mobile text NOT NULL UNIQUE,
  district text NOT NULL,
  exam text,
  dob date,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.student_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own profile"
ON public.student_profiles FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Public can read basic profile info"
ON public.student_profiles FOR SELECT
USING (true);

CREATE POLICY "Users can insert their own profile"
ON public.student_profiles FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
ON public.student_profiles FOR UPDATE
USING (auth.uid() = user_id);

CREATE TRIGGER trg_student_profiles_updated_at
BEFORE UPDATE ON public.student_profiles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- 4. test_unlocks table (lifetime access)
CREATE TABLE IF NOT EXISTS public.test_unlocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  test_id uuid NOT NULL REFERENCES public.tests(id) ON DELETE CASCADE,
  source text NOT NULL DEFAULT 'paid',
  unlocked_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(user_id, test_id)
);

CREATE INDEX IF NOT EXISTS idx_test_unlocks_user_id ON public.test_unlocks(user_id);
CREATE INDEX IF NOT EXISTS idx_test_unlocks_test_id ON public.test_unlocks(test_id);

ALTER TABLE public.test_unlocks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own unlocks"
ON public.test_unlocks FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Public can read unlocks"
ON public.test_unlocks FOR SELECT
USING (true);

CREATE POLICY "Anyone can insert unlocks"
ON public.test_unlocks FOR INSERT
WITH CHECK (true);

-- 5. Trigger: when payment marked paid, auto-create unlock
CREATE OR REPLACE FUNCTION public.on_payment_paid_create_unlock()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'paid' AND (OLD.status IS DISTINCT FROM 'paid') AND NEW.user_id IS NOT NULL THEN
    INSERT INTO public.test_unlocks (user_id, test_id, source)
    VALUES (NEW.user_id, NEW.test_id, 'paid')
    ON CONFLICT (user_id, test_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_on_payment_paid ON public.test_payments;
CREATE TRIGGER trg_on_payment_paid
AFTER UPDATE ON public.test_payments
FOR EACH ROW
EXECUTE FUNCTION public.on_payment_paid_create_unlock();

-- 6. Updated submit_test RPC with per-question time + answers
CREATE OR REPLACE FUNCTION public.submit_test(
  p_student_id uuid,
  p_test_id uuid,
  p_answers jsonb,
  p_time_taken integer,
  p_per_question_time jsonb DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_test public.tests%ROWTYPE;
  v_q RECORD;
  v_user_ans TEXT;
  v_correct INT := 0;
  v_wrong INT := 0;
  v_unattempted INT := 0;
  v_score NUMERIC := 0;
  v_neg NUMERIC;
  v_result_id UUID;
BEGIN
  SELECT * INTO v_test FROM public.tests WHERE id = p_test_id AND status = 'published';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Test not found or not published';
  END IF;

  v_neg := COALESCE(v_test.negative_marking_fraction, 0) * v_test.marks_per_question;

  FOR v_q IN SELECT id, correct_answer FROM public.questions WHERE test_id = p_test_id LOOP
    v_user_ans := p_answers ->> v_q.id::text;
    IF v_user_ans IS NULL OR v_user_ans = '' THEN
      v_unattempted := v_unattempted + 1;
    ELSIF v_user_ans = v_q.correct_answer THEN
      v_correct := v_correct + 1;
      v_score := v_score + v_test.marks_per_question;
    ELSE
      v_wrong := v_wrong + 1;
      v_score := v_score - v_neg;
    END IF;
  END LOOP;

  INSERT INTO public.results (
    student_id, test_id, score, correct_answers, wrong_answers,
    unattempted, time_taken_seconds, answers, per_question_time
  )
  VALUES (
    p_student_id, p_test_id, v_score, v_correct, v_wrong,
    v_unattempted, p_time_taken, p_answers, p_per_question_time
  )
  RETURNING id INTO v_result_id;

  RETURN v_result_id;
END;
$$;