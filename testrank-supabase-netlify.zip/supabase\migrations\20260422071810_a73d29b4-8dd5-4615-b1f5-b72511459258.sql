-- Add UTR + audit columns to test_payments
ALTER TABLE public.test_payments
  ADD COLUMN IF NOT EXISTS utr text,
  ADD COLUMN IF NOT EXISTS verified_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS verified_by text,
  ADD COLUMN IF NOT EXISTS notes text;

-- Create app_settings table
CREATE TABLE IF NOT EXISTS public.app_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  upi_id text NOT NULL,
  upi_payee_name text NOT NULL,
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read app_settings"
  ON public.app_settings FOR SELECT
  USING (true);

CREATE POLICY "Anyone can update app_settings"
  ON public.app_settings FOR UPDATE
  USING (true) WITH CHECK (true);

CREATE POLICY "Anyone can insert app_settings"
  ON public.app_settings FOR INSERT
  WITH CHECK (true);

-- Seed a single row of settings
INSERT INTO public.app_settings (upi_id, upi_payee_name)
SELECT '9523960568@naviaxis', 'TestRank'
WHERE NOT EXISTS (SELECT 1 FROM public.app_settings);
