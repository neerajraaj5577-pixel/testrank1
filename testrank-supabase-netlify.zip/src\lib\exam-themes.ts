// Color scheme presets for exam cards (matches the screenshot)
export type ExamColorScheme =
  | "blue" | "orange" | "green" | "purple" | "red" | "teal" | "slate" | "amber";

type Theme = {
  cardBg: string;
  iconBg: string;
  iconText: string;
  title: string;
  badgeBg: string;
  badgeText: string;
  exploreText: string;
  meta: string;
};

export const EXAM_THEMES: Record<ExamColorScheme, Theme> = {
  blue: {
    cardBg: "bg-blue-50 dark:bg-blue-950/40 border-blue-100 dark:border-blue-900",
    iconBg: "bg-blue-500", iconText: "text-white",
    title: "text-blue-700 dark:text-blue-300",
    badgeBg: "bg-blue-100 dark:bg-blue-900/60", badgeText: "text-blue-700 dark:text-blue-300",
    exploreText: "text-blue-600 dark:text-blue-400",
    meta: "text-blue-700/80 dark:text-blue-300/80",
  },
  orange: {
    cardBg: "bg-orange-50 dark:bg-orange-950/40 border-orange-100 dark:border-orange-900",
    iconBg: "bg-orange-500", iconText: "text-white",
    title: "text-orange-700 dark:text-orange-300",
    badgeBg: "bg-orange-100 dark:bg-orange-900/60", badgeText: "text-orange-700 dark:text-orange-300",
    exploreText: "text-orange-600 dark:text-orange-400",
    meta: "text-orange-700/80 dark:text-orange-300/80",
  },
  green: {
    cardBg: "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-100 dark:border-emerald-900",
    iconBg: "bg-emerald-600", iconText: "text-white",
    title: "text-emerald-700 dark:text-emerald-300",
    badgeBg: "bg-emerald-100 dark:bg-emerald-900/60", badgeText: "text-emerald-700 dark:text-emerald-300",
    exploreText: "text-emerald-600 dark:text-emerald-400",
    meta: "text-emerald-700/80 dark:text-emerald-300/80",
  },
  purple: {
    cardBg: "bg-purple-50 dark:bg-purple-950/40 border-purple-100 dark:border-purple-900",
    iconBg: "bg-purple-500", iconText: "text-white",
    title: "text-purple-700 dark:text-purple-300",
    badgeBg: "bg-purple-100 dark:bg-purple-900/60", badgeText: "text-purple-700 dark:text-purple-300",
    exploreText: "text-purple-600 dark:text-purple-400",
    meta: "text-purple-700/80 dark:text-purple-300/80",
  },
  red: {
    cardBg: "bg-rose-50 dark:bg-rose-950/40 border-rose-100 dark:border-rose-900",
    iconBg: "bg-rose-500", iconText: "text-white",
    title: "text-rose-700 dark:text-rose-300",
    badgeBg: "bg-rose-100 dark:bg-rose-900/60", badgeText: "text-rose-700 dark:text-rose-300",
    exploreText: "text-rose-600 dark:text-rose-400",
    meta: "text-rose-700/80 dark:text-rose-300/80",
  },
  teal: {
    cardBg: "bg-teal-50 dark:bg-teal-950/40 border-teal-100 dark:border-teal-900",
    iconBg: "bg-teal-600", iconText: "text-white",
    title: "text-teal-700 dark:text-teal-300",
    badgeBg: "bg-teal-100 dark:bg-teal-900/60", badgeText: "text-teal-700 dark:text-teal-300",
    exploreText: "text-teal-600 dark:text-teal-400",
    meta: "text-teal-700/80 dark:text-teal-300/80",
  },
  slate: {
    cardBg: "bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800",
    iconBg: "bg-slate-700", iconText: "text-white",
    title: "text-slate-800 dark:text-slate-200",
    badgeBg: "bg-slate-200 dark:bg-slate-800", badgeText: "text-slate-700 dark:text-slate-300",
    exploreText: "text-slate-700 dark:text-slate-300",
    meta: "text-slate-600 dark:text-slate-400",
  },
  amber: {
    cardBg: "bg-amber-50 dark:bg-amber-950/40 border-amber-100 dark:border-amber-900",
    iconBg: "bg-amber-500", iconText: "text-white",
    title: "text-amber-700 dark:text-amber-300",
    badgeBg: "bg-amber-100 dark:bg-amber-900/60", badgeText: "text-amber-700 dark:text-amber-300",
    exploreText: "text-amber-600 dark:text-amber-400",
    meta: "text-amber-700/80 dark:text-amber-300/80",
  },
};

export function getExamTheme(scheme?: string | null): Theme {
  return EXAM_THEMES[(scheme as ExamColorScheme) ?? "blue"] ?? EXAM_THEMES.blue;
}

export const EXAM_COLOR_OPTIONS: { value: ExamColorScheme; label: string }[] = [
  { value: "blue", label: "Blue" }, { value: "orange", label: "Orange" },
  { value: "green", label: "Green" }, { value: "purple", label: "Purple" },
  { value: "red", label: "Red" }, { value: "teal", label: "Teal" },
  { value: "slate", label: "Slate" }, { value: "amber", label: "Amber" },
];
