import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Eye, Trash2, BarChart3, Send, Undo } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type Row = {
  id: string;
  name: string;
  status: string;
  total_questions: number;
  time_limit: number;
  question_count: number;
  attempts: number;
  category_id: string | null;
  category_name: string;
};

export default function AdminTestsList() {
  const navigate = useNavigate();
  const [rows, setRows] = useState<Row[]>([]);
  const [categories, setCategories] = useState<Array<{ id: string; name: string }>>([]);
  const [filter, setFilter] = useState<string>("all");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const [{ data: tests }, { data: cats }] = await Promise.all([
      supabase.from("tests").select("*").order("created_at", { ascending: false }),
      supabase.from("categories").select("id,name").order("position").order("name"),
    ]);
    setCategories((cats ?? []) as any);
    const catMap = new Map<string, string>();
    (cats ?? []).forEach((c: any) => catMap.set(c.id, c.name));

    const ids = (tests ?? []).map((t) => t.id);
    const [qCounts, rCounts] = await Promise.all([
      ids.length
        ? supabase.from("questions").select("test_id").in("test_id", ids)
        : Promise.resolve({ data: [] as any[] }),
      ids.length
        ? supabase.from("results").select("test_id").in("test_id", ids)
        : Promise.resolve({ data: [] as any[] }),
    ]);
    const qMap = new Map<string, number>();
    (qCounts.data ?? []).forEach((q: any) => qMap.set(q.test_id, (qMap.get(q.test_id) ?? 0) + 1));
    const rMap = new Map<string, number>();
    (rCounts.data ?? []).forEach((r: any) => rMap.set(r.test_id, (rMap.get(r.test_id) ?? 0) + 1));
    setRows(
      (tests ?? []).map((t: any) => ({
        ...t,
        question_count: qMap.get(t.id) ?? 0,
        attempts: rMap.get(t.id) ?? 0,
        category_id: t.category_id ?? null,
        category_name: t.category_id ? (catMap.get(t.category_id) ?? "—") : "Uncategorised",
      })),
    );
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    if (filter === "all") return rows;
    if (filter === "none") return rows.filter((r) => !r.category_id);
    return rows.filter((r) => r.category_id === filter);
  }, [rows, filter]);

  const togglePublish = async (row: Row) => {
    if (row.status === "draft" && row.question_count === 0) {
      toast({ title: "Cannot publish", description: "Add at least one question first.", variant: "destructive" });
      return;
    }
    const next = row.status === "published" ? "draft" : "published";
    const { error } = await supabase.from("tests").update({ status: next }).eq("id", row.id);
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    toast({ title: next === "published" ? "Test published" : "Test unpublished" });
    load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("tests").delete().eq("id", id);
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    toast({ title: "Test deleted" });
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold">Tests</h1>
          <p className="text-muted-foreground">Manage your test catalog.</p>
        </div>
        <div className="flex gap-2 items-center flex-wrap">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              <SelectItem value="none">Uncategorised</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={() => navigate("/admin/tests/new")}>
            <Plus className="h-4 w-4" /> New Test
          </Button>
        </div>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead className="hidden lg:table-cell">Category</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden sm:table-cell">Questions</TableHead>
              <TableHead className="hidden md:table-cell">Time</TableHead>
              <TableHead className="hidden md:table-cell">Attempts</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground py-8">Loading…</TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                  {rows.length === 0 ? "No tests yet. Create your first one." : "No tests match this filter."}
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.name}</TableCell>
                  <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">{r.category_name}</TableCell>
                  <TableCell>
                    <Badge variant={r.status === "published" ? "default" : "secondary"}>{r.status}</Badge>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">{r.question_count}</TableCell>
                  <TableCell className="hidden md:table-cell">{r.time_limit}m</TableCell>
                  <TableCell className="hidden md:table-cell">{r.attempts}</TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex gap-1">
                      <Button asChild variant="ghost" size="icon" title="Analytics">
                        <Link to={`/admin/tests/${r.id}/analytics`}>
                          <BarChart3 className="h-4 w-4" />
                        </Link>
                      </Button>
                      <Button asChild variant="ghost" size="icon" title="Preview">
                        <Link to={`/admin/tests/${r.id}/preview`}>
                          <Eye className="h-4 w-4" />
                        </Link>
                      </Button>
                      <Button asChild variant="ghost" size="icon" title="Edit">
                        <Link to={`/admin/tests/${r.id}/edit`}>
                          <Edit className="h-4 w-4" />
                        </Link>
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        title={r.status === "published" ? "Unpublish" : "Publish"}
                        onClick={() => togglePublish(r)}
                      >
                        {r.status === "published" ? <Undo className="h-4 w-4" /> : <Send className="h-4 w-4" />}
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" title="Delete">
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete this test?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete the test, its questions, and all attempts.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => remove(r.id)}>Delete</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
