
CREATE TABLE public.test_sections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id UUID NOT NULL REFERENCES public.tests(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  position INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_test_sections_test ON public.test_sections(test_id);
ALTER TABLE public.test_sections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view sections" ON public.test_sections FOR SELECT USING (true);
CREATE POLICY "Public can manage sections" ON public.test_sections FOR ALL USING (true) WITH CHECK (true);

ALTER TABLE public.questions
  ADD COLUMN section_id UUID REFERENCES public.test_sections(id) ON DELETE SET NULL,
  ADD COLUMN option_a_image TEXT,
  ADD COLUMN option_b_image TEXT,
  ADD COLUMN option_c_image TEXT,
  ADD COLUMN option_d_image TEXT,
  ADD COLUMN explanation TEXT,
  ADD COLUMN explanation_hi TEXT;
CREATE INDEX idx_questions_section ON public.questions(section_id);

ALTER TABLE public.categories
  ADD COLUMN is_paid BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN price NUMERIC,
  ADD COLUMN mrp NUMERIC,
  ADD COLUMN validity_days INT;

CREATE TABLE public.category_unlocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  category_id UUID NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
  source TEXT NOT NULL DEFAULT 'paid',
  unlocked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, category_id)
);
ALTER TABLE public.category_unlocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read category_unlocks" ON public.category_unlocks FOR SELECT USING (true);
CREATE POLICY "Anyone can insert category_unlocks" ON public.category_unlocks FOR INSERT WITH CHECK (true);

ALTER TABLE public.test_payments
  ADD COLUMN category_id UUID REFERENCES public.categories(id);
ALTER TABLE public.test_payments ALTER COLUMN test_id DROP NOT NULL;

CREATE OR REPLACE FUNCTION public.on_payment_paid_create_category_unlock()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.status = 'paid' AND (OLD.status IS DISTINCT FROM 'paid')
     AND NEW.user_id IS NOT NULL AND NEW.category_id IS NOT NULL THEN
    INSERT INTO public.category_unlocks (user_id, category_id, source)
    VALUES (NEW.user_id, NEW.category_id, 'paid')
    ON CONFLICT (user_id, category_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS trg_payment_paid_category_unlock ON public.test_payments;
CREATE TRIGGER trg_payment_paid_category_unlock
AFTER UPDATE ON public.test_payments
FOR EACH ROW EXECUTE FUNCTION public.on_payment_paid_create_category_unlock();

DROP TRIGGER IF EXISTS trg_payment_paid_test_unlock ON public.test_payments;
CREATE TRIGGER trg_payment_paid_test_unlock
AFTER UPDATE ON public.test_payments
FOR EACH ROW EXECUTE FUNCTION public.on_payment_paid_create_unlock();

DROP FUNCTION IF EXISTS public.get_test_questions(uuid);
CREATE FUNCTION public.get_test_questions(p_test_id uuid)
RETURNS TABLE(
  id uuid, question text, option_a text, option_b text, option_c text, option_d text,
  order_index integer,
  question_hi text, option_a_hi text, option_b_hi text, option_c_hi text, option_d_hi text,
  section_id uuid,
  option_a_image text, option_b_image text, option_c_image text, option_d_image text,
  explanation text, explanation_hi text
)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT q.id, q.question, q.option_a, q.option_b, q.option_c, q.option_d, q.order_index,
         q.question_hi, q.option_a_hi, q.option_b_hi, q.option_c_hi, q.option_d_hi,
         q.section_id,
         q.option_a_image, q.option_b_image, q.option_c_image, q.option_d_image,
         q.explanation, q.explanation_hi
  FROM public.questions q
  JOIN public.tests t ON t.id = q.test_id
  WHERE q.test_id = p_test_id AND t.status = 'published'
  ORDER BY q.order_index, q.created_at;
$$;
