// Edge function: translates Hindi exam content to English via OpenAI.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { fields } = await req.json();
    if (!fields || typeof fields !== "object") {
      return new Response(JSON.stringify({ error: "fields object required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const apiKey = Deno.env.get("OPENAI_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "OPENAI_API_KEY not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const entries = Object.entries(fields).filter(([, value]) => value && String(value).trim());
    if (entries.length === 0) {
      return new Response(JSON.stringify({ translations: {} }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const properties: Record<string, { type: string }> = {};
    for (const [key] of entries) properties[key] = { type: "string" };

    const aiResp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: Deno.env.get("OPENAI_MODEL") || "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content:
              "Translate Hindi educational MCQ exam content into natural exam-style English. " +
              "Preserve meaning, proper nouns, numbers, and units. Do not answer questions or add explanations.",
          },
          {
            role: "user",
            content:
              "Translate each Hindi field to English. Return via the return_translations tool.\n\n" +
              entries.map(([key, value]) => `${key}: ${value}`).join("\n"),
          },
        ],
        tools: [{
          type: "function",
          function: {
            name: "return_translations",
            description: "Return English translations for every field key.",
            parameters: {
              type: "object",
              properties,
              required: entries.map(([key]) => key),
              additionalProperties: false,
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "return_translations" } },
      }),
    });

    if (!aiResp.ok) {
      const details = await aiResp.text();
      console.error("OpenAI API error:", aiResp.status, details);
      return new Response(JSON.stringify({ error: "OpenAI API error" }), {
        status: aiResp.status === 429 ? 429 : 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await aiResp.json();
    const args = data?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    if (!args) {
      return new Response(JSON.stringify({ error: "No translation returned" }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ translations: JSON.parse(args) }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("translate-to-english error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
