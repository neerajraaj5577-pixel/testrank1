import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, Save, Loader2, Plus, Edit, Trash2, ImagePlus, X } from "lucide-react";
import { EXAM_COLOR_OPTIONS, getExamTheme } from "@/lib/exam-themes";

type SubExam = { id: string; name: string; name_hi: string | null; icon_emoji: string | null; badge_label: string | null; is_active: boolean; position: number; test_count?: number };
type Category = { id: string; name: string; is_active?: boolean };



export default function AdminExamEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = !id;
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [subExams, setSubExams] = useState<SubExam[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  const [form, setForm] = useState({
    name: "", name_hi: "", subtitle: "", badge_label: "", icon_emoji: "📘",
    color_scheme: "blue", exam_codes: "", position: 0,
    is_active: true, is_paid: false, price: "", mrp: "", validity_days: "",
    display_test_count: "", display_student_count: "",
    free_category_id: "" as string,
    logo_url: "" as string,
  });
  const [logoUploading, setLogoUploading] = useState(false);
  const logoFileRef = useRef<HTMLInputElement | null>(null);

  const uploadLogo = async (file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      return toast({ title: "Image too large", description: "Max 2MB", variant: "destructive" });
    }
    setLogoUploading(true);
    const ext = file.name.split(".").pop() || "png";
    const path = `exams/${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("question-images").upload(path, file, { upsert: true });
    if (upErr) {
      setLogoUploading(false);
      return toast({ title: "Upload failed", description: upErr.message, variant: "destructive" });
    }
    const { data: pub } = supabase.storage.from("question-images").getPublicUrl(path);
    setForm((f) => ({ ...f, logo_url: pub.publicUrl }));
    setLogoUploading(false);
  };

  const loadSubExams = async () => {
    if (!id) return;
    const { data: subs } = await supabase
      .from("sub_exams" as any).select("*").eq("exam_id", id).order("position");
    const ids = (subs ?? []).map((s: any) => s.id);
    const { data: links } = ids.length
      ? await supabase.from("sub_exam_tests" as any).select("sub_exam_id").in("sub_exam_id", ids)
      : { data: [] as any[] };
    const counts = new Map<string, number>();
    (links ?? []).forEach((l: any) => counts.set(l.sub_exam_id, (counts.get(l.sub_exam_id) ?? 0) + 1));
    setSubExams(((subs ?? []) as any[]).map((s) => ({ ...s, test_count: counts.get(s.id) ?? 0 })));
  };

  useEffect(() => {
    (async () => {
      const { data: cats } = await supabase
        .from("categories")
        .select("id,name,is_active")
        .order("name");
      setCategories((cats ?? []) as Category[]);
      if (!isNew) {
        const { data: ex } = await supabase.from("exams" as any).select("*").eq("id", id!).maybeSingle();
        if (ex) {
          const e: any = ex;
          setForm({
            name: e.name ?? "", name_hi: e.name_hi ?? "", subtitle: e.subtitle ?? "",
            badge_label: e.badge_label ?? "", icon_emoji: e.icon_emoji ?? "📘",
            color_scheme: e.color_scheme ?? "blue", exam_codes: e.exam_codes ?? "",
            position: e.position ?? 0, is_active: !!e.is_active, is_paid: !!e.is_paid,
            price: e.price?.toString() ?? "", mrp: e.mrp?.toString() ?? "",
            validity_days: e.validity_days?.toString() ?? "",
            display_test_count: e.display_test_count ?? "",
            display_student_count: e.display_student_count ?? "",
            free_category_id: e.free_category_id ?? "",
            logo_url: e.logo_url ?? "",
          });
        }
        await loadSubExams();
        setLoading(false);
      }
    })();
  }, [id, isNew]);

  const removeSubExam = async (sid: string) => {
    if (!confirm("Delete this sub-exam? Tests inside will not be deleted.")) return;
    await supabase.from("sub_exam_tests" as any).delete().eq("sub_exam_id", sid);
    await supabase.from("sub_exams" as any).delete().eq("id", sid);
    toast({ title: "Sub-exam deleted" });
    loadSubExams();
  };

  const save = async () => {
    if (!form.name.trim()) return toast({ title: "Name required", variant: "destructive" });
    setSaving(true);
    const payload: any = {
      name: form.name.trim(),
      name_hi: form.name_hi.trim() || null,
      subtitle: form.subtitle.trim() || null,
      badge_label: form.badge_label.trim() || null,
      icon_emoji: form.icon_emoji.trim() || "📘",
      color_scheme: form.color_scheme,
      exam_codes: form.exam_codes.trim() || null,
      position: Number(form.position) || 0,
      is_active: form.is_active,
      is_paid: form.is_paid,
      price: form.is_paid && form.price ? Number(form.price) : null,
      mrp: form.is_paid && form.mrp ? Number(form.mrp) : null,
      validity_days: form.is_paid && form.validity_days ? Number(form.validity_days) : null,
      display_test_count: form.display_test_count.trim() || null,
      display_student_count: form.display_student_count.trim() || null,
      free_category_id: form.free_category_id || null,
      logo_url: form.logo_url || null,
    };
    let examId = id;
    if (isNew) {
      const { data, error } = await (supabase.from("exams" as any) as any).insert(payload).select("id").single();
      if (error) { setSaving(false); return toast({ title: "Error", description: error.message, variant: "destructive" }); }
      examId = (data as any).id;
    } else {
      const { error } = await (supabase.from("exams" as any) as any).update(payload).eq("id", id!);
      if (error) { setSaving(false); return toast({ title: "Error", description: error.message, variant: "destructive" }); }
    }

    setSaving(false);
    toast({ title: isNew ? "Exam created" : "Exam updated" });
    if (isNew && examId) navigate(`/admin/exams/${examId}/edit`);
    else navigate("/admin/exams");
  };

  if (loading) {
    return <div className="flex items-center justify-center py-20"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  }

  const th = getExamTheme(form.color_scheme);

  return (
    <div className="space-y-6 max-w-4xl">
      <Button variant="ghost" size="sm" onClick={() => navigate("/admin/exams")}>
        <ArrowLeft className="h-4 w-4" /> Back
      </Button>
      <h1 className="text-3xl font-bold">{isNew ? "New Exam" : "Edit Exam"}</h1>

      {/* Live preview */}
      <Card className={`${th.cardBg} border-2`}>
        <CardContent className="p-5">
          <div className="flex items-start justify-between gap-3">
            {form.logo_url ? (
              <div className="h-12 w-12 rounded-xl overflow-hidden bg-white border shrink-0">
                <img src={form.logo_url} alt="logo" className="w-full h-full object-cover" />
              </div>
            ) : (
              <div className={`h-12 w-12 rounded-xl flex items-center justify-center text-2xl shrink-0 ${th.iconBg} ${th.iconText}`}>
                {form.icon_emoji || "📘"}
              </div>
            )}
            {form.badge_label && (
              <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${th.badgeBg} ${th.badgeText}`}>
                {form.badge_label}
              </span>
            )}
          </div>
          <h3 className={`text-xl font-bold mt-3 ${th.title}`}>{form.name || "Exam name"}</h3>
          {form.name_hi && <div className={`text-sm ${th.meta}`}>{form.name_hi}</div>}
          {form.exam_codes && <div className="text-sm text-muted-foreground mt-3">{form.exam_codes}</div>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Basic info</CardTitle></CardHeader>
        <CardContent className="grid sm:grid-cols-2 gap-4">
          <Field label="Exam logo (replaces emoji on home card)" full>
            <div className="flex items-center gap-3">
              {form.logo_url ? (
                <div className="relative h-16 w-16 rounded-xl overflow-hidden border bg-white">
                  <img src={form.logo_url} alt="logo" className="w-full h-full object-cover" />
                  <Button type="button" variant="secondary" size="icon"
                    className="absolute -top-1 -right-1 h-6 w-6"
                    onClick={() => setForm({ ...form, logo_url: "" })}>
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ) : (
                <button type="button" onClick={() => logoFileRef.current?.click()}
                  disabled={logoUploading}
                  className="h-16 w-16 rounded-xl border-2 border-dashed flex flex-col items-center justify-center text-muted-foreground hover:bg-accent transition-colors">
                  {logoUploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-5 w-5" />}
                </button>
              )}
              <input ref={logoFileRef} type="file" accept="image/*" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadLogo(f); e.target.value = ""; }} />
              <p className="text-xs text-muted-foreground">PNG/JPG, max 2MB. Square works best.</p>
            </div>
          </Field>
          <Field label="Name (English) *"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Name (Hindi)"><Input value={form.name_hi} onChange={(e) => setForm({ ...form, name_hi: e.target.value })} /></Field>
          <Field label="Subtitle"><Input value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} placeholder="e.g. कर्मचारी चयन आयोग" /></Field>
          <Field label="Badge label"><Input value={form.badge_label} onChange={(e) => setForm({ ...form, badge_label: e.target.value })} placeholder="Most Popular / Trending..." /></Field>
          <Field label="Icon emoji"><Input value={form.icon_emoji} onChange={(e) => setForm({ ...form, icon_emoji: e.target.value })} maxLength={4} /></Field>
          <Field label="Color scheme">
            <Select value={form.color_scheme} onValueChange={(v) => setForm({ ...form, color_scheme: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {EXAM_COLOR_OPTIONS.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Exam codes (subtitle line)" full><Textarea rows={2} value={form.exam_codes} onChange={(e) => setForm({ ...form, exam_codes: e.target.value })} placeholder="CGL, CHSL, MTS, CPO, GD Constable" /></Field>
          <Field label="Position"><Input type="number" value={form.position} onChange={(e) => setForm({ ...form, position: Number(e.target.value) })} /></Field>
          <Field label="Active">
            <div className="flex items-center h-10"><Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} /></div>
          </Field>
          <Field label="Display tests label"><Input value={form.display_test_count} onChange={(e) => setForm({ ...form, display_test_count: e.target.value })} placeholder="e.g. 284 Tests" /></Field>
          <Field label="Display students label"><Input value={form.display_student_count} onChange={(e) => setForm({ ...form, display_student_count: e.target.value })} placeholder="e.g. 2.1L Students" /></Field>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Premium</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <Switch checked={form.is_paid} onCheckedChange={(v) => setForm({ ...form, is_paid: v })} />
            <Label>Mark as premium (one payment unlocks all tests inside)</Label>
          </div>
          {form.is_paid && (
            <div className="grid sm:grid-cols-3 gap-4">
              <Field label="Price (₹)"><Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></Field>
              <Field label="MRP (₹)"><Input type="number" value={form.mrp} onChange={(e) => setForm({ ...form, mrp: e.target.value })} /></Field>
              <Field label="Validity (days, optional)"><Input type="number" value={form.validity_days} onChange={(e) => setForm({ ...form, validity_days: e.target.value })} /></Field>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Free mock test promo</CardTitle></CardHeader>
        <CardContent>
          <Field label="Linked free category (shown as “Want a free mock test? Click here” button)" full>
            <Select value={form.free_category_id || "none"} onValueChange={(v) => setForm({ ...form, free_category_id: v === "none" ? "" : v })}>
              <SelectTrigger><SelectValue placeholder="No free category" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— None —</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}{c.is_active === false ? " (hidden)" : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <p className="text-xs text-muted-foreground mt-2">Create the free mock category in Categories first, then link it here.</p>
        </CardContent>
      </Card>

      {!isNew && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Sub-exams ({subExams.length})</CardTitle>
            <Button size="sm" asChild>
              <Link to={`/admin/exams/${id}/sub-exams/new`}><Plus className="h-4 w-4" /> Add sub-exam</Link>
            </Button>
          </CardHeader>
          <CardContent>
            {subExams.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                No sub-exams yet. Add categories like "SSC CGL", "SSC GD" — students will see these as buttons inside this exam.
              </p>
            ) : (
              <div className="border rounded-lg divide-y">
                {subExams.map((s) => (
                  <div key={s.id} className="flex items-center gap-3 p-3">
                    <div className="text-2xl">{s.icon_emoji ?? "📘"}</div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{s.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {s.test_count ?? 0} tests {s.badge_label ? `· ${s.badge_label}` : ""} {!s.is_active ? "· Hidden" : ""}
                      </div>
                    </div>
                    <Button asChild variant="ghost" size="icon">
                      <Link to={`/admin/sub-exams/${s.id}/edit`}><Edit className="h-4 w-4" /></Link>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => removeSubExam(s.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => navigate("/admin/exams")}>Cancel</Button>
        <Button onClick={save} disabled={saving}>
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save
        </Button>
      </div>
    </div>
  );
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={`space-y-1.5 ${full ? "sm:col-span-2" : ""}`}>
      <Label className="text-sm">{label}</Label>
      {children}
    </div>
  );
}
