
ALTER TABLE public.exams ADD COLUMN IF NOT EXISTS free_category_id uuid;

ALTER TABLE public.sub_exams
  ADD COLUMN IF NOT EXISTS is_paid boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS price numeric,
  ADD COLUMN IF NOT EXISTS mrp numeric,
  ADD COLUMN IF NOT EXISTS validity_days integer,
  ADD COLUMN IF NOT EXISTS free_category_id uuid;

ALTER TABLE public.test_payments ADD COLUMN IF NOT EXISTS sub_exam_id uuid;

CREATE TABLE IF NOT EXISTS public.sub_exam_unlocks (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  sub_exam_id uuid NOT NULL,
  source text NOT NULL DEFAULT 'paid',
  unlocked_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, sub_exam_id)
);

ALTER TABLE public.sub_exam_unlocks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can read sub_exam_unlocks" ON public.sub_exam_unlocks FOR SELECT USING (true);
CREATE POLICY "Anyone can insert sub_exam_unlocks" ON public.sub_exam_unlocks FOR INSERT WITH CHECK (true);

CREATE OR REPLACE FUNCTION public.on_payment_paid_create_sub_exam_unlock()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.status = 'paid' AND (OLD.status IS DISTINCT FROM 'paid')
     AND NEW.user_id IS NOT NULL AND NEW.sub_exam_id IS NOT NULL THEN
    INSERT INTO public.sub_exam_unlocks (user_id, sub_exam_id, source)
    VALUES (NEW.user_id, NEW.sub_exam_id, 'paid')
    ON CONFLICT (user_id, sub_exam_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_payment_paid_sub_exam_unlock ON public.test_payments;
CREATE TRIGGER trg_payment_paid_sub_exam_unlock
AFTER UPDATE ON public.test_payments
FOR EACH ROW
EXECUTE FUNCTION public.on_payment_paid_create_sub_exam_unlock();
