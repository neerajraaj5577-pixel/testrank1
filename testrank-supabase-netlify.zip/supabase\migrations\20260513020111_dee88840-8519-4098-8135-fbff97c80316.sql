DROP TRIGGER IF EXISTS trg_payment_paid_test_unlock ON public.test_payments;
DROP TRIGGER IF EXISTS trg_payment_paid_category_unlock ON public.test_payments;
DROP TRIGGER IF EXISTS trg_payment_paid_exam_unlock ON public.test_payments;
DROP TRIGGER IF EXISTS trg_payment_paid_sub_exam_unlock ON public.test_payments;

CREATE TRIGGER trg_payment_paid_test_unlock
AFTER UPDATE ON public.test_payments
FOR EACH ROW
EXECUTE FUNCTION public.on_payment_paid_create_unlock();

CREATE TRIGGER trg_payment_paid_category_unlock
AFTER UPDATE ON public.test_payments
FOR EACH ROW
EXECUTE FUNCTION public.on_payment_paid_create_category_unlock();

CREATE TRIGGER trg_payment_paid_exam_unlock
AFTER UPDATE ON public.test_payments
FOR EACH ROW
EXECUTE FUNCTION public.on_payment_paid_create_exam_unlock();

CREATE TRIGGER trg_payment_paid_sub_exam_unlock
AFTER UPDATE ON public.test_payments
FOR EACH ROW
EXECUTE FUNCTION public.on_payment_paid_create_sub_exam_unlock();

INSERT INTO public.test_unlocks (user_id, test_id, source)
SELECT DISTINCT tp.user_id, tp.test_id, 'paid'
FROM public.test_payments tp
WHERE tp.status = 'paid'
  AND tp.user_id IS NOT NULL
  AND tp.test_id IS NOT NULL
ON CONFLICT (user_id, test_id) DO NOTHING;

INSERT INTO public.category_unlocks (user_id, category_id, source)
SELECT DISTINCT tp.user_id, tp.category_id, 'paid'
FROM public.test_payments tp
WHERE tp.status = 'paid'
  AND tp.user_id IS NOT NULL
  AND tp.category_id IS NOT NULL
ON CONFLICT (user_id, category_id) DO NOTHING;

INSERT INTO public.exam_unlocks (user_id, exam_id, source)
SELECT DISTINCT tp.user_id, tp.exam_id, 'paid'
FROM public.test_payments tp
WHERE tp.status = 'paid'
  AND tp.user_id IS NOT NULL
  AND tp.exam_id IS NOT NULL
ON CONFLICT (user_id, exam_id) DO NOTHING;

INSERT INTO public.sub_exam_unlocks (user_id, sub_exam_id, source)
SELECT DISTINCT tp.user_id, tp.sub_exam_id, 'paid'
FROM public.test_payments tp
WHERE tp.status = 'paid'
  AND tp.user_id IS NOT NULL
  AND tp.sub_exam_id IS NOT NULL
ON CONFLICT (user_id, sub_exam_id) DO NOTHING;