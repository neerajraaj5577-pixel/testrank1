import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import {
  Sparkles,
  Loader2,
  ArrowLeft,
  Eye,
  EyeOff,
  Trash2,
  CheckCircle2,
  FileUp,
} from "lucide-react";
import { pdfToImages } from "@/lib/pdf-to-images";

type GenQ = {
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: "A" | "B" | "C" | "D";
};

const FRACTIONS = [
  { value: "0.5", label: "1/2" },
  { value: "0.3333", label: "1/3" },
  { value: "0.25", label: "1/4" },
  { value: "0.2", label: "1/5" },
];

export default function QuestionAI() {
  const navigate = useNavigate();
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Step 1
  const [pdf, setPdf] = useState<File | null>(null);
  const [count, setCount] = useState(10);
  const [difficulty, setDifficulty] = useState("Mixed");
  const [focus, setFocus] = useState("");
  const [generating, setGenerating] = useState(false);

  // Step 2
  const [questions, setQuestions] = useState<GenQ[]>([]);
  const [showKey, setShowKey] = useState(false);

  // Step 3
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [timeLimit, setTimeLimit] = useState(30);
  const [marksPer, setMarksPer] = useState(1);
  const [negEnabled, setNegEnabled] = useState(false);
  const [negFraction, setNegFraction] = useState("0.25");
  const [saving, setSaving] = useState(false);

  const handleGenerate = async () => {
    if (!pdf) return toast({ title: "Please upload a PDF", variant: "destructive" });
    if (pdf.size > 20 * 1024 * 1024)
      return toast({ title: "PDF too large", description: "Max 20MB", variant: "destructive" });
    if (count < 1 || count > 50)
      return toast({ title: "Pick 1–50 questions", variant: "destructive" });

    setGenerating(true);
    try {
      const pages = await pdfToImages(pdf, { maxPages: 50, scale: 1.5, quality: 0.8 });
      const images = pages.map((p) => p.dataUrl);
      const { data, error } = await supabase.functions.invoke("generate-mcqs-from-pdf", {
        body: { images, count, difficulty, focus: focus.trim() || undefined },
      });
      if (error) throw error;
      const qs: GenQ[] = (data?.questions || []).map((q: any) => ({
        question: String(q.question || "").trim(),
        option_a: String(q.option_a || "").trim(),
        option_b: String(q.option_b || "").trim(),
        option_c: String(q.option_c || "").trim(),
        option_d: String(q.option_d || "").trim(),
        correct_answer: (q.correct_answer || "A") as "A" | "B" | "C" | "D",
      }));
      if (qs.length === 0) {
        toast({ title: "No questions returned", variant: "destructive" });
        setGenerating(false);
        return;
      }
      if (qs.length < count) {
        toast({
          title: `Generated ${qs.length} of ${count}`,
          description: "AI returned fewer questions than requested. You can edit/add more before saving.",
        });
      } else {
        toast({ title: `Generated ${qs.length} questions` });
      }
      setQuestions(qs);
      setStep(2);
    } catch (e: any) {
      toast({ title: "Generation failed", description: e.message ?? String(e), variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const updateQ = (idx: number, patch: Partial<GenQ>) => {
    setQuestions((prev) => prev.map((q, i) => (i === idx ? { ...q, ...patch } : q)));
  };
  const removeQ = (idx: number) => {
    setQuestions((prev) => prev.filter((_, i) => i !== idx));
  };

  const saveTest = async (status: "draft" | "published") => {
    if (!name.trim()) return toast({ title: "Test name required", variant: "destructive" });
    if (questions.length === 0)
      return toast({ title: "No questions to save", variant: "destructive" });

    setSaving(true);
    try {
      const { data: testRow, error: testErr } = await supabase
        .from("tests")
        .insert({
          name: name.trim(),
          description: description.trim() || null,
          time_limit: timeLimit,
          marks_per_question: marksPer,
          negative_marking_fraction: negEnabled ? Number(negFraction) : null,
          total_questions: questions.length,
          status,
        })
        .select("id")
        .single();
      if (testErr) throw testErr;

      const rows = questions.map((q, i) => ({
        test_id: testRow.id,
        question: q.question,
        option_a: q.option_a,
        option_b: q.option_b,
        option_c: q.option_c,
        option_d: q.option_d,
        correct_answer: q.correct_answer,
        order_index: i,
      }));
      const { data: inserted, error: qErr } = await supabase
        .from("questions")
        .insert(rows)
        .select("id, question, option_a, option_b, option_c, option_d");
      if (qErr) throw qErr;

      // Background: auto-translate each question (test name/desc too)
      supabase.functions
        .invoke("translate-to-hindi", {
          body: {
            fields: {
              name: name.trim(),
              ...(description.trim() ? { description: description.trim() } : {}),
            },
          },
        })
        .then(({ data }) => {
          const t = data?.translations;
          if (t)
            supabase
              .from("tests")
              .update({ name_hi: t.name || null, description_hi: t.description || null })
              .eq("id", testRow.id)
              .then(() => {});
        });

      (inserted ?? []).forEach((q: any) => {
        const fields: Record<string, string> = {};
        if (q.question) fields.question = q.question;
        if (q.option_a) fields.option_a = q.option_a;
        if (q.option_b) fields.option_b = q.option_b;
        if (q.option_c) fields.option_c = q.option_c;
        if (q.option_d) fields.option_d = q.option_d;
        supabase.functions
          .invoke("translate-to-hindi", { body: { fields } })
          .then(({ data }) => {
            const t = data?.translations;
            if (!t) return;
            supabase
              .from("questions")
              .update({
                question_hi: t.question || null,
                option_a_hi: t.option_a || null,
                option_b_hi: t.option_b || null,
                option_c_hi: t.option_c || null,
                option_d_hi: t.option_d || null,
              })
              .eq("id", q.id)
              .then(() => {});
          });
      });

      toast({ title: status === "published" ? "Test is now live" : "Saved as draft" });
      navigate("/admin/tests");
    } catch (e: any) {
      toast({ title: "Save failed", description: e.message ?? String(e), variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const answerKeyText = questions.map((q, i) => `${i + 1}-${q.correct_answer}`).join(", ");

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate("/admin")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-primary" /> Question AI
          </h1>
          <p className="text-sm text-muted-foreground">
            Upload a PDF and let AI generate MCQs with answers automatically.
          </p>
        </div>
      </div>

      {/* Step indicators */}
      <div className="flex items-center gap-2 text-sm">
        {[1, 2, 3].map((s) => (
          <div
            key={s}
            className={`flex items-center gap-2 px-3 py-1 rounded-full ${
              step === s
                ? "bg-primary text-primary-foreground"
                : step > s
                  ? "bg-primary/20 text-primary"
                  : "bg-muted text-muted-foreground"
            }`}
          >
            <span className="font-bold">{s}</span>
            <span>{s === 1 ? "Upload" : s === 2 ? "Review" : "Save"}</span>
          </div>
        ))}
      </div>

      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Upload material</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>PDF file (max 20MB, up to 50 pages)</Label>
              <Input
                type="file"
                accept="application/pdf"
                onChange={(e) => setPdf(e.target.files?.[0] ?? null)}
              />
              {pdf && (
                <p className="text-xs text-muted-foreground inline-flex items-center gap-1">
                  <FileUp className="h-3 w-3" /> {pdf.name} ({Math.round(pdf.size / 1024)} KB)
                </p>
              )}
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>How many questions? (1–50)</Label>
                <Input
                  type="number"
                  min={1}
                  max={50}
                  value={count}
                  onChange={(e) => setCount(Number(e.target.value))}
                />
              </div>
              <div className="space-y-2">
                <Label>Difficulty</Label>
                <Select value={difficulty} onValueChange={setDifficulty}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {["Easy", "Medium", "Hard", "Mixed"].map((d) => (
                      <SelectItem key={d} value={d}>
                        {d}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Focus / topic (optional)</Label>
              <Textarea
                value={focus}
                onChange={(e) => setFocus(e.target.value)}
                rows={2}
                placeholder="e.g. Focus on Chapter 3 — World War II causes"
              />
            </div>
            <Button onClick={handleGenerate} disabled={generating || !pdf}>
              {generating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Generating…
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" /> Generate Questions
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {step === 2 && (
        <Card>
          <CardHeader className="flex-row items-center justify-between flex-wrap gap-2">
            <CardTitle>Review ({questions.length} questions)</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setShowKey((v) => !v)}>
                {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                {showKey ? "Hide" : "Show"} answer key
              </Button>
              <Button variant="outline" size="sm" onClick={() => setStep(1)}>
                Back
              </Button>
              <Button size="sm" onClick={() => setStep(3)} disabled={questions.length === 0}>
                Continue
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {showKey && (
              <div className="rounded-md bg-muted p-3 text-sm font-mono">
                <span className="font-sans font-medium not-italic">Answer key: </span>
                {answerKeyText}
              </div>
            )}
            {questions.map((q, idx) => (
              <Card key={idx} className="border-2">
                <CardContent className="pt-6 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-primary">Q{idx + 1}.</span>
                    <Textarea
                      value={q.question}
                      onChange={(e) => updateQ(idx, { question: e.target.value })}
                      rows={2}
                      className="flex-1"
                    />
                    <Button variant="ghost" size="icon" onClick={() => removeQ(idx)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-2 pl-6">
                    {(["A", "B", "C", "D"] as const).map((opt) => {
                      const key = `option_${opt.toLowerCase()}` as keyof GenQ;
                      const isCorrect = q.correct_answer === opt;
                      return (
                        <div key={opt} className="flex items-center gap-2">
                          <span
                            className={`font-medium w-5 ${
                              isCorrect ? "text-success" : ""
                            }`}
                          >
                            {opt}.
                          </span>
                          <Input
                            value={(q[key] as string) ?? ""}
                            onChange={(e) => updateQ(idx, { [key]: e.target.value } as any)}
                            className={isCorrect ? "border-success" : ""}
                          />
                          {isCorrect && <CheckCircle2 className="h-4 w-4 text-success shrink-0" />}
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center gap-2 pl-6">
                    <Label className="text-sm">Correct Answer:</Label>
                    <Select
                      value={q.correct_answer}
                      onValueChange={(v) => updateQ(idx, { correct_answer: v as any })}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {(["A", "B", "C", "D"] as const).map((o) => (
                          <SelectItem key={o} value={o}>
                            {o}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            ))}
          </CardContent>
        </Card>
      )}

      {step === 3 && (
        <Card>
          <CardHeader>
            <CardTitle>Test details & save</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2 sm:col-span-2">
                <Label>Test Name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label>Description</Label>
                <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
              </div>
              <div className="space-y-2">
                <Label>Time Limit (minutes)</Label>
                <Input
                  type="number"
                  min={1}
                  value={timeLimit}
                  onChange={(e) => setTimeLimit(Number(e.target.value))}
                />
              </div>
              <div className="space-y-2">
                <Label>Marks per Question</Label>
                <Input
                  type="number"
                  step="0.5"
                  min={0.5}
                  value={marksPer}
                  onChange={(e) => setMarksPer(Number(e.target.value))}
                />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="ai-neg"
                    checked={negEnabled}
                    onCheckedChange={(v) => setNegEnabled(!!v)}
                  />
                  <Label htmlFor="ai-neg" className="cursor-pointer">
                    Enable negative marking
                  </Label>
                </div>
                {negEnabled && (
                  <Select value={negFraction} onValueChange={setNegFraction}>
                    <SelectTrigger className="max-w-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FRACTIONS.map((f) => (
                        <SelectItem key={f.value} value={f.value}>
                          {f.label} of marks per question
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" onClick={() => setStep(2)}>
                Back
              </Button>
              <Button variant="secondary" onClick={() => saveTest("draft")} disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Save as Draft
              </Button>
              <Button onClick={() => saveTest("published")} disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Save & Go Live
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
