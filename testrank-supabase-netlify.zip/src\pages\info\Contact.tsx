import StaticPage from "./StaticPage";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, MessageCircle, MapPin, Clock } from "lucide-react";

export default function Contact() {
  return (
    <StaticPage title="Contact Us" subtitle="We typically respond within 24 hours on working days." path="/contact" seoTitle="Contact TestNexa – Mock Test Support & Help" seoDescription="Reach the TestNexa team for help with mock tests, payments, account issues or partnerships. Email, WhatsApp and office details.">
      <div className="grid sm:grid-cols-2 gap-4 not-prose my-6">
        <Card>
          <CardContent className="p-5 space-y-2">
            <Mail className="h-6 w-6 text-primary" />
            <h3 className="font-semibold">Email Support</h3>
            <a href="mailto:support@testnexa.com" className="text-primary hover:underline">support@testnexa.com</a>
            <p className="text-sm text-muted-foreground">For payment, account, or bug-related issues.</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 space-y-2">
            <MessageCircle className="h-6 w-6 text-primary" />
            <h3 className="font-semibold">WhatsApp</h3>
            <a href="https://wa.me/919999999999" className="text-primary hover:underline">+91 99999 99999</a>
            <p className="text-sm text-muted-foreground">Quick help for test access and payment issues.</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 space-y-2">
            <MapPin className="h-6 w-6 text-primary" />
            <h3 className="font-semibold">Office</h3>
            <p>TestNexa EdTech Pvt. Ltd.<br/>New Delhi, India</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 space-y-2">
            <Clock className="h-6 w-6 text-primary" />
            <h3 className="font-semibold">Support hours</h3>
            <p>Mon – Sat · 9:00 AM – 8:00 PM IST</p>
          </CardContent>
        </Card>
      </div>

      <h2 className="text-2xl font-semibold">Have feedback?</h2>
      <p>We genuinely read every email. Tell us what you'd love to see next at <a className="text-primary" href="mailto:hello@testnexa.com">hello@testnexa.com</a>.</p>
    </StaticPage>
  );
}
