-- Tests table
CREATE TABLE public.tests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  time_limit INTEGER NOT NULL DEFAULT 30,
  total_questions INTEGER NOT NULL DEFAULT 0,
  marks_per_question NUMERIC NOT NULL DEFAULT 1,
  negative_marking_fraction NUMERIC,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Questions table
CREATE TABLE public.questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  test_id UUID NOT NULL REFERENCES public.tests(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  option_a TEXT NOT NULL DEFAULT '',
  option_b TEXT NOT NULL DEFAULT '',
  option_c TEXT NOT NULL DEFAULT '',
  option_d TEXT NOT NULL DEFAULT '',
  correct_answer TEXT NOT NULL DEFAULT 'A' CHECK (correct_answer IN ('A','B','C','D')),
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_questions_test ON public.questions(test_id, order_index);

-- Students table
CREATE TABLE public.students (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  mobile TEXT NOT NULL,
  district TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Results table
CREATE TABLE public.results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  test_id UUID NOT NULL REFERENCES public.tests(id) ON DELETE CASCADE,
  score NUMERIC NOT NULL DEFAULT 0,
  correct_answers INTEGER NOT NULL DEFAULT 0,
  wrong_answers INTEGER NOT NULL DEFAULT 0,
  unattempted INTEGER NOT NULL DEFAULT 0,
  time_taken_seconds INTEGER NOT NULL DEFAULT 0,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_results_test ON public.results(test_id);
CREATE INDEX idx_results_student ON public.results(student_id);

-- Enable RLS
ALTER TABLE public.tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.results ENABLE ROW LEVEL SECURITY;

-- RLS: tests
-- Anyone can read published tests (anon + authenticated)
CREATE POLICY "Anyone can view published tests" ON public.tests
  FOR SELECT USING (status = 'published');
-- Anon can do everything for admin (hardcoded admin gate on client per plan)
CREATE POLICY "Public can manage tests" ON public.tests
  FOR ALL USING (true) WITH CHECK (true);

-- RLS: questions  -- admin needs full access; public should NOT read correct_answer (use RPC)
CREATE POLICY "Public can manage questions" ON public.questions
  FOR ALL USING (true) WITH CHECK (true);

-- RLS: students -- public can insert and read their own (we just allow insert/select for simplicity)
CREATE POLICY "Public can insert students" ON public.students
  FOR INSERT WITH CHECK (true);
CREATE POLICY "Public can read students" ON public.students
  FOR SELECT USING (true);

-- RLS: results
CREATE POLICY "Public can read results" ON public.results
  FOR SELECT USING (true);
CREATE POLICY "Public can insert results" ON public.results
  FOR INSERT WITH CHECK (true);

-- RPC: get questions WITHOUT correct_answer
CREATE OR REPLACE FUNCTION public.get_test_questions(p_test_id UUID)
RETURNS TABLE (
  id UUID,
  question TEXT,
  option_a TEXT,
  option_b TEXT,
  option_c TEXT,
  option_d TEXT,
  order_index INTEGER
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT q.id, q.question, q.option_a, q.option_b, q.option_c, q.option_d, q.order_index
  FROM public.questions q
  JOIN public.tests t ON t.id = q.test_id
  WHERE q.test_id = p_test_id AND t.status = 'published'
  ORDER BY q.order_index, q.created_at;
$$;

-- RPC: submit test, compute score server-side
CREATE OR REPLACE FUNCTION public.submit_test(
  p_student_id UUID,
  p_test_id UUID,
  p_answers JSONB,  -- { "<question_id>": "A" | "B" | "C" | "D" }
  p_time_taken INTEGER
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_test public.tests%ROWTYPE;
  v_q RECORD;
  v_user_ans TEXT;
  v_correct INT := 0;
  v_wrong INT := 0;
  v_unattempted INT := 0;
  v_score NUMERIC := 0;
  v_neg NUMERIC;
  v_result_id UUID;
BEGIN
  SELECT * INTO v_test FROM public.tests WHERE id = p_test_id AND status = 'published';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Test not found or not published';
  END IF;

  v_neg := COALESCE(v_test.negative_marking_fraction, 0) * v_test.marks_per_question;

  FOR v_q IN SELECT id, correct_answer FROM public.questions WHERE test_id = p_test_id LOOP
    v_user_ans := p_answers ->> v_q.id::text;
    IF v_user_ans IS NULL OR v_user_ans = '' THEN
      v_unattempted := v_unattempted + 1;
    ELSIF v_user_ans = v_q.correct_answer THEN
      v_correct := v_correct + 1;
      v_score := v_score + v_test.marks_per_question;
    ELSE
      v_wrong := v_wrong + 1;
      v_score := v_score - v_neg;
    END IF;
  END LOOP;

  INSERT INTO public.results (student_id, test_id, score, correct_answers, wrong_answers, unattempted, time_taken_seconds)
  VALUES (p_student_id, p_test_id, v_score, v_correct, v_wrong, v_unattempted, p_time_taken)
  RETURNING id INTO v_result_id;

  RETURN v_result_id;
END;
$$;