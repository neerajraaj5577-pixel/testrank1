import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Clock, FileQuestion, Award, Target, ListChecks,
  IndianRupee, User, LogOut, Trophy, ChevronDown, Unlock, ArrowLeft,
} from "lucide-react";
import Footer from "@/components/Footer";
import SiteHeader from "@/components/SiteHeader";
import { toast } from "@/hooks/use-toast";
import { getOrCreateStudent, setStoredStudentId } from "@/lib/student";

const OTHER_SLUG = "other";

export default function CategoryView() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const [category, setCategory] = useState<any | null>(null);
  const [tests, setTests] = useState<any[]>([]);
  const [unlockedIds, setUnlockedIds] = useState<Set<string>>(new Set());
  const [categoryUnlocked, setCategoryUnlocked] = useState(false);
  const [loading, setLoading] = useState(true);
  const FREE_PREVIEW = 2;

  useEffect(() => {
    (async () => {
      setLoading(true);
      if (slug === OTHER_SLUG) {
        setCategory({ name: "Other Tests", description: "Tests not assigned to any category." });
        const { data } = await supabase
          .from("tests").select("*")
          .eq("status", "published").is("category_id", null)
          .order("created_at", { ascending: false });
        setTests(data ?? []);
      } else {
        const { data: cat } = await supabase
          .from("categories").select("*").eq("slug", slug!).maybeSingle();
        if (!cat) { setLoading(false); return; }
        setCategory(cat);
        const { data } = await supabase
          .from("tests").select("*")
          .eq("status", "published").eq("category_id", cat.id)
          .order("created_at", { ascending: false });
        setTests(data ?? []);
      }
      setLoading(false);
    })();
  }, [slug]);

  useEffect(() => {
    if (!user) { setUnlockedIds(new Set()); setCategoryUnlocked(false); return; }
    (async () => {
      const { data } = await supabase.from("test_unlocks").select("test_id").eq("user_id", user.id);
      setUnlockedIds(new Set((data ?? []).map((r: any) => r.test_id)));
      if (category?.id) {
        const { data: cu } = await supabase.from("category_unlocks").select("id").eq("user_id", user.id).eq("category_id", category.id).maybeSingle();
        setCategoryUnlocked(!!cu);
      }
    })();
  }, [user, category]);

  const isCategoryPaid = !!(category?.is_paid && Number(category?.price ?? 0) > 0);

  const handleStart = async (t: any, idx: number) => {
    // Category-level gating: if category is paid and user hasn't unlocked it, allow first FREE_PREVIEW tests free
    const lockedByCategory = isCategoryPaid && !categoryUnlocked && idx >= FREE_PREVIEW;
    const isPaid = lockedByCategory || (t.is_paid && Number(t.price ?? 0) > 0);
    if (user && profile) {
      let studentId: string | null = null;
      try {
        const student = await getOrCreateStudent({
          name: profile.name,
          mobile: profile.mobile,
          district: profile.district,
        });
        studentId = student.id;
      } catch (error: any) {
        toast({ title: "Error", description: error.message, variant: "destructive" });
        return;
      }
      setStoredStudentId(t.id, studentId!);
      if (lockedByCategory) {
        toast({
          title: "Unlock the full category",
          description: `Pay ₹${Number(category?.price)} once to access all ${tests.length} tests in ${category?.name}. Contact support to complete your purchase.`,
        });
        return;
      }
      if (isPaid) {
        navigate(unlockedIds.has(t.id) || categoryUnlocked ? `/test/${t.id}/instructions` : `/test/${t.id}/pay`);
        return;
      }
      navigate(`/test/${t.id}/instructions`);
      return;
    }
    navigate(`/signup?redirect=${encodeURIComponent(`/test/${t.id}/instructions`)}`);
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <SiteHeader />

      <main className="container py-8 md:py-12">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/")}>
          <ArrowLeft className="h-4 w-4" /> Back to categories
        </Button>

        {loading ? (
          <Skeleton className="h-32 mb-8" />
        ) : !category ? (
          <Card className="max-w-md mx-auto text-center">
            <CardContent className="py-12">
              <FileQuestion className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">Category not found.</p>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="mb-8 flex flex-col sm:flex-row gap-5 items-start">
              {category.thumbnail_url && (
                <div className="w-full sm:w-48 aspect-video rounded-lg overflow-hidden bg-muted shrink-0">
                  <img src={category.thumbnail_url} alt={category.name} className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex-1">
                <h1 className="text-3xl md:text-4xl font-bold mb-2">{category.name}</h1>
                {category.description && <p className="text-muted-foreground">{category.description}</p>}
                <p className="text-sm text-muted-foreground mt-2">{tests.length} test{tests.length === 1 ? "" : "s"}</p>
              </div>
            </div>

            {tests.length === 0 ? (
              <Card className="max-w-md mx-auto text-center">
                <CardContent className="py-12">
                  <FileQuestion className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">No tests in this category yet.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {tests.map((t, idx) => {
                  const lockedByCategory = isCategoryPaid && !categoryUnlocked && idx >= FREE_PREVIEW;
                  const isPaid = lockedByCategory || (t.is_paid && Number(t.price ?? 0) > 0);
                  const unlocked = unlockedIds.has(t.id) || categoryUnlocked;
                  const showFreePreview = isCategoryPaid && !categoryUnlocked && idx < FREE_PREVIEW;
                  return (
                    <Card key={t.id} className="flex flex-col hover-glow gradient-border-top overflow-hidden">
                      <div className="relative aspect-video w-full overflow-hidden bg-muted">
                        {t.thumbnail_url ? (
                          <img src={t.thumbnail_url} alt={t.name}
                            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                            loading="lazy" />
                        ) : (
                          <div className="w-full h-full bg-gradient-primary flex items-center justify-center">
                            <span className="text-5xl font-bold text-primary-foreground/90">
                              {t.name?.[0]?.toUpperCase() ?? "T"}
                            </span>
                          </div>
                        )}
                        <Badge className="absolute top-3 left-3 bg-card/80 text-foreground hover:bg-card/80 backdrop-blur shadow-sm">
                          #{idx + 1}
                        </Badge>
                        {showFreePreview ? (
                          <Badge className="absolute top-3 right-3 bg-success text-success-foreground shadow-md">Free Preview</Badge>
                        ) : lockedByCategory ? (
                          <Badge className="absolute top-3 right-3 bg-primary text-primary-foreground shadow-md gap-0.5">
                            <IndianRupee className="h-3 w-3" />{Number(category?.price)} · Unlock all
                          </Badge>
                        ) : isPaid ? (
                          unlocked ? (
                            <Badge className="absolute top-3 right-3 bg-success text-success-foreground hover:bg-success/90 shadow-md gap-1">
                              <Unlock className="h-3 w-3" /> Unlocked
                            </Badge>
                          ) : (
                            <Badge className="absolute top-3 right-3 bg-primary text-primary-foreground hover:bg-primary/90 shadow-md gap-0.5">
                              <IndianRupee className="h-3 w-3" />{Number(t.price)}
                            </Badge>
                          )
                        ) : (
                          <Badge className="absolute top-3 right-3 bg-success text-success-foreground hover:bg-success/90 shadow-md">Free</Badge>
                        )}
                      </div>
                      <CardHeader>
                        <CardTitle className="text-lg leading-snug">{t.name}</CardTitle>
                        {t.description && <CardDescription className="line-clamp-2">{t.description}</CardDescription>}
                      </CardHeader>
                      <CardContent className="flex-1 space-y-2.5 text-sm">
                        <Stat icon={ListChecks} label={`${t.total_questions} questions`} />
                        <Stat icon={Clock} label={`${t.time_limit} minutes`} />
                        <Stat icon={Award} label={`${t.marks_per_question} marks per question`} />
                        {t.negative_marking_fraction != null && (
                          <Stat icon={Target}
                            label={`−${(Number(t.negative_marking_fraction) * Number(t.marks_per_question)).toFixed(2)} per wrong answer`}
                            tone="destructive" />
                        )}
                      </CardContent>
                      <CardFooter>
                        <Button onClick={() => handleStart(t, idx)} className="w-full" size="lg">
                          {lockedByCategory
                            ? `Unlock category ₹${Number(category?.price)}`
                            : isPaid
                              ? (unlocked ? "Re-attempt" : `Pay ₹${Number(t.price)} & Start`)
                              : "Start Test"}
                        </Button>
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            )}
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}

function Stat({ icon: Icon, label, tone }: {
  icon: React.ComponentType<{ className?: string }>; label: string; tone?: "destructive";
}) {
  return (
    <div className="flex items-center gap-2.5">
      <span className={"inline-flex items-center justify-center h-7 w-7 rounded-full shrink-0 " +
        (tone === "destructive" ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary")}>
        <Icon className="h-3.5 w-3.5" />
      </span>
      <span className={tone === "destructive" ? "text-destructive" : "text-muted-foreground"}>{label}</span>
    </div>
  );
}
