import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { AlertCircle, Clock, FileQuestion, Award, Languages, ShieldCheck, BookOpen, ArrowRight, CheckCircle2 } from "lucide-react";
import Logo from "@/components/Logo";
import { getOrCreateStudent, getStoredLanguage, setStoredLanguage, setStoredStudentId } from "@/lib/student";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function Instructions() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [test, setTest] = useState<any>(null);
  const [ready, setReady] = useState(false);
  const [lang, setLangState] = useState<"en" | "hi">(getStoredLanguage(id));
  const [showLangDialog, setShowLangDialog] = useState(false);

  const beginTest = () => setShowLangDialog(true);

  const confirmLangAndStart = (chosen: "en" | "hi") => {
    setLangState(chosen);
    if (id) setStoredLanguage(id, chosen);
    setShowLangDialog(false);
    navigate(`/test/${id}/attempt`);
  };

  useEffect(() => {
    if (!id) return;
    (async () => {
      if (user && profile && !sessionStorage.getItem(`tb_student_${id}`)) {
        const student = await getOrCreateStudent({
          name: profile.name,
          mobile: profile.mobile,
          district: profile.district,
        });
        if (student?.id) setStoredStudentId(id, student.id);
      }
      if (!sessionStorage.getItem(`tb_student_${id}`)) {
        navigate(`/signup?redirect=${encodeURIComponent(`/test/${id}/instructions`)}`, { replace: true });
        return;
      }
      const { data } = await supabase.from("tests").select("*").eq("id", id!).single();
      setTest(data);
      setReady(true);
    })();
  }, [id, navigate, user, profile]);

  if (!ready || !test) return <div className="min-h-screen flex items-center justify-center">Loading…</div>;

  const negPerWrong = test.negative_marking_fraction
    ? Number(test.negative_marking_fraction) * Number(test.marks_per_question)
    : 0;

  const displayName = lang === "hi" && test.name_hi ? test.name_hi : test.name;
  const displayDesc = lang === "hi" && test.description_hi ? test.description_hi : test.description;

  const rules = lang === "hi" ? [
    "परीक्षा के दौरान टैब को रिफ्रेश या बंद न करें।",
    "समय समाप्त होने पर परीक्षा स्वतः जमा हो जाएगी।",
    "आप प्रश्नों को समीक्षा के लिए चिह्नित कर सकते हैं।",
    "उत्तर स्वतः सहेजे जाते हैं।",
    "जिस भाषा में आप शुरू करेंगे, उसी भाषा का संस्करण पहले दिखेगा।",
  ] : [
    "Do not refresh or close the tab during the test.",
    "The timer will auto-submit your test when time runs out.",
    "You can mark questions for review and revisit them.",
    "Answers are auto-saved as you go.",
    "The test will open first in the language you choose before starting.",
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle relative overflow-hidden">
      <div className="blob bg-primary/20 h-72 w-72 -top-20 -left-20" />
      <div className="blob bg-primary-glow/20 h-80 w-80 top-40 -right-20" style={{ animationDelay: "4s" }} />

      <header className="relative">
        <div className="container flex h-16 items-center justify-between">
          <Logo />
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-success/10 text-success border border-success/20">
            <ShieldCheck className="h-3.5 w-3.5" /> Secure & Monitored
          </span>
        </div>
      </header>

      <main className="container py-6 md:py-10 relative">
        <div className="max-w-2xl mx-auto rounded-3xl bg-card/90 backdrop-blur shadow-elegant border p-6 md:p-8">
          {/* Title block */}
          <div className="flex items-start gap-4">
            <div className="h-16 w-16 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-lg shrink-0">
              <BookOpen className="h-8 w-8 text-primary-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl md:text-3xl font-bold leading-tight">{displayName}</h1>
              <p className="text-sm text-muted-foreground mt-1">
                {lang === "hi"
                  ? "शुरू करने से पहले निर्देश ध्यान से पढ़ें।"
                  : "Read the instructions carefully before you begin."}
              </p>
              <span className="inline-block mt-2 text-xs font-semibold px-2.5 py-1 rounded-full bg-primary/10 text-primary">
                Test
              </span>
            </div>
          </div>

          {displayDesc && (
            <p className="text-sm mt-4 text-muted-foreground">{displayDesc}</p>
          )}

          {/* Stat tiles */}
          <div className="grid grid-cols-3 gap-3 mt-6">
            <StatTile
              icon={FileQuestion}
              value={test.total_questions}
              label={lang === "hi" ? "प्रश्न" : "Questions"}
              tone="violet"
            />
            <StatTile
              icon={Clock}
              value={test.time_limit}
              label={lang === "hi" ? "मिनट" : "Minutes"}
              tone="blue"
            />
            <StatTile
              icon={Award}
              value={test.marks_per_question}
              label={lang === "hi" ? "अंक प्रत्येक" : "Marks each"}
              tone="emerald"
            />
          </div>

          {/* Negative marking */}
          {negPerWrong > 0 && (
            <div className="mt-5 flex items-center gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/20">
              <AlertCircle className="h-5 w-5 text-destructive shrink-0" />
              <p className="text-sm">
                <span className="font-bold text-destructive">
                  {lang === "hi" ? "नकारात्मक अंकन:" : "Negative marking:"}
                </span>{" "}
                {lang === "hi"
                  ? `हर गलत उत्तर के लिए −${negPerWrong} अंक।`
                  : `−${negPerWrong} marks for every wrong answer.`}
              </p>
            </div>
          )}

          {/* Rules card */}
          <div className="mt-5 rounded-xl border bg-background/60 p-5">
            <div className="flex items-center gap-2 mb-3">
              <ShieldCheck className="h-5 w-5 text-primary" />
              <h3 className="font-semibold">{lang === "hi" ? "नियम" : "Rules"}</h3>
            </div>
            <ul className="space-y-2.5">
              {rules.map((r, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span className="text-muted-foreground">{r}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Begin button */}
          <Button
            className="w-full mt-6 h-14 text-base font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg shadow-primary/30 group"
            size="lg"
            onClick={beginTest}
          >
            {lang === "hi" ? "परीक्षा शुरू करें" : "Begin Test"}
            <span className="ml-2 h-8 w-8 rounded-full bg-white/20 flex items-center justify-center group-hover:translate-x-0.5 transition-transform">
              <ArrowRight className="h-4 w-4" />
            </span>
          </Button>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-5 inline-flex items-center gap-1.5 w-full justify-center">
          <ShieldCheck className="h-3.5 w-3.5" /> Your progress is safe and secure
        </p>
      </main>

      <Dialog open={showLangDialog} onOpenChange={setShowLangDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Languages className="h-5 w-5 text-primary" />
              Choose language / भाषा चुनें
            </DialogTitle>
            <DialogDescription>
              Select your preferred language for this test. The test will start in the same language.
              <br />
              इस परीक्षा के लिए अपनी पसंदीदा भाषा चुनें। परीक्षा उसी भाषा में शुरू होगी।
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="grid grid-cols-2 gap-3 sm:gap-3">
            <Button variant="outline" size="lg" onClick={() => confirmLangAndStart("en")} className="w-full">
              English
            </Button>
            <Button size="lg" onClick={() => confirmLangAndStart("hi")} className="w-full">
              हिंदी
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatTile({
  icon: Icon, value, label, tone,
}: {
  icon: React.ComponentType<{ className?: string }>;
  value: React.ReactNode;
  label: string;
  tone: "violet" | "blue" | "emerald";
}) {
  const tones = {
    violet: { bg: "bg-violet-50 dark:bg-violet-950/40", iconBg: "bg-violet-100 dark:bg-violet-900/60", iconText: "text-violet-600 dark:text-violet-300" },
    blue:   { bg: "bg-blue-50 dark:bg-blue-950/40",   iconBg: "bg-blue-100 dark:bg-blue-900/60",   iconText: "text-blue-600 dark:text-blue-300" },
    emerald:{ bg: "bg-emerald-50 dark:bg-emerald-950/40", iconBg: "bg-emerald-100 dark:bg-emerald-900/60", iconText: "text-emerald-600 dark:text-emerald-300" },
  }[tone];
  return (
    <div className={`text-center p-4 rounded-2xl ${tones.bg}`}>
      <div className={`mx-auto mb-2 h-10 w-10 rounded-full flex items-center justify-center ${tones.iconBg}`}>
        <Icon className={`h-5 w-5 ${tones.iconText}`} />
      </div>
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}
