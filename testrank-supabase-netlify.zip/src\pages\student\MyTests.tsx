import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Home, Trophy, RefreshCw, Eye, TrendingUp, Target, Clock, Award, Flame } from "lucide-react";
import { format } from "@/lib/format";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
  LineChart, Line, CartesianGrid,
} from "recharts";
import UserAvatar from "@/components/UserAvatar";
import Footer from "@/components/Footer";
import SiteHeader from "@/components/SiteHeader";

type Unlock = { test_id: string; source: string; unlocked_at: string };
type Test = { id: string; name: string; total_questions: number; time_limit: number; is_paid: boolean; marks_per_question?: number };
type Result = { id: string; test_id: string; score: number; correct_answers: number; wrong_answers: number; unattempted: number; submitted_at: string; time_taken_seconds: number };

export default function MyTests() {
  const { user, profile } = useAuth();
  const [unlocks, setUnlocks] = useState<Unlock[]>([]);
  const [tests, setTests] = useState<Record<string, Test>>({});
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: u } = await supabase.from("test_unlocks").select("test_id, source, unlocked_at").eq("user_id", user.id);
      const unlocksList = (u ?? []) as Unlock[];
      setUnlocks(unlocksList);

      let resultsList: Result[] = [];
      if (profile?.mobile) {
        const { data: studs } = await supabase.from("students").select("id").eq("mobile", profile.mobile);
        const ids = (studs ?? []).map((s: any) => s.id);
        if (ids.length > 0) {
          const { data: rs } = await supabase
            .from("results")
            .select("id, test_id, score, correct_answers, wrong_answers, unattempted, submitted_at, time_taken_seconds")
            .in("student_id", ids)
            .order("submitted_at", { ascending: false });
          resultsList = (rs ?? []) as Result[];
        }
      }
      setResults(resultsList);

      const testIds = Array.from(new Set([...unlocksList.map((x) => x.test_id), ...resultsList.map((x) => x.test_id)]));
      if (testIds.length > 0) {
        const { data: ts } = await supabase
          .from("tests")
          .select("id, name, total_questions, time_limit, is_paid, marks_per_question")
          .in("id", testIds);
        const map: Record<string, Test> = {};
        (ts ?? []).forEach((t: any) => (map[t.id] = t));
        setTests(map);
      }
      setLoading(false);
    })();
  }, [user, profile]);

  // Aggregates
  const stats = useMemo(() => {
    const totals = results.reduce(
      (a, r) => ({
        correct: a.correct + r.correct_answers,
        wrong: a.wrong + r.wrong_answers,
        unatt: a.unatt + r.unattempted,
        time: a.time + r.time_taken_seconds,
      }),
      { correct: 0, wrong: 0, unatt: 0, time: 0 },
    );
    const attempted = totals.correct + totals.wrong;
    const accuracy = attempted > 0 ? Math.round((totals.correct / attempted) * 100) : 0;
    const totalQs = totals.correct + totals.wrong + totals.unatt;
    return {
      attempts: results.length,
      ...totals,
      accuracy,
      totalQs,
      avgScore: results.length ? Math.round((results.reduce((s, r) => s + Number(r.score), 0) / results.length) * 10) / 10 : 0,
    };
  }, [results]);

  const pieData = [
    { name: "Correct", value: stats.correct, color: "hsl(var(--success))" },
    { name: "Wrong", value: stats.wrong, color: "hsl(var(--destructive))" },
    { name: "Skipped", value: stats.unatt, color: "hsl(var(--muted-foreground))" },
  ].filter(d => d.value > 0);

  const trend = useMemo(() => {
    return [...results].reverse().slice(-12).map((r, i) => {
      const t = tests[r.test_id];
      const max = (t?.total_questions ?? 1) * Number(t?.marks_per_question ?? 1);
      const pct = max > 0 ? Math.round((Number(r.score) / max) * 100) : 0;
      return { name: `#${i + 1}`, score: pct, raw: Number(r.score) };
    });
  }, [results, tests]);

  const perTest = useMemo(() => {
    return results.slice(0, 8).map((r) => {
      const t = tests[r.test_id];
      return {
        name: (t?.name ?? "Test").slice(0, 14),
        Correct: r.correct_answers,
        Wrong: r.wrong_answers,
        Skipped: r.unattempted,
      };
    }).reverse();
  }, [results, tests]);

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col">
      <SiteHeader />

      <main className="container py-8 md:py-10 space-y-6 flex-1">
        {/* Hero/Welcome */}
        <Card className="overflow-hidden">
          <CardContent className="p-6 flex flex-col sm:flex-row gap-5 items-center sm:items-start bg-gradient-to-br from-primary/5 to-primary/0">
            <UserAvatar url={profile?.avatar_url} name={profile?.name} size="xl" />
            <div className="flex-1 text-center sm:text-left">
              <h1 className="text-2xl font-bold">Welcome back, {profile?.name?.split(" ")[0] ?? "Student"} 👋</h1>
              <p className="text-muted-foreground text-sm">Your progress, all in one place. Keep practising to climb the ranks.</p>
              <div className="flex flex-wrap gap-2 justify-center sm:justify-start mt-3">
                <Button asChild size="sm"><Link to="/">Browse new tests</Link></Button>
                <Button asChild size="sm" variant="outline"><Link to="/profile">Edit profile</Link></Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* KPI cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Kpi icon={Trophy} label="Tests taken" value={stats.attempts} tone="primary" />
          <Kpi icon={Target} label="Accuracy" value={`${stats.accuracy}%`} tone="success" />
          <Kpi icon={Award} label="Avg score" value={stats.avgScore} tone="primary" />
          <Kpi icon={Clock} label="Time spent" value={format.duration(stats.time)} tone="muted" />
        </div>

        {results.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center space-y-3">
              <Flame className="h-10 w-10 text-muted-foreground mx-auto" />
              <p className="text-muted-foreground">No attempts yet. Take your first test to unlock your dashboard!</p>
              <Button asChild><Link to="/">Browse tests</Link></Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2"><Target className="h-4 w-4 text-primary" /> Overall accuracy</CardTitle>
                <CardDescription>Across all your attempts</CardDescription>
              </CardHeader>
              <CardContent>
                {pieData.length === 0 ? <p className="text-sm text-muted-foreground">No data yet.</p> : (
                  <ResponsiveContainer width="100%" height={240}>
                    <PieChart>
                      <Pie data={pieData} dataKey="value" nameKey="name" outerRadius={80} innerRadius={45} paddingAngle={2} label>
                        {pieData.map((d, i) => <Cell key={i} fill={d.color} />)}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2"><TrendingUp className="h-4 w-4 text-primary" /> Score trend</CardTitle>
                <CardDescription>Last {trend.length} attempts (% of max)</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={240}>
                  <LineChart data={trend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} domain={[0, 100]} />
                    <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                    <Line type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2.5} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2"><Trophy className="h-4 w-4 text-primary" /> Recent attempts breakdown</CardTitle>
                <CardDescription>Correct vs Wrong vs Skipped per test</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={perTest}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                    <Legend />
                    <Bar dataKey="Correct" stackId="a" fill="hsl(var(--success))" />
                    <Bar dataKey="Wrong" stackId="a" fill="hsl(var(--destructive))" />
                    <Bar dataKey="Skipped" stackId="a" fill="hsl(var(--muted-foreground))" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Unlocks */}
        <Card>
          <CardHeader><CardTitle>Unlocked Tests</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {loading ? <p className="text-muted-foreground">Loading…</p>
              : unlocks.length === 0 ? <p className="text-muted-foreground text-sm">You haven't unlocked any paid tests yet.</p>
              : unlocks.map((u) => {
                  const t = tests[u.test_id];
                  if (!t) return null;
                  return (
                    <div key={u.test_id} className="flex items-center justify-between border rounded-md p-3 flex-wrap gap-2">
                      <div>
                        <div className="font-medium">{t.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {t.total_questions} Qs · {t.time_limit} min · Unlocked {format.dateTime(u.unlocked_at)}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{u.source}</Badge>
                        <Button asChild size="sm"><Link to={`/test/${t.id}/instructions`}><RefreshCw className="h-3.5 w-3.5" /> Re-attempt</Link></Button>
                      </div>
                    </div>
                  );
                })}
          </CardContent>
        </Card>

        {/* Results history */}
        <Card>
          <CardHeader><CardTitle>My Results</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {loading ? <p className="text-muted-foreground">Loading…</p>
              : results.length === 0 ? <p className="text-muted-foreground text-sm">No attempts yet.</p>
              : results.map((r) => {
                  const t = tests[r.test_id];
                  return (
                    <div key={r.id} className="flex items-center justify-between border rounded-md p-3 flex-wrap gap-2">
                      <div>
                        <div className="font-medium flex items-center gap-2">
                          <Trophy className="h-4 w-4 text-primary" />
                          {t?.name ?? "Test"}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Score {r.score} · ✓{r.correct_answers} ✗{r.wrong_answers} ⊘{r.unattempted} · {format.duration(r.time_taken_seconds)} · {format.dateTime(r.submitted_at)}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button asChild size="sm" variant="outline"><Link to={`/test/${r.test_id}/result/${r.id}`}><Eye className="h-3.5 w-3.5" /> View</Link></Button>
                        <Button asChild size="sm"><Link to={`/test/${r.test_id}/instructions`}><RefreshCw className="h-3.5 w-3.5" /> Retest</Link></Button>
                      </div>
                    </div>
                  );
                })}
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  );
}

function Kpi({ icon: Icon, label, value, tone }: { icon: any; label: string; value: any; tone: "primary" | "success" | "muted" }) {
  const toneClass = tone === "success" ? "bg-success/10 text-success" : tone === "muted" ? "bg-muted text-foreground" : "bg-primary/10 text-primary";
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${toneClass}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <div className="text-xl font-bold leading-tight">{value}</div>
          <div className="text-xs text-muted-foreground">{label}</div>
        </div>
      </CardContent>
    </Card>
  );
}
