import { Link } from "react-router-dom";
import logo from "@/assets/logo.png";

export default function Logo({ to = "/", className = "", size = "md" }: { to?: string; className?: string; size?: "sm" | "md" | "lg" }) {
  const heightClass = size === "sm" ? "h-10 md:h-12" : size === "lg" ? "h-16 md:h-20" : "h-12 md:h-14";
  return (
    <Link to={to} className={`flex items-center ${className}`}>
      <img src={logo} alt="TestNexa logo" className={`${heightClass} w-auto`} />
    </Link>
  );
}
