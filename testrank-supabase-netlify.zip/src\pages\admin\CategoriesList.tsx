import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Edit, Trash2, Eye, EyeOff, FolderTree } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type Row = {
  id: string;
  name: string;
  slug: string;
  thumbnail_url: string | null;
  position: number;
  is_active: boolean;
  test_count: number;
};

export default function AdminCategoriesList() {
  const navigate = useNavigate();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data: cats } = await supabase
      .from("categories")
      .select("*")
      .order("position")
      .order("created_at", { ascending: false });
    const ids = (cats ?? []).map((c: any) => c.id);
    const { data: tests } = ids.length
      ? await supabase.from("tests").select("category_id").in("category_id", ids)
      : { data: [] as any[] };
    const counts = new Map<string, number>();
    (tests ?? []).forEach((t: any) => counts.set(t.category_id, (counts.get(t.category_id) ?? 0) + 1));
    setRows(
      (cats ?? []).map((c: any) => ({
        id: c.id,
        name: c.name,
        slug: c.slug,
        thumbnail_url: c.thumbnail_url,
        position: c.position,
        is_active: c.is_active,
        test_count: counts.get(c.id) ?? 0,
      })),
    );
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const toggleActive = async (row: Row) => {
    const { error } = await supabase.from("categories").update({ is_active: !row.is_active }).eq("id", row.id);
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    toast({ title: row.is_active ? "Category hidden" : "Category visible" });
    load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    toast({ title: "Category deleted", description: "Tests inside are now uncategorised." });
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold">Categories</h1>
          <p className="text-muted-foreground">Group tests by class or exam (e.g. Class 10, SSC CGL).</p>
        </div>
        <Button onClick={() => navigate("/admin/categories/new")}>
          <Plus className="h-4 w-4" /> New Category
        </Button>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16"></TableHead>
              <TableHead>Name</TableHead>
              <TableHead className="hidden sm:table-cell">Slug</TableHead>
              <TableHead className="hidden md:table-cell">Tests</TableHead>
              <TableHead className="hidden md:table-cell">Position</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground py-8">Loading…</TableCell>
              </TableRow>
            ) : rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                  No categories yet. Create your first one.
                </TableCell>
              </TableRow>
            ) : (
              rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell>
                    <div className="h-10 w-10 rounded-md overflow-hidden bg-muted flex items-center justify-center">
                      {r.thumbnail_url ? (
                        <img src={r.thumbnail_url} alt={r.name} className="h-full w-full object-cover" />
                      ) : (
                        <FolderTree className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{r.name}</TableCell>
                  <TableCell className="hidden sm:table-cell text-muted-foreground text-sm">{r.slug}</TableCell>
                  <TableCell className="hidden md:table-cell">{r.test_count}</TableCell>
                  <TableCell className="hidden md:table-cell">{r.position}</TableCell>
                  <TableCell>
                    <Badge variant={r.is_active ? "default" : "secondary"}>
                      {r.is_active ? "Active" : "Hidden"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex gap-1">
                      <Button variant="ghost" size="icon" title={r.is_active ? "Hide" : "Show"} onClick={() => toggleActive(r)}>
                        {r.is_active ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                      <Button asChild variant="ghost" size="icon" title="Edit">
                        <Link to={`/admin/categories/${r.id}/edit`}>
                          <Edit className="h-4 w-4" />
                        </Link>
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" title="Delete">
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete this category?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Tests inside will become uncategorised (they won't be deleted).
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => remove(r.id)}>Delete</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
