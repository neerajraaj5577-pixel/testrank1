import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { IndianRupee } from "lucide-react";

type Row = {
  id: string;
  test_id: string;
  student_id: string;
  amount: number;
  status: string;
  created_at: string;
  verified_at: string | null;
  verified_by: string | null;
  notes: string | null;
  razorpay_order_id: string;
  razorpay_payment_id: string | null;
  student?: { name: string; mobile: string; district: string } | null;
  test?: { name: string } | null;
};

const STATUSES = [
  { value: "all", label: "All" },
  { value: "created", label: "Created" },
  { value: "paid", label: "Approved" },
  { value: "failed", label: "Failed" },
];

export default function AdminPayments() {
  const [rows, setRows] = useState<Row[]>([]);
  const [tests, setTests] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterTest, setFilterTest] = useState("all");
  const [search, setSearch] = useState("");

  const load = async () => {
    setLoading(true);
    const [{ data: pays }, { data: ts }] = await Promise.all([
      supabase.from("test_payments").select("*").order("created_at", { ascending: false }),
      supabase.from("tests").select("id, name").order("created_at", { ascending: false }),
    ]);
    const list = (pays ?? []) as Row[];
    // Hydrate student + test names
    const studentIds = Array.from(new Set(list.map((r) => r.student_id)));
    const testIds = Array.from(new Set(list.map((r) => r.test_id)));
    const [{ data: students }, { data: testRows }] = await Promise.all([
      studentIds.length
        ? supabase.from("students").select("id, name, mobile, district").in("id", studentIds)
        : Promise.resolve({ data: [] as any[] }),
      testIds.length
        ? supabase.from("tests").select("id, name").in("id", testIds)
        : Promise.resolve({ data: [] as any[] }),
    ]);
    const sMap = new Map((students ?? []).map((s: any) => [s.id, s]));
    const tMap = new Map((testRows ?? []).map((t: any) => [t.id, t]));
    setRows(
      list.map((r) => ({
        ...r,
        student: sMap.get(r.student_id) ?? null,
        test: tMap.get(r.test_id) ?? null,
      })),
    );
    setTests((ts ?? []) as any);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (filterStatus !== "all" && r.status !== filterStatus) return false;
      if (filterTest !== "all" && r.test_id !== filterTest) return false;
      if (q) {
        const hay = `${r.student?.mobile ?? ""} ${r.razorpay_order_id ?? ""} ${r.razorpay_payment_id ?? ""} ${r.student?.name ?? ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [rows, filterStatus, filterTest, search]);

  const statusBadge = (s: string) => {
    if (s === "paid") return <Badge className="bg-success text-success-foreground hover:bg-success/90">Approved</Badge>;
    if (s === "created") return <Badge variant="secondary">Created</Badge>;
    if (s === "failed") return <Badge variant="destructive">Failed</Badge>;
    return <Badge variant="outline">{s}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <IndianRupee className="h-6 w-6" /> Payments
        </h1>
        <p className="text-sm text-muted-foreground">
          Track live Razorpay payment attempts and successful unlocks.
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1">
              <Label className="text-xs">Status</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {STATUSES.map((s) => (
                    <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Test</Label>
              <Select value={filterTest} onValueChange={setFilterTest}>
                <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All tests</SelectItem>
                  {tests.map((t) => (
                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1 flex-1 min-w-[200px]">
              <Label className="text-xs">Search (mobile / order id / payment id / name)</Label>
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search…" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Test</TableHead>
                <TableHead>Amount</TableHead>
                  <TableHead>Order ID</TableHead>
                  <TableHead>Payment ID</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead>Status</TableHead>
                  <TableHead className="text-right">Verified</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">Loading…</TableCell>
                </TableRow>
              ) : filtered.length === 0 ? (
                <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">No payments found</TableCell>
                </TableRow>
              ) : (
                filtered.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell>
                      <div className="font-medium">{r.student?.name ?? "—"}</div>
                      <div className="text-xs text-muted-foreground">{r.student?.mobile ?? ""}</div>
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">{r.test?.name ?? "—"}</TableCell>
                    <TableCell>₹ {Number(r.amount)}</TableCell>
                      <TableCell className="font-mono text-xs">{r.razorpay_order_id}</TableCell>
                      <TableCell className="font-mono text-xs">{r.razorpay_payment_id ?? "—"}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(r.created_at).toLocaleString()}
                    </TableCell>
                    <TableCell>{statusBadge(r.status)}</TableCell>
                    <TableCell className="text-right">
                        <span className="text-xs text-muted-foreground">
                          {r.verified_at ? new Date(r.verified_at).toLocaleString() : r.status === "created" ? "Awaiting completion" : "—"}
                        </span>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
