import StaticPage from "./StaticPage";

export default function Terms() {
  return (
    <StaticPage title="Terms of Service" subtitle="Last updated: May 2026" path="/terms" seoTitle="Terms of Service – TestNexa" seoDescription="TestNexa's terms of service covering account use, test integrity, payments, refunds and content ownership.">
      <p>By using TestNexa, you agree to the following terms.</p>

      <h2 className="text-2xl font-semibold mt-6">1. Account</h2>
      <p>You must provide accurate information and are responsible for activity on your account.</p>

      <h2 className="text-2xl font-semibold mt-6">2. Test integrity</h2>
      <ul className="list-disc pl-6 space-y-1">
        <li>Do not screenshot, screen-record, or share test content publicly.</li>
        <li>Going back / closing the tab during an attempt auto-submits the test.</li>
        <li>Repeated misuse may result in account suspension without refund.</li>
      </ul>

      <h2 className="text-2xl font-semibold mt-6">3. Payments & refunds</h2>
      <ul className="list-disc pl-6 space-y-1">
        <li>Paid categories give you lifetime access to all tests inside that category.</li>
        <li>Free preview tests inside paid categories are clearly marked.</li>
        <li>Refunds are reviewed case-by-case within 7 days of purchase if no test was attempted.</li>
      </ul>

      <h2 className="text-2xl font-semibold mt-6">4. Content ownership</h2>
      <p>All questions, explanations, and branding belong to TestNexa. You may not republish.</p>

      <h2 className="text-2xl font-semibold mt-6">5. Disclaimer</h2>
      <p>TestNexa is a practice platform. We do not guarantee selection in any government exam.</p>

      <h2 className="text-2xl font-semibold mt-6">6. Contact</h2>
      <p>Questions about these terms? Email <a className="text-primary" href="mailto:legal@testnexa.com">legal@testnexa.com</a>.</p>
    </StaticPage>
  );
}
