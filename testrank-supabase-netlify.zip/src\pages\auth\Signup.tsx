import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { mobileToEmail } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Home } from "lucide-react";

const EXAMS = ["SSC", "Banking", "Railways", "UPSC", "State PSC", "NEET", "JEE", "Other"];

const schema = z.object({
  name: z.string().trim().min(2, "Name too short").max(100),
  mobile: z.string().trim().regex(/^\d{10}$/, "Mobile must be 10 digits"),
  district: z.string().trim().min(2, "District required").max(100),
  exam: z.string().min(1, "Choose exam"),
  dob: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Enter DOB"),
});

export default function Signup() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const redirect = params.get("redirect") || "/";
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [district, setDistrict] = useState("");
  const [exam, setExam] = useState("");
  const [dob, setDob] = useState(""); // yyyy-mm-dd
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({ name, mobile, district, exam, dob });
    if (!parsed.success) {
      toast({ title: "Invalid input", description: parsed.error.issues[0].message, variant: "destructive" });
      return;
    }
    // Convert dob yyyy-mm-dd → DDMMYYYY password
    const [y, m, d] = parsed.data.dob.split("-");
    const password = `${d}${m}${y}`;

    setSubmitting(true);
    const { data, error } = await supabase.auth.signUp({
      email: mobileToEmail(parsed.data.mobile),
      password,
      options: { emailRedirectTo: `${window.location.origin}/` },
    });
    if (error) {
      setSubmitting(false);
      toast({ title: "Signup failed", description: error.message, variant: "destructive" });
      return;
    }
    const uid = data.user?.id;
    if (!uid) {
      setSubmitting(false);
      toast({ title: "Signup failed", description: "No user returned", variant: "destructive" });
      return;
    }
    const { error: pErr } = await supabase.from("student_profiles").insert({
      user_id: uid,
      name: parsed.data.name,
      mobile: parsed.data.mobile,
      district: parsed.data.district,
      exam: parsed.data.exam,
      dob: parsed.data.dob,
    });
    setSubmitting(false);
    if (pErr) {
      toast({ title: "Profile save failed", description: pErr.message, variant: "destructive" });
      return;
    }
    toast({
      title: "Welcome!",
      description: `Your password is your DOB: ${password}. Save it.`,
    });
    navigate(redirect, { replace: true });
  };

  return (
    <div className="min-h-screen bg-gradient-subtle flex items-center justify-center p-4 py-10">
      <div className="w-full max-w-md space-y-3">
        <div className="flex justify-start">
          <Button asChild variant="ghost" size="sm">
            <Link to="/"><Home className="h-4 w-4" /> Back to Home</Link>
          </Button>
        </div>
        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle>Create your account</CardTitle>
            <CardDescription>One-time signup. Login next time with mobile + DOB.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={100} required />
              </div>
              <div className="space-y-2">
                <Label>Mobile Number (this becomes your login ID)</Label>
                <Input
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, ""))}
                  inputMode="tel"
                  maxLength={10}
                  placeholder="10-digit mobile"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Date of Birth (becomes your password)</Label>
                <Input type="date" value={dob} onChange={(e) => setDob(e.target.value)} required />
                <p className="text-xs text-muted-foreground">Default password = DDMMYYYY of this date.</p>
              </div>
              <div className="space-y-2">
                <Label>District</Label>
                <Input value={district} onChange={(e) => setDistrict(e.target.value)} maxLength={100} required />
              </div>
              <div className="space-y-2">
                <Label>Exam preparing for</Label>
                <Select value={exam} onValueChange={setExam}>
                  <SelectTrigger><SelectValue placeholder="Choose exam" /></SelectTrigger>
                  <SelectContent>
                    {EXAMS.map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? "Creating account…" : "Sign up"}
              </Button>
              <p className="text-sm text-center text-muted-foreground">
                Already registered?{" "}
                <Link to={`/login?redirect=${encodeURIComponent(redirect)}`} className="text-primary font-medium">Login</Link>
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
