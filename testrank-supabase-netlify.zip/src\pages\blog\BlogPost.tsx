import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar } from "lucide-react";
import Footer from "@/components/Footer";
import SiteHeader from "@/components/SiteHeader";
import SEO, { breadcrumbSchema } from "@/components/SEO";
import Breadcrumbs from "@/components/Breadcrumbs";

type Post = {
  id: string; slug: string; title: string; excerpt: string | null;
  content: string; cover_image: string | null; tags: string[] | null;
  seo_title: string | null; seo_description: string | null;
  published_at: string | null;
};

function renderMarkdown(md: string) {
  // Lightweight markdown: headings, paragraphs, lists, bold
  const lines = md.split("\n");
  const out: string[] = [];
  let inList = false;
  for (const raw of lines) {
    const line = raw.trimEnd();
    if (/^##\s+/.test(line)) {
      if (inList) { out.push("</ul>"); inList = false; }
      out.push(`<h2>${escapeHtml(line.replace(/^##\s+/, ""))}</h2>`);
    } else if (/^###\s+/.test(line)) {
      if (inList) { out.push("</ul>"); inList = false; }
      out.push(`<h3>${escapeHtml(line.replace(/^###\s+/, ""))}</h3>`);
    } else if (/^[-*]\s+/.test(line)) {
      if (!inList) { out.push("<ul>"); inList = true; }
      out.push(`<li>${formatInline(line.replace(/^[-*]\s+/, ""))}</li>`);
    } else if (/^\d+\.\s+/.test(line)) {
      if (!inList) { out.push("<ul>"); inList = true; }
      out.push(`<li>${formatInline(line.replace(/^\d+\.\s+/, ""))}</li>`);
    } else if (line.trim() === "") {
      if (inList) { out.push("</ul>"); inList = false; }
    } else {
      if (inList) { out.push("</ul>"); inList = false; }
      out.push(`<p>${formatInline(line)}</p>`);
    }
  }
  if (inList) out.push("</ul>");
  return out.join("\n");
}
function escapeHtml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function formatInline(s: string) {
  return escapeHtml(s).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
}

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<Post | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      if (!slug) return;
      const { data } = await supabase
        .from("blog_posts")
        .select("*")
        .eq("slug", slug)
        .eq("is_published", true)
        .maybeSingle();
      setPost((data as any) ?? null);
      setLoading(false);
    })();
  }, [slug]);

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col">
      {post && (
        <SEO
          title={post.seo_title || post.title}
          description={post.seo_description || post.excerpt || post.title}
          path={`/blog/${post.slug}`}
          type="article"
          jsonLd={[
            breadcrumbSchema([{ name: "Blog", path: "/blog" }, { name: post.title, path: `/blog/${post.slug}` }]),
            {
              "@context": "https://schema.org",
              "@type": "Article",
              headline: post.title,
              description: post.seo_description || post.excerpt,
              datePublished: post.published_at,
              author: { "@type": "Organization", name: "TestNexa" },
              publisher: { "@type": "Organization", name: "TestNexa", logo: { "@type": "ImageObject", url: "https://testnexa.com/icon-512.png" } },
            },
          ]}
        />
      )}
      <SiteHeader />
      <main className="container max-w-3xl py-10 flex-1">
        {loading ? (
          <div className="space-y-4"><Skeleton className="h-10 w-3/4" /><Skeleton className="h-6 w-1/2" /><Skeleton className="h-64" /></div>
        ) : !post ? (
          <div className="text-center py-20">
            <p className="text-muted-foreground mb-4">Post not found.</p>
            <Button asChild><Link to="/blog">Back to Blog</Link></Button>
          </div>
        ) : (
          <>
            <Breadcrumbs items={[{ name: "Blog", path: "/blog" }, { name: post.title, path: `/blog/${post.slug}` }]} />
            <h1 className="text-3xl md:text-4xl font-bold leading-tight mb-3">{post.title}</h1>
            <div className="text-sm text-muted-foreground mb-8 inline-flex items-center gap-1.5">
              <Calendar className="h-4 w-4" />
              {post.published_at && new Date(post.published_at).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}
            </div>
            <article
              className="prose prose-slate dark:prose-invert max-w-none prose-headings:font-bold prose-h2:text-2xl prose-h2:mt-8 prose-h3:text-xl prose-li:my-1"
              dangerouslySetInnerHTML={{ __html: renderMarkdown(post.content) }}
            />
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}
