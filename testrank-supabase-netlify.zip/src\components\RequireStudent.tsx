import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

export function RequireStudent({
  children,
  unauthenticatedTo = "/login",
}: {
  children: React.ReactNode;
  unauthenticatedTo?: "/login" | "/signup";
}) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading…</div>;
  }
  if (!user) {
    const redirect = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`${unauthenticatedTo}?redirect=${redirect}`} replace />;
  }
  return <>{children}</>;
}
