import StaticPage from "./StaticPage";
import { Card, CardContent } from "@/components/ui/card";
import { Target, Users, Sparkles, ShieldCheck } from "lucide-react";

export default function About() {
  return (
    <StaticPage title="About TestNexa" subtitle="Test Smart. Crack Faster." path="/about" seoTitle="About TestNexa – India's Modern Mock Test Platform" seoDescription="Learn about TestNexa — India's mock test platform helping aspirants crack SSC, Banking, Railway, UPSC and state government exams with real exam-feel practice.">
      <p className="text-lg">
        TestNexa is India's modern mock-test platform built for serious aspirants of competitive
        exams — from SSC and Banking to Railways, Defence, State PSCs, and beyond. We obsess over
        one thing: making practice feel exactly like the real exam.
      </p>

      <h2 className="text-2xl font-semibold mt-8">Our mission</h2>
      <p>
        Every aspirant deserves an exam-ready experience without expensive coaching. We deliver
        bilingual, sectioned, full-length mock tests with deep analytics so you can identify weak
        topics, fix them, and walk into the real exam with confidence.
      </p>

      <div className="grid sm:grid-cols-2 gap-4 not-prose my-8">
        {[
          { icon: Target, title: "10,000+ MCQs", desc: "Curated by educators and refreshed monthly." },
          { icon: Users, title: "50,000+ Aspirants", desc: "A growing community across India." },
          { icon: Sparkles, title: "AI-Assisted Hindi", desc: "Every question available in हिंदी, instantly." },
          { icon: ShieldCheck, title: "Real Exam Feel", desc: "Section palette, timer, anti-cheat — just like TCS/Eduquity." },
        ].map((f) => (
          <Card key={f.title}>
            <CardContent className="p-5 flex gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                <f.icon className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.desc}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <h2 className="text-2xl font-semibold">Why TestNexa?</h2>
      <ul className="list-disc pl-6 space-y-2">
        <li>Real exam-style interface modelled on TCS iON & Eduquity.</li>
        <li>Per-question time tracking and accuracy breakdowns.</li>
        <li>Category-wise unlock — pay once, practice all tests in a category.</li>
        <li>English & Hindi support on every question.</li>
        <li>Built in India, for India.</li>
      </ul>
    </StaticPage>
  );
}
