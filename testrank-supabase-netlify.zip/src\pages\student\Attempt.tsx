import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetTrigger, SheetTitle, SheetHeader } from "@/components/ui/sheet";
import { Clock, Menu, Timer, User, Maximize2 } from "lucide-react";
import UserAvatar from "@/components/UserAvatar";
import { cn } from "@/lib/utils";
import { format } from "@/lib/format";
import { toast } from "@/hooks/use-toast";
import { getStoredLanguage } from "@/lib/student";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type Q = {
  id: string;
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  order_index: number;
  image_url?: string | null;
  question_hi?: string | null;
  option_a_hi?: string | null;
  option_b_hi?: string | null;
  option_c_hi?: string | null;
  option_d_hi?: string | null;
  section_id?: string | null;
  option_a_image?: string | null;
  option_b_image?: string | null;
  option_c_image?: string | null;
  option_d_image?: string | null;
};

type Section = { id: string; name: string; position: number };
type LockedLanguage = "en" | "hi" | null;

const GENERAL_SECTION: Section = { id: "__general__", name: "General", position: 0 };

export default function Attempt() {
  const { id: testId } = useParams();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const studentId = sessionStorage.getItem(`tb_student_${testId}`);

  const [test, setTest] = useState<any>(null);
  const [questions, setQuestions] = useState<Q[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [activeSectionId, setActiveSectionId] = useState<string>(GENERAL_SECTION.id);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [marked, setMarked] = useState<Set<string>>(new Set());
  const [visited, setVisited] = useState<Set<string>>(new Set());
  const [current, setCurrent] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [lang, setLang] = useState<"en" | "hi">(getStoredLanguage(testId));
  const [questionLanguageLock, setQuestionLanguageLock] = useState<Record<string, LockedLanguage>>({});
  const startedAtRef = useRef<number>(Date.now());
  const submittedRef = useRef(false);

  const [timeSpent, setTimeSpent] = useState<Record<string, number>>({});
  const currentQuestionStartRef = useRef<number>(Date.now());
  const currentQuestionIdRef = useRef<string | null>(null);
  const [, forceTick] = useState(0);

  const toggleLang = () => {
    const lock = questionLanguageLock[questions[current]?.id];
    if (lock) return;
    const next = lang === "en" ? "hi" : "en";
    setLang(next);
    if (testId) sessionStorage.setItem(`tb_lang_${testId}`, next);
  };

  const localized = (q: Q, key: "question" | "option_a" | "option_b" | "option_c" | "option_d") => {
    const forcedLang = questionLanguageLock[q.id];
    if (forcedLang === "en") return (q as any)[key];
    if (forcedLang === "hi") return (q as any)[`${key}_hi`];
    if (lang === "hi") {
      const hi = (q as any)[`${key}_hi`];
      if (hi && String(hi).trim()) return hi;
    }
    return (q as any)[key];
  };

  // Load
  useEffect(() => {
    if (!studentId) {
      navigate(`/test/${testId}/instructions`, { replace: true });
      return;
    }
    (async () => {
      const [{ data: t }, { data: qs }, { data: imgs }, { data: secs }] = await Promise.all([
        supabase.from("tests").select("*").eq("id", testId!).single(),
        supabase.rpc("get_test_questions", { p_test_id: testId! }),
        supabase.from("questions").select("id, image_url").eq("test_id", testId!),
        supabase.from("test_sections").select("id, name, position").eq("test_id", testId!).order("position"),
      ]);
      if (!t || t.status !== "published") {
        toast({ title: "Test unavailable", variant: "destructive" });
        navigate("/", { replace: true });
        return;
      }
      const imgMap = new Map((imgs ?? []).map((r: any) => [r.id, r.image_url]));
      const merged = ((qs ?? []) as Q[]).map((q) => ({ ...q, image_url: imgMap.get(q.id) ?? null }));
      const langLocks = merged.reduce<Record<string, LockedLanguage>>((acc, question) => {
        const hasEnglish = !!String(question.question ?? "").trim();
        const hasHindi = !!String(question.question_hi ?? "").trim();
        if (hasEnglish && !hasHindi) acc[question.id] = "en";
        else if (!hasEnglish && hasHindi) acc[question.id] = "hi";
        else acc[question.id] = null;
        return acc;
      }, {});
      setTest(t);
      setQuestions(merged);
      setSections((secs ?? []) as Section[]);
      setQuestionLanguageLock(langLocks);
      setSecondsLeft(t.time_limit * 60);

      const saved = sessionStorage.getItem(`tb_attempt_${testId}`);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          setAnswers(parsed.answers ?? {});
          setMarked(new Set(parsed.marked ?? []));
          setTimeSpent(parsed.timeSpent ?? {});
          startedAtRef.current = parsed.startedAt ?? Date.now();
          const elapsed = Math.floor((Date.now() - startedAtRef.current) / 1000);
          setSecondsLeft(Math.max(0, t.time_limit * 60 - elapsed));
        } catch {}
      } else {
        startedAtRef.current = Date.now();
      }
      if (merged.length > 0) {
        currentQuestionIdRef.current = merged[0].id;
        currentQuestionStartRef.current = Date.now();
        setActiveSectionId(merged[0].section_id ?? GENERAL_SECTION.id);
      }
    })();
  }, [testId, navigate, studentId]);

  // Update active section when current question changes
  useEffect(() => {
    if (questions.length === 0) return;
    const newQ = questions[current];
    if (!newQ) return;

    const prevId = currentQuestionIdRef.current;
    if (prevId && prevId !== newQ.id) {
      const delta = Date.now() - currentQuestionStartRef.current;
      setTimeSpent((prev) => ({ ...prev, [prevId]: (prev[prevId] ?? 0) + delta }));
    }
    currentQuestionIdRef.current = newQ.id;
    currentQuestionStartRef.current = Date.now();
    setActiveSectionId(newQ.section_id ?? GENERAL_SECTION.id);

    setVisited((prev) => new Set(prev).add(newQ.id));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current, questions]);

  useEffect(() => {
    const t = setInterval(() => forceTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);

  // Timer
  useEffect(() => {
    if (secondsLeft === null) return;
    if (secondsLeft <= 0) {
      handleSubmit(true);
      return;
    }
    const t = setTimeout(() => setSecondsLeft((s) => (s ?? 0) - 1), 1000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secondsLeft]);

  // Auto-save
  useEffect(() => {
    if (!testId) return;
    sessionStorage.setItem(
      `tb_attempt_${testId}`,
      JSON.stringify({
        answers,
        marked: Array.from(marked),
        startedAt: startedAtRef.current,
        timeSpent,
      }),
    );
  }, [answers, marked, testId, timeSpent]);

  // Beforeunload warning
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (submittedRef.current) return;
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, []);

  // Back-button auto-submit
  useEffect(() => {
    if (!testId) return;
    // Push a sentinel so back triggers popstate without leaving the page
    history.pushState({ tbAttempt: true }, "", location.href);
    const onPop = () => {
      if (submittedRef.current) return;
      // Re-push to trap until submission completes
      history.pushState({ tbAttempt: true }, "", location.href);
      toast({
        title: "Submitting test",
        description: "Going back auto-submits your test.",
      });
      handleSubmit(true);
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [testId]);

  const setAnswer = (qid: string, val: string) => setAnswers((a) => ({ ...a, [qid]: val }));
  const clearAnswer = (qid: string) =>
    setAnswers((a) => {
      const next = { ...a };
      delete next[qid];
      return next;
    });
  const toggleMark = (qid: string) =>
    setMarked((m) => {
      const next = new Set(m);
      if (next.has(qid)) next.delete(qid);
      else next.add(qid);
      return next;
    });

  const handleSubmit = async (auto = false) => {
    if (submittedRef.current) return;
    submittedRef.current = true;
    setSubmitting(true);

    const finalTimeSpent = { ...timeSpent };
    const curId = currentQuestionIdRef.current;
    if (curId) {
      const delta = Date.now() - currentQuestionStartRef.current;
      finalTimeSpent[curId] = (finalTimeSpent[curId] ?? 0) + delta;
    }

    const timeTaken = Math.floor((Date.now() - startedAtRef.current) / 1000);
    const { data, error } = await supabase.rpc("submit_test", {
      p_student_id: studentId!,
      p_test_id: testId!,
      p_answers: answers as any,
      p_time_taken: timeTaken,
      p_per_question_time: finalTimeSpent as any,
    });
    if (error) {
      submittedRef.current = false;
      setSubmitting(false);
      toast({ title: "Submit failed", description: error.message, variant: "destructive" });
      return;
    }
    sessionStorage.removeItem(`tb_attempt_${testId}`);
    if (auto) toast({ title: "Test submitted", description: "Your answers were saved." });
    navigate(`/test/${testId}/result/${data}`, { replace: true });
  };

  const requestFullscreen = () => {
    const el = document.documentElement as any;
    const fn = el.requestFullscreen ?? el.webkitRequestFullscreen ?? el.mozRequestFullScreen;
    if (fn) fn.call(el).catch(() => {});
  };

  // Section grouping
  const allSections: Section[] = useMemo(() => {
    if (sections.length === 0) return [GENERAL_SECTION];
    const hasUnsectioned = questions.some((q) => !q.section_id);
    return hasUnsectioned ? [...sections, GENERAL_SECTION] : sections;
  }, [sections, questions]);

  const questionsBySection = useMemo(() => {
    const map = new Map<string, { q: Q; globalIdx: number }[]>();
    allSections.forEach((s) => map.set(s.id, []));
    questions.forEach((q, idx) => {
      const sid = q.section_id ?? GENERAL_SECTION.id;
      if (!map.has(sid)) map.set(sid, []);
      map.get(sid)!.push({ q, globalIdx: idx });
    });
    return map;
  }, [questions, allSections]);

  const switchToSection = (sid: string) => {
    const list = questionsBySection.get(sid) ?? [];
    if (list.length === 0) return;
    const currentInTarget = list.find((x) => x.globalIdx >= current);
    const target = currentInTarget ?? list[0];
    setCurrent(target.globalIdx);
  };

  const goToNextQuestion = () => {
    const currentSectionId = q.section_id ?? GENERAL_SECTION.id;
    const currentSectionQuestions = questionsBySection.get(currentSectionId) ?? [];
    const currentPosInSection = currentSectionQuestions.findIndex((item) => item.q.id === q.id);
    const nextInSection = currentSectionQuestions[currentPosInSection + 1];
    if (nextInSection) {
      setCurrent(nextInSection.globalIdx);
      return;
    }

    const currentSectionIndex = allSections.findIndex((section) => section.id === currentSectionId);
    for (let index = currentSectionIndex + 1; index < allSections.length; index += 1) {
      const nextSectionQuestions = questionsBySection.get(allSections[index].id) ?? [];
      if (nextSectionQuestions.length > 0) {
        setCurrent(nextSectionQuestions[0].globalIdx);
        return;
      }
    }
  };

  if (!test || questions.length === 0 || secondsLeft === null) {
    return <div className="min-h-screen flex items-center justify-center">Loading…</div>;
  }

  const q = questions[current];
  const lowTime = secondsLeft <= 60;
  const answeredCount = Object.keys(answers).length;

  const currentElapsedMs =
    (timeSpent[q.id] ?? 0) +
    (currentQuestionIdRef.current === q.id ? Date.now() - currentQuestionStartRef.current : 0);
  const currentElapsedSec = Math.floor(currentElapsedMs / 1000);

  // Index of current question within its section
  const sectionList = questionsBySection.get(q.section_id ?? GENERAL_SECTION.id) ?? [];
  const inSectionIdx = sectionList.findIndex((x) => x.q.id === q.id);

  const PaletteContent = (
    <div className="space-y-5">
      {/* Candidate */}
      {profile && (
        <div className="flex items-center gap-3 p-3 rounded-lg border bg-card">
          <UserAvatar url={profile.avatar_url} name={profile.name} size="md" />
          <div className="min-w-0">
            <p className="font-medium text-sm truncate">{profile.name}</p>
            <p className="text-xs text-muted-foreground truncate">{profile.mobile}</p>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="grid grid-cols-2 gap-1.5 text-xs">
        <div className="flex items-center gap-1.5">
          <span className="h-4 w-4 rounded bg-success" /> Answered
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-4 w-4 rounded bg-destructive/80" /> Not answered
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-4 w-4 rounded bg-muted border" /> Not visited
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-4 w-4 rounded bg-warning" /> Marked
        </div>
        <div className="flex items-center gap-1.5 col-span-2">
          <span className="h-4 w-4 rounded bg-warning ring-2 ring-success" /> Marked & answered
        </div>
      </div>

      {/* Per-section grids */}
      <div className="space-y-4">
        {allSections.map((s) => {
          const list = questionsBySection.get(s.id) ?? [];
          if (list.length === 0) return null;
          return (
            <div key={s.id}>
              <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">{s.name}</p>
              <div className="grid grid-cols-5 gap-1.5">
                {list.map((x, i) => {
                  const answered = !!answers[x.q.id];
                  const isMarked = marked.has(x.q.id);
                  const isVisited = visited.has(x.q.id);
                  const isCurrent = x.globalIdx === current;
                  return (
                    <button
                      key={x.q.id}
                      onClick={() => setCurrent(x.globalIdx)}
                      className={cn(
                        "h-8 w-8 rounded text-xs font-semibold border transition-all",
                        !isVisited && !answered && !isMarked && "bg-muted text-foreground border-border",
                        isVisited && !answered && !isMarked && "bg-destructive/80 text-destructive-foreground border-destructive",
                        answered && !isMarked && "bg-success text-success-foreground border-success",
                        isMarked && !answered && "bg-warning text-warning-foreground border-warning",
                        isMarked && answered && "bg-warning text-warning-foreground border-warning ring-2 ring-success",
                        isCurrent && "ring-2 ring-primary ring-offset-1",
                      )}
                    >
                      {i + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <AlertDialog>
        <AlertDialogTrigger asChild>
          <Button className="w-full" disabled={submitting}>Submit Test</Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Submit your test?</AlertDialogTitle>
            <AlertDialogDescription>
              You answered {answeredCount} of {questions.length} questions. This action is final.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep editing</AlertDialogCancel>
            <AlertDialogAction onClick={() => handleSubmit(false)}>Submit</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <header className="sticky top-0 z-20 border-b bg-card/95 backdrop-blur">
        <div className="container flex h-14 items-center justify-between gap-2">
          <div className="font-semibold truncate">{lang === "hi" && test.name_hi ? test.name_hi : test.name}</div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={toggleLang}
              className="font-semibold"
              title={questionLanguageLock[q.id] ? "Only one language is available for this question" : "Switch language"}
              disabled={!!questionLanguageLock[q.id]}
            >
              {questionLanguageLock[q.id] === "en" ? "EN" : questionLanguageLock[q.id] === "hi" ? "हिं" : lang === "en" ? "हिं" : "EN"}
            </Button>
            <Button variant="outline" size="icon" onClick={requestFullscreen} title="Fullscreen" className="hidden sm:inline-flex">
              <Maximize2 className="h-4 w-4" />
            </Button>
            <div
              className={cn(
                "flex items-center gap-2 px-3 py-1.5 rounded-md font-mono font-bold",
                lowTime ? "bg-destructive text-destructive-foreground animate-pulse" : "bg-primary text-primary-foreground",
              )}
            >
              <Clock className="h-4 w-4" />
              {format.clock(secondsLeft)}
            </div>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="lg:hidden">
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Question Palette</SheetTitle>
                </SheetHeader>
                <div className="mt-6">{PaletteContent}</div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Section tabs */}
        {allSections.length > 1 && (
          <div className="border-t bg-muted/40 overflow-x-auto">
            <div className="container flex items-center gap-1 py-2 min-w-max">
              {allSections.map((s) => {
                const list = questionsBySection.get(s.id) ?? [];
                if (list.length === 0) return null;
                const isActive = activeSectionId === s.id;
                const ans = list.filter((x) => answers[x.q.id]).length;
                return (
                  <button
                    key={s.id}
                    onClick={() => switchToSection(s.id)}
                    className={cn(
                      "px-3 py-1.5 rounded-md text-sm font-medium whitespace-nowrap transition-colors",
                      isActive
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-card text-foreground",
                    )}
                  >
                    {s.name}{" "}
                    <span className={cn("ml-1 text-xs", isActive ? "opacity-80" : "text-muted-foreground")}>
                      ({ans}/{list.length})
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </header>

      <div className="container py-6 grid lg:grid-cols-[1fr_300px] gap-6">
        <div>
          <Card>
            <CardContent className="pt-6 space-y-6">
              <div className="flex items-center justify-between text-sm text-muted-foreground flex-wrap gap-2">
                <span>
                  {lang === "hi"
                    ? `प्रश्न ${inSectionIdx + 1} / ${sectionList.length}`
                    : `Question ${inSectionIdx + 1} of ${sectionList.length}`}
                </span>
                <span className="inline-flex items-center gap-1 font-mono px-2 py-0.5 rounded bg-muted">
                  <Timer className="h-3.5 w-3.5" />
                  {format.clock(currentElapsedSec)}
                </span>
                <span>{lang === "hi" ? `${answeredCount} उत्तर दिए` : `${answeredCount} answered`}</span>
              </div>
              {q.image_url && (
                <img
                  src={q.image_url}
                  alt="Question illustration"
                  className="max-h-72 rounded-md border mx-auto"
                />
              )}
              <h2 className="text-lg font-semibold leading-relaxed">{localized(q, "question")}</h2>
              <RadioGroup value={answers[q.id] ?? ""} onValueChange={(v) => setAnswer(q.id, v)} className="space-y-2">
                {(["A", "B", "C", "D"] as const).map((opt) => {
                  const text = localized(q, `option_${opt.toLowerCase()}` as any);
                  const img = (q as any)[`option_${opt.toLowerCase()}_image`] as string | null | undefined;
                  if (!text && !img) return null;
                  return (
                    <div
                      key={opt}
                      className={cn(
                        "flex items-start gap-3 p-3 rounded-md border cursor-pointer transition-colors",
                        answers[q.id] === opt ? "border-primary bg-accent" : "hover:bg-muted",
                      )}
                      onClick={() => setAnswer(q.id, opt)}
                    >
                      <RadioGroupItem value={opt} id={`opt-${opt}`} className="mt-1" />
                      <Label htmlFor={`opt-${opt}`} className="flex-1 cursor-pointer space-y-2">
                        <div>
                          <span className="font-medium mr-2">{opt}.</span>
                          {text}
                        </div>
                        {img && (
                          <img src={img} alt={`Option ${opt}`} className="max-h-32 rounded border" />
                        )}
                      </Label>
                    </div>
                  );
                })}
              </RadioGroup>

              <div className="flex flex-wrap gap-2 justify-between pt-4 border-t">
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => clearAnswer(q.id)}>
                    Clear
                  </Button>
                  <Button
                    variant={marked.has(q.id) ? "default" : "outline"}
                    size="sm"
                    onClick={() => toggleMark(q.id)}
                  >
                    {marked.has(q.id) ? "Unmark Review" : "Mark for Review"}
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" disabled={current === 0} onClick={() => setCurrent((c) => c - 1)}>
                    Previous
                  </Button>
                  {current < questions.length - 1 ? (
                    <Button size="sm" onClick={goToNextQuestion}>
                      {answers[q.id] ? "Save & Next" : "Next"}
                    </Button>
                  ) : (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" disabled={submitting}>
                          Submit Test
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Submit your test?</AlertDialogTitle>
                          <AlertDialogDescription>
                            You have answered {answeredCount} of {questions.length} questions. You cannot change answers after submitting.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Keep editing</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleSubmit(false)}>Submit</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <aside className="hidden lg:block">
          <Card className="sticky top-32">
            <CardContent className="pt-6">
              {PaletteContent}
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}
