import { useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, Save, Loader2 } from "lucide-react";

type Test = { id: string; name: string };
type Category = { id: string; name: string; is_active?: boolean };

export default function AdminSubExamEditor() {
  const params = useParams();
  const id = params.id;
  const [search] = useSearchParams();
  const navigate = useNavigate();
  const isNew = !id;
  const [examId, setExamId] = useState<string | null>(params.examId ?? search.get("examId"));
  const [examName, setExamName] = useState("");
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [tests, setTests] = useState<Test[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [form, setForm] = useState({
    name: "", name_hi: "", icon_emoji: "📘", badge_label: "",
    exam_codes: "", position: 0, is_active: true,
    is_paid: false, price: "", mrp: "", validity_days: "",
    free_category_id: "" as string,
  });

  useEffect(() => {
    (async () => {
      const [{ data: ts }, { data: cats }] = await Promise.all([
        supabase.from("tests").select("id,name").eq("status", "published").order("name"),
        supabase.from("categories").select("id,name,is_active").order("name"),
      ]);
      setTests((ts ?? []) as Test[]);
      setCategories((cats ?? []) as Category[]);

      let eid = examId;
      if (!isNew) {
        const { data: sub } = await supabase.from("sub_exams" as any).select("*").eq("id", id!).maybeSingle();
        if (sub) {
          const s: any = sub;
          eid = s.exam_id;
          setExamId(s.exam_id);
          setForm({
            name: s.name ?? "", name_hi: s.name_hi ?? "", icon_emoji: s.icon_emoji ?? "📘",
            badge_label: s.badge_label ?? "", exam_codes: s.exam_codes ?? "",
            position: s.position ?? 0, is_active: !!s.is_active,
            is_paid: !!s.is_paid,
            price: s.price?.toString() ?? "",
            mrp: s.mrp?.toString() ?? "",
            validity_days: s.validity_days?.toString() ?? "",
            free_category_id: s.free_category_id ?? "",
          });
        }
        const { data: links } = await supabase.from("sub_exam_tests" as any).select("test_id").eq("sub_exam_id", id!);
        setSelected(new Set((links ?? []).map((l: any) => l.test_id)));
        setLoading(false);
      }
      if (eid) {
        const { data: ex } = await supabase.from("exams" as any).select("name").eq("id", eid).maybeSingle();
        if (ex) setExamName((ex as any).name ?? "");
      }
    })();
  }, [id, isNew]);

  const save = async () => {
    if (!form.name.trim()) return toast({ title: "Name required", variant: "destructive" });
    if (!examId) return toast({ title: "Missing exam", variant: "destructive" });
    setSaving(true);
    const payload: any = {
      exam_id: examId,
      name: form.name.trim(),
      name_hi: form.name_hi.trim() || null,
      icon_emoji: form.icon_emoji.trim() || "📘",
      badge_label: form.badge_label.trim() || null,
      exam_codes: form.exam_codes.trim() || null,
      position: Number(form.position) || 0,
      is_active: form.is_active,
      is_paid: form.is_paid,
      price: form.is_paid && form.price ? Number(form.price) : null,
      mrp: form.is_paid && form.mrp ? Number(form.mrp) : null,
      validity_days: form.is_paid && form.validity_days ? Number(form.validity_days) : null,
      free_category_id: form.free_category_id || null,
    };
    let sid = id;
    if (isNew) {
      const { data, error } = await (supabase.from("sub_exams" as any) as any).insert(payload).select("id").single();
      if (error) { setSaving(false); return toast({ title: "Error", description: error.message, variant: "destructive" }); }
      sid = (data as any).id;
    } else {
      const { error } = await (supabase.from("sub_exams" as any) as any).update(payload).eq("id", id!);
      if (error) { setSaving(false); return toast({ title: "Error", description: error.message, variant: "destructive" }); }
    }
    await supabase.from("sub_exam_tests" as any).delete().eq("sub_exam_id", sid!);
    if (selected.size > 0) {
      const rows = Array.from(selected).map((tid, i) => ({ sub_exam_id: sid, test_id: tid, position: i }));
      await (supabase.from("sub_exam_tests" as any) as any).insert(rows);
    }
    setSaving(false);
    toast({ title: isNew ? "Sub-exam created" : "Sub-exam updated" });
    navigate(`/admin/exams/${examId}/edit`);
  };

  if (loading) return <div className="flex items-center justify-center py-20"><Loader2 className="h-6 w-6 animate-spin" /></div>;

  return (
    <div className="space-y-6 max-w-3xl">
      <Button variant="ghost" size="sm" onClick={() => examId ? navigate(`/admin/exams/${examId}/edit`) : navigate("/admin/exams")}>
        <ArrowLeft className="h-4 w-4" /> Back
      </Button>
      <div>
        <h1 className="text-3xl font-bold">{isNew ? "New Sub-exam" : "Edit Sub-exam"}</h1>
        {examName && <p className="text-muted-foreground">Inside: {examName}</p>}
      </div>

      <Card>
        <CardHeader><CardTitle>Details</CardTitle></CardHeader>
        <CardContent className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-1.5"><Label>Name (English) *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. SSC CGL" /></div>
          <div className="space-y-1.5"><Label>Name (Hindi)</Label><Input value={form.name_hi} onChange={(e) => setForm({ ...form, name_hi: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Icon emoji</Label><Input value={form.icon_emoji} onChange={(e) => setForm({ ...form, icon_emoji: e.target.value })} maxLength={4} /></div>
          <div className="space-y-1.5"><Label>Badge label</Label><Input value={form.badge_label} onChange={(e) => setForm({ ...form, badge_label: e.target.value })} placeholder="Mock Test / PYQ / Topic Test..." /></div>
          <div className="space-y-1.5 sm:col-span-2"><Label>Subtitle / codes</Label><Input value={form.exam_codes} onChange={(e) => setForm({ ...form, exam_codes: e.target.value })} placeholder="Tier I, Tier II..." /></div>
          <div className="space-y-1.5"><Label>Position</Label><Input type="number" value={form.position} onChange={(e) => setForm({ ...form, position: Number(e.target.value) })} /></div>
          <div className="space-y-1.5"><Label>Active</Label><div className="flex items-center h-10"><Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} /></div></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Premium</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <Switch checked={form.is_paid} onCheckedChange={(v) => setForm({ ...form, is_paid: v })} />
            <Label>Mark this sub-exam as premium (one payment unlocks all tests inside)</Label>
          </div>
          {form.is_paid && (
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="space-y-1.5"><Label>Price (₹)</Label><Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></div>
              <div className="space-y-1.5"><Label>MRP (₹)</Label><Input type="number" value={form.mrp} onChange={(e) => setForm({ ...form, mrp: e.target.value })} /></div>
              <div className="space-y-1.5"><Label>Validity (days)</Label><Input type="number" value={form.validity_days} onChange={(e) => setForm({ ...form, validity_days: e.target.value })} /></div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Free mock test promo</CardTitle></CardHeader>
        <CardContent>
          <Label className="text-sm">Linked free category (shown as “Want a free mock test? Click here”)</Label>
          <Select value={form.free_category_id || "none"} onValueChange={(v) => setForm({ ...form, free_category_id: v === "none" ? "" : v })}>
            <SelectTrigger className="mt-1.5"><SelectValue placeholder="No free category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">— None —</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.name}{c.is_active === false ? " (hidden)" : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Tests inside this sub-exam ({selected.size})</CardTitle></CardHeader>
        <CardContent>
          {tests.length === 0 ? (
            <p className="text-muted-foreground text-sm">No published tests yet. Create tests first.</p>
          ) : (
            <div className="max-h-[28rem] overflow-auto border rounded-lg divide-y">
              {tests.map((t) => (
                <label key={t.id} className="flex items-center gap-3 p-3 hover:bg-muted/40 cursor-pointer">
                  <Checkbox
                    checked={selected.has(t.id)}
                    onCheckedChange={(v) => {
                      const next = new Set(selected);
                      if (v) next.add(t.id); else next.delete(t.id);
                      setSelected(next);
                    }}
                  />
                  <span className="text-sm">{t.name}</span>
                </label>
              ))}
            </div>
          )}
          <p className="text-xs text-muted-foreground mt-2">Set each test's <strong>Test Type</strong> &amp; <strong>Subject</strong> in the Test editor — those drive the tabs and filters on the student page.</p>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => examId ? navigate(`/admin/exams/${examId}/edit`) : navigate("/admin/exams")}>Cancel</Button>
        <Button onClick={save} disabled={saving}>
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save
        </Button>
      </div>
    </div>
  );
}
