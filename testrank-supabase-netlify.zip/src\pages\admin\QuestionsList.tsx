import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Search, Pencil } from "lucide-react";

type QuestionRow = {
  id: string;
  question: string;
  question_hi: string | null;
  correct_answer: string;
  order_index: number;
  test_id: string;
  section_id: string | null;
  test_name?: string;
  section_name?: string;
};

export default function AdminQuestionsList() {
  const [rows, setRows] = useState<QuestionRow[]>([]);
  const [tests, setTests] = useState<Array<{ id: string; name: string }>>([]);
  const [filterTest, setFilterTest] = useState("all");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [{ data: questions }, { data: testsData }, { data: sections }] = await Promise.all([
        supabase.from("questions").select("id, question, question_hi, correct_answer, order_index, test_id, section_id").order("test_id").order("order_index"),
        supabase.from("tests").select("id, name").order("created_at", { ascending: false }),
        supabase.from("test_sections").select("id, name"),
      ]);

      const testMap = new Map((testsData ?? []).map((test: any) => [test.id, test.name]));
      const sectionMap = new Map((sections ?? []).map((section: any) => [section.id, section.name]));

      setTests((testsData ?? []) as Array<{ id: string; name: string }>);
      setRows(
        ((questions ?? []) as QuestionRow[]).map((row) => ({
          ...row,
          test_name: testMap.get(row.test_id) ?? "—",
          section_name: row.section_id ? sectionMap.get(row.section_id) ?? "—" : "General",
        })),
      );
      setLoading(false);
    })();
  }, []);

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    return rows.filter((row) => {
      if (filterTest !== "all" && row.test_id !== filterTest) return false;
      if (!query) return true;
      const haystack = `${row.question} ${row.question_hi ?? ""} ${row.test_name ?? ""} ${row.section_name ?? ""}`.toLowerCase();
      return haystack.includes(query);
    });
  }, [rows, filterTest, search]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">All Questions</h1>
        <p className="text-muted-foreground">Browse every question across all tests from one place.</p>
      </div>

      <Card className="p-4 space-y-3">
        <div className="grid gap-3 md:grid-cols-[1fr_auto]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search question, Hindi text, test or section…" className="pl-9" />
          </div>
          <Select value={filterTest} onValueChange={setFilterTest}>
            <SelectTrigger className="w-full md:w-64">
              <SelectValue placeholder="All tests" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All tests</SelectItem>
              {tests.map((test) => (
                <SelectItem key={test.id} value={test.id}>{test.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Question</TableHead>
              <TableHead className="hidden lg:table-cell">Test</TableHead>
              <TableHead className="hidden md:table-cell">Section</TableHead>
              <TableHead>Correct</TableHead>
              <TableHead className="text-right">Edit</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading…</TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No questions found.</TableCell>
              </TableRow>
            ) : (
              filtered.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>
                    <div className="space-y-1">
                      <p className="font-medium line-clamp-2">Q{row.order_index + 1}. {row.question || row.question_hi || "Untitled question"}</p>
                      {row.question_hi && row.question_hi !== row.question && (
                        <p className="text-xs text-muted-foreground line-clamp-2">{row.question_hi}</p>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell">{row.test_name}</TableCell>
                  <TableCell className="hidden md:table-cell">{row.section_name}</TableCell>
                  <TableCell>{row.correct_answer}</TableCell>
                  <TableCell className="text-right">
                    <Button asChild variant="ghost" size="icon" title="Edit test">
                      <Link to={`/admin/tests/${row.test_id}/edit`}>
                        <Pencil className="h-4 w-4" />
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}