import StaticPage from "./StaticPage";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Briefcase, MapPin } from "lucide-react";

const roles = [
  { title: "Senior Frontend Engineer", type: "Full-time", location: "Remote (India)", stack: "React · TypeScript · Tailwind" },
  { title: "Content Lead — SSC & Banking", type: "Full-time", location: "Delhi NCR", stack: "Subject Matter Expert" },
  { title: "Hindi Content Editor", type: "Contract", location: "Remote", stack: "Translation · QA" },
  { title: "Growth Marketer", type: "Full-time", location: "Bengaluru / Remote", stack: "SEO · Performance ads" },
];

export default function Careers() {
  return (
    <StaticPage title="Careers at TestNexa" subtitle="Help millions of Indian aspirants crack their dream exam." path="/careers" seoTitle="Careers at TestNexa – Join India's EdTech Movement" seoDescription="Open roles at TestNexa: frontend, content, growth and more. Help us build India's most loved competitive exam mock test platform.">
      <p className="text-lg">
        We're a small, focused team building the most loved mock-test platform in India. If you
        care deeply about education and craft, we'd love to talk.
      </p>

      <h2 className="text-2xl font-semibold mt-8">Open roles</h2>
      <div className="not-prose grid gap-3 my-4">
        {roles.map((r) => (
          <Card key={r.title} className="hover-glow">
            <CardContent className="p-5 flex items-start justify-between gap-4 flex-wrap">
              <div>
                <h3 className="font-semibold flex items-center gap-2"><Briefcase className="h-4 w-4 text-primary" /> {r.title}</h3>
                <p className="text-sm text-muted-foreground mt-1 flex items-center gap-3 flex-wrap">
                  <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {r.location}</span>
                  <span>·</span>
                  <span>{r.stack}</span>
                </p>
              </div>
              <Badge variant="secondary">{r.type}</Badge>
            </CardContent>
          </Card>
        ))}
      </div>

      <h2 className="text-2xl font-semibold mt-8">How to apply</h2>
      <p>
        Email <a className="text-primary" href="mailto:careers@testnexa.com">careers@testnexa.com</a> with your CV and a short note on why you'd fit the role. We reply to every applicant.
      </p>
    </StaticPage>
  );
}
