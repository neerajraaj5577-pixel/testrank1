// Edge function: receives base64 PDF page images + answer key, calls OpenAI to extract MCQs.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

type ParsedQuestion = {
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  question_hi?: string;
  option_a_hi?: string;
  option_b_hi?: string;
  option_c_hi?: string;
  option_d_hi?: string;
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { images, answerKey } = await req.json();
    if (!Array.isArray(images) || images.length === 0) {
      return new Response(JSON.stringify({ error: "No images provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
    if (!OPENAI_API_KEY) {
      return new Response(JSON.stringify({ error: "OPENAI_API_KEY not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build vision message: text + each page image
    const expectedCount = answerKey ? Object.keys(answerKey).length : 0;
    const userContent: any[] = [
      {
        type: "text",
        text:
          "Extract EVERY multiple-choice question (MCQ) from these PDF page images, in the order they appear. " +
          "CRITICAL: Do NOT skip the last question on the last page. Scan the bottom of each page carefully. " +
          (expectedCount > 0
            ? `The answer key indicates exactly ${expectedCount} questions are expected — return ALL ${expectedCount}. `
            : "") +
          "For each question, return the question text and exactly 4 options labelled A, B, C, D. " +
          "Strip any leading numbering like '1.' or 'Q1)' from question text. " +
          "Strip leading 'A)', 'a.', '(A)' etc from option text. " +
          "If the PDF contains BOTH English and Hindi versions of the same question (bilingual), " +
          "return the English text in the main fields (question, option_a..d) AND the Hindi text in the *_hi fields " +
          "(question_hi, option_a_hi..d_hi). If only one language is present, fill only those fields and leave the other language fields empty. " +
          "Before returning, COUNT the questions you extracted and verify nothing is missing — including the very last one. " +
          "Use the extract_mcqs tool to return results.",
      },
      ...images.map((dataUrl: string) => ({
        type: "image_url",
        image_url: { url: dataUrl },
      })),
    ];

    const aiResp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: Deno.env.get("OPENAI_MODEL") || "gpt-4o-mini",
        max_tokens: 16000,
        messages: [
          {
            role: "system",
            content:
              "You are a precise OCR + structuring assistant. Extract MCQs from images exactly as written. Detect and preserve bilingual (English/Hindi) content when present. ALWAYS include the final question — never truncate.",
          },
          { role: "user", content: userContent },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "extract_mcqs",
              description: "Return the COMPLETE list of MCQs extracted from the PDF page images, in order. Include Hindi translations in *_hi fields if present. Must include the last question.",
              parameters: {
                type: "object",
                properties: {
                  questions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        question: { type: "string" },
                        option_a: { type: "string" },
                        option_b: { type: "string" },
                        option_c: { type: "string" },
                        option_d: { type: "string" },
                        question_hi: { type: "string", description: "Hindi version if present, else empty string" },
                        option_a_hi: { type: "string" },
                        option_b_hi: { type: "string" },
                        option_c_hi: { type: "string" },
                        option_d_hi: { type: "string" },
                      },
                      required: ["question", "option_a", "option_b", "option_c", "option_d"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["questions"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "extract_mcqs" } },
      }),
    });

    if (!aiResp.ok) {
      if (aiResp.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit reached. Please try again in a minute." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (aiResp.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Add credits in Settings → Workspace → Usage." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      const t = await aiResp.text();
      console.error("OpenAI API error:", aiResp.status, t);
      return new Response(JSON.stringify({ error: "OpenAI API error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await aiResp.json();
    const toolCall = data?.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall?.function?.arguments) {
      console.error("No tool call in response", JSON.stringify(data).slice(0, 500));
      return new Response(JSON.stringify({ error: "AI did not return structured questions" }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const parsed = JSON.parse(toolCall.function.arguments) as { questions: ParsedQuestion[] };
    const questions = (parsed.questions || []).map((q, idx) => {
      const num = idx + 1;
      const correct = (answerKey && answerKey[num]) || "A";
      return { ...q, correct_answer: correct, _hasKey: !!(answerKey && answerKey[num]) };
    });

    const missingCount = expectedCount > questions.length ? expectedCount - questions.length : 0;

    return new Response(JSON.stringify({ questions, expectedCount, missingCount }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("parse-mcq-pdf error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
