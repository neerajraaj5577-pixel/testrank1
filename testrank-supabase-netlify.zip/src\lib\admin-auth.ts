const KEY = "tb_admin_authed";
const ADMIN_USER = "Admin";
const ADMIN_PASS = "Student@321";

export function adminLogin(username: string, password: string): boolean {
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    sessionStorage.setItem(KEY, "1");
    return true;
  }
  return false;
}

export function adminLogout() {
  sessionStorage.removeItem(KEY);
}

export function isAdminAuthed(): boolean {
  return sessionStorage.getItem(KEY) === "1";
}
